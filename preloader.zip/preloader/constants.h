#ifndef CONSTANTS_H
#define CONSTANTS_H

// Conditional constants
#ifdef site24x7
#define agent_install_path "/opt/site24x7/apminsight"
#else
#define agent_install_path "/opt/applicationsmanager/apminsight"
#endif

#endif // CONSTANTS_H
