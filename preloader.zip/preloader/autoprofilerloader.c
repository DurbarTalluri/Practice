#include <stdio.h>
#include <stdlib.h>
#include <dlfcn.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <errno.h>
#include <syslog.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "slog.h"
#include "ini.h"
#include "constants.h"
typedef struct
{
    char* proxyUrl;
    char* apmHost;
    char* agentMonitorGroupStr;
    char* NewPythonPath;
    char* Preloader;
    char* ExporterHost;
} configuration;

configuration config;

typedef struct
{
    char* processMonitoringRules;
} ProcessMonitoringProfile;

ProcessMonitoringProfile process_monitoring_profile;

extern char *__progname;
char *logfilename = "autoprofilerloader";
char *process_monitoring_profile_section = "process_monitoring_profile";
char *agent_installation_path = agent_install_path;
char autoprofilerconf_filepath[224];
char process_monitoring_config_filepath[250];
bool configurationsCleared=false;
char *cwd = NULL;
char *puid = NULL;
char *cmdline = NULL;
char *matched_process_monitoring_rule_name = NULL;
char *commandline_proc = NULL;

const char* excluded_processes[] = {
    "lvm",           // LVM utilities
    "lvmetad",       // LVM metadata daemon  
    "lvm2-monitor",  // LVM monitoring service
    "systemd",       // System manager
    "systemctl",     // System control
    "dbus",          // D-Bus system
    "udev",          // Device manager
    "mount",         // Mount utilities
    "fsck",          // Filesystem check
    "init",          // Init process
    "kthreadd",      // Kernel thread daemon
    "ksoftirqd",     // Kernel soft IRQ
    "migration",     // Migration threads
    "rcu_",          // RCU threads
    "watchdog",      // Watchdog threads
    "systemd-",      // All systemd services
    "NetworkManager", // Network manager
    "dhclient",      // DHCP client
    "sshd",          // SSH daemon (avoid interfering)
    "cron",          // Cron daemon
    "rsyslog",       // System logger
    NULL
};

bool should_exclude_process() {
    // Early safety check - if __progname is NULL, exclude
    if (__progname == NULL) {
        return true;
    }
    
    // Check if this is a system/critical process
    for (int i = 0; excluded_processes[i] != NULL; i++) {
        if (strstr(__progname, excluded_processes[i]) != NULL) {
            return true;  // EXCLUDE system processes
        }
    }
    
    // Additional safety: Exclude if running as root and appears to be a system service
    if (getuid() == 0) {
        if (getppid() == 1) {  // Direct child of init
            return true;
        }
    }
    
    return false;
}

bool is_safe_to_initialize() {
    // Don't run during very early boot
    if (access("/proc", R_OK) != 0) {
        return false;  // /proc not ready = very early boot
    }
    
    // Don't run if basic filesystem operations might fail
    if (access("/tmp", W_OK) != 0) {
        return false;  // Can't write to /tmp = filesystem issues
    }
    
    // Check if we can safely allocate memory
    void* test_alloc = malloc(1024);
    if (test_alloc == NULL) {
        return false;  // Memory allocation problems
    }
    free(test_alloc);
    
    return true;
}

bool set_agent_installation_path() {
    FILE *file = fopen("/etc/environment", "r");
    if (file == NULL) {
        fprintf(stderr, "Error opening file\n");
        return false;
    }

    char line[212];

    while (fgets(line, sizeof(line), file)) {
        size_t len = strlen(line);
        if (len > 0 && line[len - 1] == '\n') {
            line[len - 1] = '\0';
        }
        if (strstr(line, "AUTOPROFILERPATH") != NULL) {
            sscanf(line, "AUTOPROFILERPATH=%199[^\n]", agent_installation_path);
            openlog("ApminsightAutoProfiler", LOG_PID, LOG_USER);
            syslog(LOG_INFO, "Custom Apminsight AutoProfiler installation path found to be %s", agent_installation_path);
            closelog();
            break;
        }
    }
    fclose(file);
    return true;
}

char* trim_string(char* str) {
    if (!str) return NULL;
    
    // Trim leading whitespace
    while (isspace((unsigned char)*str)) {
        str++;
    }
    
    if (*str == 0) {  // All spaces?
        return str;
    }
    
    // Trim trailing whitespace
    char* end = str + strlen(str) - 1;
    while (end > str && isspace((unsigned char)*end)) {
        end--;
    }
    end[1] = '\0';  // Write new null terminator
    
    return str;
}

void set_commandline_proc(pid_t pid) {
    char path[256];
    snprintf(path, sizeof(path), "/proc/%d/cmdline", pid);

    FILE *cmdline_file = fopen(path, "r");
    if (cmdline_file == NULL) {
        slog_debug("No cmdline file for the process");
        perror("fopen");
        return;
    }

    char buffer[4096];
    size_t bytes_read = fread(buffer, 1, sizeof(buffer) - 1, cmdline_file);
    if (bytes_read > 0) {
        buffer[bytes_read] = '\0'; // Ensure null-termination
        // Replace null characters with spaces for readability
        for (size_t i = 0; i < bytes_read; i++) {
            if (buffer[i] == '\0') {
                buffer[i] = ' ';
            }
        }
        // Allocate on heap to avoid dangling pointer
        commandline_proc = malloc(bytes_read + 1);
        if (commandline_proc == NULL) {
            perror("malloc");
            slog_debug("Failed to allocate memory for commandline_proc");
            fclose(cmdline_file);
            return;
        }
        strcpy(commandline_proc, buffer);
        trim_string(commandline_proc);
    } else {
        slog_debug("Empty command line information available");
    }
    fclose(cmdline_file);
    return;
}

void get_file_path(char *filepath_string, int buffer_size, char *extension) {
    strncpy(filepath_string, agent_installation_path, buffer_size-1);
    filepath_string[buffer_size-1] = '\0';
    strncat(filepath_string, extension, buffer_size-1 - strlen(filepath_string) - 1);
}

bool get_node_options_val(char *node_options, int node_options_buffer_size){
    char node_file_path[234];
    get_file_path(node_file_path, sizeof(node_file_path), "/lib/NODE/agent_minified/index.js");
    strncat(node_options, node_file_path, node_options_buffer_size - strlen(node_options) - 1);
    return access(node_file_path, F_OK) == 0;
}

bool get_java_tool_options_val(char *java_tool_options, int java_tool_options_buffer_size) {
    char java_agent_path[234];
    get_file_path(java_agent_path, sizeof(java_agent_path), "/lib/JAVA/apminsight-javaagent.jar");
    strncat(java_tool_options, java_agent_path, java_tool_options_buffer_size - strlen(java_tool_options) - 1);
    return access(java_agent_path, F_OK) == 0;
}

void safe_initialize_logger() {
    // Only initialize logger if it's safe to do so
    if (access("/tmp", W_OK) != 0) {
        return; // Can't write to /tmp, skip logging
    }
    
    slog_config_t cfg;
    slog_init(logfilename, SLOG_FLAGS_ALL, 0);
    slog_config_get(&cfg);
    cfg.nToScreen = 0;
    cfg.nToFile = 1;
    cfg.eDateControl = SLOG_DATE_FULL;
    char logfolderpath[205];
    get_file_path(logfolderpath, sizeof(logfolderpath), "/logs");
    strcpy(cfg.sFilePath, logfolderpath);
    cfg.eColorFormat = SLOG_COLORING_DISABLE;
    slog_config_set(&cfg);
}

static int apm_config_handler(void* user, const char* section, const char* name,
                   const char* value)
{
    configuration* pconfig = (configuration*)user;

    #define MATCH(s, n) strcmp(section, s) == 0 && strcmp(name, n) == 0
    if (MATCH("apminsight_auto_profiler", "APMINSIGHT_PROXY_URL")) {
        pconfig->proxyUrl = strdup(value);
    } else if (MATCH("apminsight_auto_profiler", "APMINSIGHT_HOST")) {
        pconfig->apmHost = strdup(value);
    } else if (MATCH("apminsight_auto_profiler", "APMINSIGHT_MONITOR_GROUP")) {
        pconfig->agentMonitorGroupStr = strdup(value);
    } else if (MATCH("apminsight_auto_profiler", "NEW_PYTHON_PATH")) {
        pconfig->NewPythonPath = strdup(value);
    } else if (MATCH("apminsight_auto_profiler", "PRELOADER")) {
        pconfig->Preloader = strdup(value);
    } else if (MATCH("apminsight_auto_profiler", "APMINSIGHT_DATAEXPORTER_HOST")) {
        pconfig->ExporterHost = strdup(value);
    } else {
        return 0;  /* unknown section/name, error */
    }
    return 1;
}

void safe_free_config(){
    if (configurationsCleared == true)
        return;
        
    // Safe free with NULL checks and pointer reset
    if (config.proxyUrl) {
        free(config.proxyUrl);
        config.proxyUrl = NULL;
    }
    if (config.apmHost) {
        free(config.apmHost);
        config.apmHost = NULL;
    }
    if (config.agentMonitorGroupStr) {
        free(config.agentMonitorGroupStr);
        config.agentMonitorGroupStr = NULL;
    }
    if (config.NewPythonPath) {
        free(config.NewPythonPath);
        config.NewPythonPath = NULL;
    }
    if (config.Preloader) {
        free(config.Preloader);
        config.Preloader = NULL;
    }
    if (config.ExporterHost) {
        free(config.ExporterHost);
        config.ExporterHost = NULL;
    }
    if (puid) {
        free(puid);
        puid = NULL;
    }
    if (cwd) {
        free(cwd);
        cwd = NULL;
    }
    if (cmdline) {
        free(cmdline);
        cmdline = NULL;
    }
    if (commandline_proc) {
        free(commandline_proc);
        commandline_proc = NULL;
    }
    if (process_monitoring_profile.processMonitoringRules) {
        free(process_monitoring_profile.processMonitoringRules);
        process_monitoring_profile.processMonitoringRules = NULL;
    }
    if (matched_process_monitoring_rule_name) {
        free(matched_process_monitoring_rule_name);
        matched_process_monitoring_rule_name = NULL;
    }
    configurationsCleared = true;
}

void safe_read_config(){
    // Initialize all config pointers to NULL first
    config.proxyUrl = NULL;
    config.apmHost = NULL;
    config.agentMonitorGroupStr = NULL;
    config.NewPythonPath = NULL;
    config.Preloader = NULL;
    config.ExporterHost = NULL;
    
    get_file_path(autoprofilerconf_filepath, sizeof(autoprofilerconf_filepath), "/conf/autoprofilerconf.ini");
    
    // Check if config file exists before trying to parse
    if (access(autoprofilerconf_filepath, R_OK) != 0) {
        return; // Config file doesn't exist or can't be read
    }
    
    if (ini_parse(autoprofilerconf_filepath, apm_config_handler, &config) < 0) {
        slog_error("Cannot load the config file %s", autoprofilerconf_filepath);
        // Don't leave partially initialized state
        safe_free_config();
        return;
    }
    slog_info("Successfully read the configuration from autoprofilerconf.ini file");
}

void set_env(char *key, char *val, char *process_type, int pid){
    if (val!=NULL){
        if (setenv(key, val, 1) != 0){
            slog_error("Error setting %s env into the %s process with pid: %d", key, process_type, pid);
        }
        slog_info("Succesfully set %s to the %s process %d", key, process_type, pid);
    }   
}

// Keep the old function name for compatibility but redirect to safe version
void free_config() {
    safe_free_config();
}

void pass_apminsight_configurations(char *process_type, int pid){
    if (config.proxyUrl!=NULL) {
        set_env("APMINSIGHT_PROXY_URL", config.proxyUrl, process_type, pid);
    }
    if (config.apmHost!=NULL) {
        set_env("APMINSIGHT_HOST", config.apmHost, process_type, pid);
    }
    if (config.ExporterHost!=NULL) {
        set_env("APM_EXPORTER_HOST", config.ExporterHost, process_type, pid);
    }
    if (puid!=NULL) {
        set_env("APMINSIGHT_PROCESS_UID", puid, process_type, pid);
    }
    if (matched_process_monitoring_rule_name!=NULL) {
        set_env("APMINSIGHT_PROCESS_MONITORING_RULE_NAME", matched_process_monitoring_rule_name, process_type, pid);
    }
    char agent_home_path[215];
    char path_extension[20]="/agents";
    get_file_path(agent_home_path, sizeof(agent_home_path), path_extension);
    set_env("APMINSIGHT_AGENT_HOMEPATH", agent_home_path, process_type, pid);
    set_env("APMINSIGHT_MONITOR_GROUP", config.agentMonitorGroupStr, process_type, pid);
    set_env("APMINSIGHT_AUTOPROFILER_CONF_FILEPATH", autoprofilerconf_filepath, process_type, pid);
    safe_free_config();
}

bool check_dotnet_agent_download(const char *coreprofilerpath_64, const char *coreprofilerpath_86, const char *dotnet_startup_hooks) {
    return ((access(coreprofilerpath_64, F_OK) == 0) && (access(coreprofilerpath_86, F_OK) == 0) && (access(dotnet_startup_hooks, F_OK) == 0));
}

bool check_python_agent_download(const char *python_agent_files_path) {
    return (access(python_agent_files_path, F_OK) == 0);
}

bool check_java_agent_download(const char *java_agent_jarfile_path) {
    return (access(java_agent_jarfile_path, F_OK) == 0);
}

bool check_nodejs_agent_download(const char *nodeminified_file_path) {
    return (access(nodeminified_file_path, F_OK) == 0);
}

void strip_surrounding_backticks(char *str) {
    size_t len = strlen(str);
    if (len > 0 && str[0] == '`') {
        memmove(str, str + 1, len);
        len--;
    }
    if (len > 0 && str[len - 1] == '`') {
        str[len - 1] = '\0';
    }
}

static int process_monitoring_profile_handler(void* user, const char* section, const char* name,
                   const char* value)
{
    ProcessMonitoringProfile* profile = (ProcessMonitoringProfile*)user;

    #define MATCH(s, n) strcmp(section, s) == 0 && strcmp(name, n) == 0
    if (MATCH(process_monitoring_profile_section, "process_monitoring_rules")) {
        char *clean_val = strdup(value);
        if (clean_val) {
            strip_surrounding_backticks(clean_val);
            profile->processMonitoringRules = strdup(clean_val);
            free(clean_val);
        }
    } else {
        return 0;  /* unknown section/name, error */
    }
    return 1;
}

char* match_process_monitoring_condition(char *input) {
    const char *delimiter = "|";
    size_t delim_len = strlen(delimiter);
    char *condition = strdup(input);
    if (!condition) return strdup("nomatch");
    
    char *condition_copy = condition;
    int field = 0;
    char *parameter = NULL;
    char *operator = NULL;
    char *parameter_value = NULL;
    
    while (condition_copy) {
        char *match = strstr(condition_copy, delimiter);
        if (match) {
            *match = '\0'; // Terminate current token
            if (*condition_copy != '\0') {
                switch (field) {
                    case 0: 
                        parameter = condition_copy;
                        break;
                    case 1: 
                        operator = condition_copy;
                        break;
                    default:
                        slog_debug("Invalid Process Monitoring Condition String format. Additional field found in Process Monitoring Condition: %s", input);
                        free(condition);
                        return strdup("nomatch");
                }
            }
            else {
                slog_debug("Invalid Process Monitoring Condition String format. Found an empty parameter in Process Monitoring Condition: %s", input);
                free(condition);
                return strdup("nomatch");
            }
            condition_copy = match + delim_len;
            field++;
        }
        else {
            if (*condition_copy != '\0') {
                switch(field) {
                    case 2: 
                        parameter_value = condition_copy;
                        break;
                    default:
                        slog_debug("Invalid Process Monitoring Condition String format. Not enough fields found in the Process Monitoring Condition: %s", input);
                        free(condition);
                        return strdup("nomatch");
                }
            }
            else {
                slog_debug("Invalid Process Monitoring Condition String format. Found an empty parameter in Process Monitoring Condition: %s", input);
                free(condition);
                return strdup("nomatch");
            }
            break;
        }
    }
    
    char *cur_param_value = NULL;
    if (strcmp(parameter, "command") == 0) {
        cur_param_value = __progname;
    }
    else if (strcmp(parameter, "commandline") == 0) {
        cur_param_value = commandline_proc;
    }
    else if (strcmp(parameter, "working_dir") == 0) {
        cur_param_value = cwd;
    }
    else {
        slog_debug("Unsupported param type: %s for Process Monitoring Condition: %s", parameter, input);
        free(condition);
        return strdup("nomatch");
    }
    
    if (!cur_param_value) {
        free(condition);
        return strdup("nomatch");
    }
    
    char *result = NULL;
    if (strcmp(operator, "is") == 0) {
        result = (strcmp(cur_param_value, parameter_value) == 0) ? strdup("match") : strdup("nomatch");
    }
    else if (strcmp(operator, "is_not") == 0) {
        result = (strcmp(cur_param_value, parameter_value) != 0) ? strdup("match") : strdup("nomatch");
    }
    else if (strcmp(operator, "contains") == 0){
        result = (strstr(cur_param_value, parameter_value) != NULL) ? strdup("match") : strdup("nomatch");
    }
    else if (strcmp(operator, "does_not_contain") == 0) {
        result = (strstr(cur_param_value, parameter_value) == NULL) ? strdup("match") : strdup("nomatch");
    }
    else if (strcmp(operator, "begins_with") == 0) {
        result = (strncmp(cur_param_value, parameter_value, strlen(parameter_value)) == 0) ? strdup("match") : strdup("nomatch");
    }
    else if (strcmp(operator, "ends_with") == 0) {
        size_t len_str = strlen(cur_param_value);
        size_t len_suffix = strlen(parameter_value);
        if (len_suffix > len_str) {
            result = strdup("nomatch");
        } else {
            result = (strcmp(cur_param_value + len_str - len_suffix, parameter_value) == 0) ? strdup("match") : strdup("nomatch");
        }
    }
    else {
        slog_debug("None of the Process Monitoring Condition Operator is satisfied. Process Monitoring Condition: %s", input);
        result = strdup("nomatch");
    }
    
    free(condition);
    return result ? result : strdup("nomatch");
}

char* get_process_monitoring_rule_status(char *input) {
    const char *delimiter = "||";
    size_t delim_len = strlen(delimiter);
    char *input_copy = strdup(input);
    if (!input_copy) return strdup("nomatch");

    // Get monitoring status (before first semicolon)
    char *monitoring_status = NULL;
    char *first_semicolon = strchr(input_copy, ';');
    if (!first_semicolon) {
        slog_debug("Monitoring status not found in rule: %s", input);
        free(input_copy);
        return strdup("nomatch");
    }
    *first_semicolon = '\0';
    if (*input_copy == '\0') {
        slog_debug("Empty monitoring status in rule: %s", input);
        free(input_copy);
        return strdup("nomatch");
    }
    monitoring_status = strdup(input_copy);  // Store status

    // Get rule name (between semicolons)
    char *input_remaining = first_semicolon + 1;
    char *second_semicolon = strchr(first_semicolon + 1, ';');
    if (second_semicolon) {
        *second_semicolon = '\0';
        if (*input_remaining == '\0') {
            slog_debug("Empty Process Monitoring Rule Name rule: %s", input);
            matched_process_monitoring_rule_name = strdup("");
        }
        else {
            matched_process_monitoring_rule_name = strdup(input_remaining);
        }
    }
    else {
        slog_debug("Rule name separator not found in: %s", input);
        free(input_copy);
        if (monitoring_status) free(monitoring_status);
        return strdup("nomatch");
    }

    // Process conditions (after second semicolon)
    char *conditions = second_semicolon + 1;
    while (conditions && *conditions) {
        char *match = strstr(conditions, delimiter);
        if (match) {
            *match = '\0';  // Split at delimiter
            if (*conditions == '\0') {
                slog_debug("Empty condition in rule: %s", input);
                free(input_copy);
                if (monitoring_status) free(monitoring_status);
                return strdup("nomatch");
            }

            // Check this condition
            char *condition_result = match_process_monitoring_condition(conditions);
            if (strcmp(condition_result, "nomatch") == 0) {
                free(condition_result);
                free(input_copy);
                if (monitoring_status) free(monitoring_status);
                return strdup("nomatch");
            }
            free(condition_result);
            conditions = match + delim_len;
        } else {
            // Last condition
            if (*conditions != '\0') {
                char *condition_result = match_process_monitoring_condition(conditions);
                if (strcmp(condition_result, "nomatch") == 0) {
                    free(condition_result);
                    free(input_copy);
                    if (monitoring_status) free(monitoring_status);
                    return strdup("nomatch");
                }
                free(condition_result);
            }
            break;
        }
    }

    free(input_copy);
    return monitoring_status ? monitoring_status : strdup("nomatch");  // Return "monitor" if all conditions matched
}

char* get_process_monitoring_status(const char *input) {
    const char *delimiter = "|||";
    size_t delim_len = strlen(delimiter);
    char *input_copy = strdup(input);
    if (!input_copy) return strdup("nomatch");
    
    char *current_pos = input_copy;
    while (current_pos) {
        char *match = strstr(current_pos, delimiter);
        if (match) {
            *match = '\0'; // Terminate current token
            if (*current_pos != '\0') {
                char *monitoring_rule_status = get_process_monitoring_rule_status(current_pos);
                if (strcmp(monitoring_rule_status, "nomatch") != 0) {
                    free(input_copy);
                    return monitoring_rule_status;
                }
                free(monitoring_rule_status);
            }
            else {
                slog_debug("Invalid Process Monitoring String format. Found empty String for Monitoring Rule. Process Monitoring String: %s", input);
                free(input_copy);
                return strdup("nomatch");
            }
            current_pos = match + delim_len;
        }
        else {
            if (*current_pos != '\0') {
                char *monitoring_rule_status = get_process_monitoring_rule_status(current_pos);
                if (strcmp(monitoring_rule_status, "nomatch") != 0) {
                    free(input_copy);
                    return monitoring_rule_status;
                }
                free(monitoring_rule_status);
            }
            else {
                slog_debug("Invalid Process Monitoring String format. Found empty String for Monitoring Rule. Process Monitoring String: %s", input);
                free(input_copy);
                return strdup("nomatch");
            }
            break;
        }
    }
    free(input_copy);
    return strdup("nomatch");
}

bool check_process_monitoring_config(char *process_type, int pid) {
    slog_debug("Matching Process Monitoring Config");
    cwd = getcwd(NULL, 0);
    if (!cwd) {
        slog_error("Failed to get current working directory for %s process", process_type);
        return false;
    }
    
    int needed = snprintf(NULL, 0, "%s::%s::%s", process_type, cwd, commandline_proc);
    if (needed < 0) {
        slog_error("snprintf failed while generating unique id for the %s process", process_type);
        return false;
    }
    puid = malloc(needed + 1);
    if (!puid) {
        slog_error("malloc failed for %s unique id", process_type);
        return false;
    }
    sprintf(puid, "%s::%s::%s", process_type, cwd, commandline_proc);
    get_file_path(process_monitoring_config_filepath, sizeof(process_monitoring_config_filepath), "/conf/process-monitoring-config.ini");
    
    // Initialize process monitoring profile
    process_monitoring_profile.processMonitoringRules = NULL;
    
    if (ini_parse(process_monitoring_config_filepath, process_monitoring_profile_handler, &process_monitoring_profile) < 0) {
        slog_error("Cannot load the config file %s", process_monitoring_config_filepath);
        return false;
    }
    if (process_monitoring_profile.processMonitoringRules != NULL && process_monitoring_profile.processMonitoringRules[0] != '\0') {
        slog_debug("Checking the status of Process with UID %s in Process Monitoring Rules", puid);
        char *process_monitoring_status = get_process_monitoring_status(process_monitoring_profile.processMonitoringRules);
        bool result = false;
        if (strcmp(process_monitoring_status, "monitor") == 0) {
            slog_info("APM Monitoring is found to be ENABLED for the %s process with UID %s", process_type, puid);
            result = true;
        } else if (strcmp(process_monitoring_status, "donot_monitor") == 0) {
            slog_info("APM Monitoring is found to be DISABLED for the %s process with UID %s", process_type, puid);
            result = false;
        } else {
            slog_debug("No match for %s process with UID: %s in Process Monitoring Rules", process_type, puid);
            result = false;
        }
        free(process_monitoring_status);
        return result;
    } else {
        slog_debug("No Process Monitoring Rules found in Process Monitoring Config file");
    }
    return false;
}

void __attribute__((constructor)) my_constructor(int argc, char *argv[]) {
    if (should_exclude_process()) {
        return;  // Exit immediately for lvm2-monitor, systemd, etc.
    }
    
    if (!is_safe_to_initialize()) {
        return;  // Exit if filesystem/memory not ready
    }
    
    if (argc <= 0 || argv == NULL) {
        return;
    }
    
    // Initialize all global structures to zero
    memset(&config, 0, sizeof(configuration));
    memset(&process_monitoring_profile, 0, sizeof(ProcessMonitoringProfile));
    
    // Initialize other globals to NULL
    cwd = NULL;
    puid = NULL;
    cmdline = NULL;
    commandline_proc = NULL;
    matched_process_monitoring_rule_name = NULL;
    configurationsCleared = false;
    
    size_t total_length = 0;
    int i;
    for (i = 0; i < argc; i++) {
        total_length += strlen(argv[i]) + 1;
    }
    cmdline = malloc(total_length);
    if (cmdline == NULL) {
        perror("malloc");
        return;
    }
    cmdline[0] = '\0';
    for (i = 0; i < argc; i++) {
        strcat(cmdline, argv[i]);
        if (i < argc - 1) {
            strcat(cmdline, " ");
        }
    }
    
    // Node.js detection and handling
    if (strcmp(__progname, "node")==0 && argc > 1 && strcmp(argv[0], "node" ) == 0 && access("package.json", F_OK) == 0) {
        pid_t pid = getpid();
        slog_info("NODE process detected");
        /*set_agent_installation_path();*/
        safe_initialize_logger();
        safe_read_config();
        set_commandline_proc(pid);
        if (config.Preloader == NULL || strcmp(config.Preloader,"UNSET")==0) {
            slog_info("PRELOADER UNSET, Skipped Node Process Monitoring");
            safe_free_config();
            return;
        }

	char node_minified_file_path[245];
        get_file_path(node_minified_file_path, sizeof(node_minified_file_path),"/lib/NODE/agent_minified/index.js");
        if (check_nodejs_agent_download(node_minified_file_path)==false) {
            slog_info("Node.js Agent minified file is missing, Ignoring the NODE process with pid: %d", pid);
            return;
        }
        
        if (!check_process_monitoring_config("NODE", pid)) {
            slog_info("Skipped Node Process Monitoring");
            safe_free_config();
            return;
        }
        char node_options[237] = "-r ";
        if (get_node_options_val(node_options, sizeof(node_options))==false) {
            slog_warn("Agent minified file is missing, Ignoring the NODE process with pid: %d", pid);
            safe_free_config();
            return;
        }
        set_env("NODE_OPTIONS", node_options, "NODE", pid);
        pass_apminsight_configurations("NODE", pid);
        return;
    }

    // Java detection and handling
    else if (strstr(__progname, "java")!=NULL) {
        if ((cmdline!=NULL) && (strstr(cmdline, "jboss.home.dir")!=NULL || strstr(cmdline, "jboss.home")!=NULL || strstr(cmdline, "com.sun.aas.installRoot")!=NULL || strstr(cmdline, "jetty.home")!=NULL || strstr(cmdline, "weblogic.home")!=NULL || strstr(cmdline, "jboss.home.dir")!=NULL || strstr(cmdline, "wlp.install.dir")!=NULL || strstr(cmdline, "resin.home")!=NULL || strstr(cmdline, "catalina.home")!=NULL || strstr(cmdline, "java -jar ")!=NULL)){
            pid_t pid = getpid();
            slog_info("JAVA process detected");
            /*set_agent_installation_path();*/
            safe_initialize_logger();
            safe_read_config();
        set_commandline_proc(pid);
            slog_info("JAVA process detected with pid: %d", pid);
            if (config.Preloader == NULL || strcmp(config.Preloader,"UNSET")==0) {
                slog_info("PRELOADER UNSET. Skipped Java Process Monitoring");
                safe_free_config();
                return;
            }


            char java_agent_jarfile_path[245];
            get_file_path(java_agent_jarfile_path, sizeof(java_agent_jarfile_path),"/lib/JAVA/apminsight-javaagent.jar");
            if (check_java_agent_download(java_agent_jarfile_path)==false) {
                slog_info("Java Agent jar file is missing, Ignoring the JAVA process with pid: %d", pid);
                return;
            }

            if (!check_process_monitoring_config("JAVA", pid)) {
                slog_info("Skipped Java Process Monitoring");
                safe_free_config();
                return;
            }
            if (strstr(cmdline, "apminsight-javaagent.jar")!=0){
                slog_info("Apminsight Java agent argument already found in commandline, Exiting without loading the agent");
                safe_free_config();
                return;
            }
            char java_tool_options[245] = "-javaagent:";
            if (get_java_tool_options_val(java_tool_options, sizeof(java_tool_options))==false){
                slog_warn("Agent jarfile file is missing, Ignoring the JAVA process with pid: %d", pid);
                safe_free_config();
                return;
            }

            set_env("JAVA_TOOL_OPTIONS", java_tool_options, "JAVA", pid);
            pass_apminsight_configurations("JAVA", pid);
        }
        safe_free_config();
        return;
    }

    // Python detection and handling
    else if ((cmdline!=NULL) && (strstr(cmdline, "flask run")!= NULL || strstr(cmdline, "python ")!=NULL || strstr(cmdline, "python3 ")!=NULL || strstr(cmdline, "gunicorn ")!=NULL || strstr(cmdline, "uvicorn ")!=NULL || strstr(cmdline, "uwsgi ")!=NULL || strstr(cmdline, "daphne ")!=NULL || strstr(cmdline, "hypercorn ")!=NULL || strstr(cmdline, "waitress-serve ")!=NULL || strstr(cmdline, "mod_wsgi-express ")!=NULL || strstr(cmdline, "flask ")!=NULL)){
        pid_t pid = getpid();
        slog_info("PYTHON3 process detected");
        /*set_agent_installation_path();*/
        safe_initialize_logger();
        safe_read_config();
        set_commandline_proc(pid);
        if (config.Preloader == NULL || strcmp(config.Preloader,"UNSET")==0) {
            slog_info("PRELOADER UNSET, Skipped Python Process monitoring");
            safe_free_config();
            return;
        }
        
        if (!check_process_monitoring_config("PYTHON", pid)) {
            slog_info("Skipped Python Process monitoring");
            safe_free_config();
            return;
        }
        if (config.NewPythonPath==NULL) {
            slog_info("No python path found in configuration file, Skipped Python Process monitoring");
            safe_free_config();
            return;
        }
        char python_agent_files_path[245];
        get_file_path(python_agent_files_path, sizeof(python_agent_files_path),"/lib/PYTHON/wheels/apminsight/bootstrap");
        if (check_python_agent_download(python_agent_files_path)==false) {
            slog_info("Python Agent files are missing, Ignoring the PYTHON process with pid: %d", pid);
            safe_free_config();
            return;
        }
        char *PYTHON_PATH_NEW=strdup(config.NewPythonPath);
        if (!PYTHON_PATH_NEW) {
            slog_error("Failed to duplicate NewPythonPath");
            safe_free_config();
            return;
        }
        
        char *PYTHON_PATH_EXISTING = getenv("PYTHONPATH");
        if ( PYTHON_PATH_EXISTING!=NULL ) {
            if (strstr(PYTHON_PATH_EXISTING, "apminsight") != NULL){
                slog_info("Found Apm Insight path already added to PYTHONPATH, Exiting without loading agent");
                goto EndPythonPreload;
            }
            slog_info("Modifying existing PYTHONPATH environment variable");
            int new_pythonpath_buffer_size=strlen(PYTHON_PATH_NEW) + strlen(PYTHON_PATH_EXISTING) + 2;
            char *temp = realloc(PYTHON_PATH_NEW, new_pythonpath_buffer_size);
            if (temp == NULL) {
                // realloc failed
                slog_info("Error while generating new PYTHONPATH");
                slog_debug("Error while allocating allocating memory to temporary PYTHONPATH object");
                goto EndPythonPreload;
                
            } else {
                PYTHON_PATH_NEW = temp;
            }
            strncat(PYTHON_PATH_NEW, ":", new_pythonpath_buffer_size - strlen(PYTHON_PATH_NEW) - 1);
            strncat(PYTHON_PATH_NEW, PYTHON_PATH_EXISTING, new_pythonpath_buffer_size - strlen(PYTHON_PATH_NEW) - 1);
        }
        set_env("PYTHONPATH", PYTHON_PATH_NEW, "PYTHON", pid);
        set_env("APMINSIGHT_MONITOR_GROUP", config.agentMonitorGroupStr, "PYTHON", pid);
        set_env("APMINSIGHT_AUTOPROFILER_CONF_FILEPATH", autoprofilerconf_filepath, "PYTHON", pid);
        set_env("APM_EXPORTER_HOST", config.ExporterHost, "PYTHON", pid);
        set_env("APMINSIGHT_PROCESS_UID", puid, "PYTHON", pid);
        set_env("APMINSIGHT_PROCESS_MONITORING_RULE_NAME", matched_process_monitoring_rule_name, "PYTHON", pid);
        char agent_home_path[215];
        get_file_path(agent_home_path, sizeof(agent_home_path), "/agents");
        if (setenv("APMINSIGHT_AGENT_HOMEPATH", agent_home_path, 1) != 0) {
            slog_error("Error setting APMINSIGHT_AGENT_HOMEPATH env into the PYTHON process with pid: %d", pid);
        }
        slog_info("Succesfully set APMINSIGHT_AGENT_HOMEPATH to the PYTHON process %d", pid);
        
        EndPythonPreload:
            if (PYTHON_PATH_NEW) free(PYTHON_PATH_NEW);
        safe_free_config();
        return;
    }

    // .NET detection and handling
    else if (strcmp(__progname, "dotnet")==0 || getenv("ASPNETCORE_ENVIRONMENT")!=NULL || getenv("ASPNETCORE_URLS")!=NULL) {
        pid_t pid = getpid();
        slog_info("DOTNET process detected");
        /*set_agent_installation_path();*/
        safe_initialize_logger();
        safe_read_config();
        set_commandline_proc(pid);
        if (config.Preloader == NULL || strcmp(config.Preloader,"UNSET")==0) {
            slog_info("PRELOADER UNSET, Skipped DotNet Process Monitoring");
            safe_free_config();
            return;
        }
        
        if (!check_process_monitoring_config("DOTNET", pid)) {
            slog_info("Skipped DotNet Process Monitoring");
            safe_free_config();
            return;
        }
        char dotnetcore_clr_path[215];
        get_file_path(dotnetcore_clr_path, sizeof(dotnetcore_clr_path), "/agents/DOTNET/ApmInsightDotNetCoreAgent");
        char coreprofilerpath_64[245];
        get_file_path(coreprofilerpath_64, sizeof(coreprofilerpath_64), "/lib/DOTNET/ApmInsightDotNetCoreAgent/x64/libClrProfilerAgent.so");
        char coreprofilerpath_86[245];
        get_file_path(coreprofilerpath_86, sizeof(coreprofilerpath_86), "/lib/DOTNET/ApmInsightDotNetCoreAgent/x86/libClrProfilerAgent.so");
        char dotnet_startup_hooks[245];
        get_file_path(dotnet_startup_hooks, sizeof(dotnet_startup_hooks), "/lib/DOTNET/ApmInsightDotNetCoreAgent/netstandard2.0/DotNetAgent.Loader.dll");
        if (check_dotnet_agent_download(coreprofilerpath_64, coreprofilerpath_86, dotnet_startup_hooks)==false) {
            slog_info("DotNet Agent files are missing, Ignoring the DOTNET process with pid: %d", pid);
            safe_free_config();
            return;
        }
        set_env("DOTNETCOREAGENT_HOME", dotnetcore_clr_path, "DOTNET", pid);
        set_env("CORECLR_ENABLE_PROFILING", "1", "DOTNET", pid);
        set_env("MANAGEENGINE_COMMUNICATION_MODE", "direct", "DOTNET", pid);
        set_env("PAL_OUTPUTDEBUGSTRING", "1", "DOTNET", pid);
        set_env("CORECLR_PROFILER", "{9D363A5F-ED5F-4AAC-B456-75AFFA6AA0C8}", "DOTNET", pid);
        set_env("CORECLR_PROFILER_PATH_64", coreprofilerpath_64, "DOTNET", pid);
        set_env("CORECLR_PROFILER_PATH_32", coreprofilerpath_86, "DOTNET", pid);
        set_env("DOTNET_STARTUP_HOOKS", dotnet_startup_hooks, "DOTNET", pid);
        pass_apminsight_configurations("DOTNET", pid);
        return;
    }
    
    // Always clean up safely before exit
    safe_free_config();
    return;
}