#!/bin/bash

set -e

SERVICE_NAME="S247_eBPF_APM"
SERVICE_FILE="/etc/systemd/system/$SERVICE_NAME.service"

usage() {
  echo "Usage:"
  echo "  $0 --license_key <license_key> --exporter_ip <host> --install_dir <install_dir>"
  echo "  $0 --uninstall"
  exit 1
}

# Handle uninstall option
if [ "$1" = "--uninstall" ]; then
  echo "[+] Stopping and removing service"
  sudo systemctl stop "$SERVICE_NAME.service" || true
  sudo systemctl disable "$SERVICE_NAME.service" || true
  
  # Read the installation path from the service file
  if [ -f "$SERVICE_FILE" ]; then
    INSTALL_DIR=$(grep "ExecStart=" "$SERVICE_FILE" | sed 's/.*--install_dir \([^ ]*\).*/\1/')
    if [ -n "$INSTALL_DIR" ]; then
      echo "[+] Found installation directory: $INSTALL_DIR"
      echo "[+] Removing installation directories"
      sudo rm -rf "$INSTALL_DIR/lib/EBPF" 2>/dev/null || true
      sudo rm -rf "$INSTALL_DIR/logs/eBPF" 2>/dev/null || true
    else
      echo "[!] Could not determine installation directory from service file"
    fi
  else
    echo "[!] Service file not found, cannot determine installation directory"
  fi
  
  sudo rm -f "$SERVICE_FILE"
  
  echo "[✓] Uninstalled $SERVICE_NAME service and removed directories"
  sudo systemctl daemon-reload
  exit 0
fi

# Parse install args
while [ $# -gt 0 ]; do
  case $1 in
    --license_key)
      LICENSE_KEY="$2"
      shift 2
      ;;
    --exporter_ip)
      HOST="$2"
      shift 2
      ;;
    --install_dir)
      INSTALL_DIR="$2"
      shift 2
      ;;
    *)
      usage
      ;;
  esac
done

if [ -z "$LICENSE_KEY" ] || [ -z "$HOST" ] || [ -z "$INSTALL_DIR" ]; then
  usage
fi

# Update paths based on install directory (after parsing arguments)
BINARY_PATH="$INSTALL_DIR/lib/EBPF/Site24x7_EBPF_APM"
LOG_DIR="$INSTALL_DIR/logs/eBPF"

# 1. Prepare installation
echo "[+] Creating install directory at $INSTALL_DIR"
sudo mkdir -p "$INSTALL_DIR/lib/EBPF"
sudo mkdir -p "$LOG_DIR"
sudo cp Site24x7_EBPF_APM "$BINARY_PATH"
sudo chmod +x "$BINARY_PATH"

# 2. Create systemd service
echo "[+] Creating systemd service at $SERVICE_FILE"
sudo tee "$SERVICE_FILE" > /dev/null <<EOF
[Unit]
Description=$SERVICE_NAME
After=network.target

[Service]
Type=simple
ExecStart=$BINARY_PATH --license_key $LICENSE_KEY --exporter_ip $HOST --install_dir $INSTALL_DIR
User=root
Restart=on-failure
RestartSec=3
StandardOutput=append:$LOG_DIR/stdout.log
StandardError=append:$LOG_DIR/stderr.log

[Install]
WantedBy=multi-user.target
EOF

# 3. Reload and start service
echo "[+] Reloading systemd and enabling service"
sudo systemctl daemon-reexec
sudo systemctl daemon-reload
sudo systemctl enable "$SERVICE_NAME.service"
sudo systemctl restart "$SERVICE_NAME.service"

# 4. Show status
echo "[+] Service status:"
sudo systemctl status "$SERVICE_NAME.service" --no-pager

