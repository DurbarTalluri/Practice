package main

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"oneagent/apmlogger"
	"os"
	"os/signal"
	"syscall"
	"time"

	"gopkg.in/ini.v1"
)

var OneagentVersion = "1.0.0"
var OneagentVersionMajor = "1.0"
var logger *apmlogger.FileLog
var ApmDomain string
var ApmLicensekey string
var Apmhost string
var ApmAgentStartTime string
var ApmAgentId string
var ApmProxyUrl string
var AgentKey string
var rawLicenseKey string
var logFileName = "apm-one-agent-service.log"
var logFolderPath = "/opt/site24x7/apmoneagent/logs"
var ApmOneagentConfFilepath = "/opt/site24x7/apmoneagent/conf/oneagentconf.ini"
var OneagentConfSectionName = "ApminsightOneAgent"
var configKeyMapper = map[string]*string{
	"APMINSIGHT_LICENSEKEY":       &ApmLicensekey,
	"APMINSIGHT_AGENT_START_TIME": &ApmAgentStartTime,
	"APMINSIGHT_AGENT_ID":         &ApmAgentId,
	"APMINSIGHT_DOMAIN":           &ApmDomain,
	"APMINSIGHT_HOST":             &Apmhost,
	"APMINSIGHT_PROXY_URL":        &ApmProxyUrl,
	"AGENT_KEY":                   &AgentKey,
}

type OneagentVersionRegisterResponse struct {
	OneagentVersionRegistered bool `json:"result"`
}

var stop = make(chan os.Signal, 1)

func getPayload() string {
	payload := fmt.Sprintf("{\"agent_info\":{\"server.key\":\"%s\",\"agent.version\":%s,\"agent.version.info\":\"%s\"}}", AgentKey, OneagentVersionMajor, OneagentVersion)
	return payload
}

func getUrl() (string, error) {
	if ApmLicensekey == "" {
		return "", fmt.Errorf("empty License key")
	}
	var apm_url string
	if Apmhost != "" {
		apm_url = Apmhost
	} else {
		apm_url = "https://plusinsight.site24x7."
		if ApmDomain != "" {
			apm_url = apm_url + ApmDomain
		} else {
			apm_url = apm_url + "com"
		}
		apm_url = apm_url + ":443"
	}
	apm_url = apm_url + "/arh/oneagent_register?license.key=" + rawLicenseKey
	return apm_url, nil
}

func registerOneagentVersion() {
	logger.InfoLog("Registering Oneagent Version")
	tr := &http.Transport{
		MaxIdleConns:       10,
		IdleConnTimeout:    30 * time.Second,
		DisableCompression: true,
	}
	if ApmProxyUrl != "" {
		proxyUrl, err := url.Parse(ApmProxyUrl)
		if err != nil {
			logger.InfoLog("Error parsing proxy URL %v", err)
			stopOneagentService()
		}
		tr.Proxy = http.ProxyURL(proxyUrl)
	}
	client := &http.Client{
		Transport: tr,
		Timeout:   time.Second * 10,
	}
	payload := getPayload()
	apm_url, err := getUrl()
	if err != nil {
		logger.InfoLog("Error while generating the Apm server endpoint url %v", err)
		stopOneagentService()
	}

	sleep_time := 300 * time.Second
	retry_start_time := time.Now()
	go func() {
		for {
			logger.InfoLog("Started the Oneagent Version Registration goroutine")
			req, err := http.NewRequest("POST", apm_url, bytes.NewBuffer([]byte(payload)))
			if err != nil {
				logger.InfoLog("Error while creating request object: %v", err)
			}
			req.Header.Set("Content-Type", "application/json")
			logger.InfoLog("Attempting http request to %s with payload %s", apm_url, payload)
			resp, err := client.Do(req)
			if (resp != nil) && (resp.StatusCode == http.StatusOK) {
				defer resp.Body.Close() // Ensure the response body is closed after reading
				bodyBytes, err := io.ReadAll(resp.Body)
				if err != nil {
					logger.InfoLog("Error while reading response body: %v", err)
				}
				var response OneagentVersionRegisterResponse
				err = json.Unmarshal(bodyBytes, &response)
				if err != nil {
					logger.InfoLog("Failed to parse response JSON: %v", err)
				}
				if response.OneagentVersionRegistered {
					logger.InfoLog("Successfully registered Oneagent version")
					break
				} else {
					logger.InfoLog("Oneagent version registration unsuccessful")
				}
			}
			logger.InfoLog("Failed to register Oneagent version %v", err)
			logger.InfoLog("Received response code: %d", resp.StatusCode)
			time.Sleep(sleep_time)
			cur_time := time.Now()
			dur_since_first_retry := int(cur_time.Sub(retry_start_time).Minutes())
			if dur_since_first_retry < 360 {
				continue
			} else if dur_since_first_retry < 720 {
				sleep_time = 600
			} else if dur_since_first_retry < 1440 {
				sleep_time = 1800
			} else if dur_since_first_retry < 4320 {
				sleep_time = 3600
			} else {
				break
			}
		}
	}()
}

func startLogger() {
	logger = apmlogger.InitFileLogger(logFileName, logFolderPath, apmlogger.Info)
	err := logger.Start()
	if err != nil {
		fmt.Println("Unable to initialize logger: ", err)
		close(stop)
		os.Exit(0)
	}
	logger.InfoLog("Started Apminsight Oneagent Linux Service")
}

func readOneagentConfig() {
	if _, err := os.Stat(ApmOneagentConfFilepath); os.IsNotExist(err) {
		logger.InfoLog("Configuration file oneagentconf.ini not found.")
		stopOneagentService()
	}
	cfg, err := ini.Load(ApmOneagentConfFilepath)
	if err != nil {
		logger.InfoLog("Failed to load Apminsight Oneagent configuration file: %v", err)
		stopOneagentService()
	}
	logger.InfoLog("Successfully loaded Apminsight Oneagent configuration file")
	if !cfg.HasSection(OneagentConfSectionName) {
		logger.InfoLog("Section %s does not exist", OneagentConfSectionName)
		stopOneagentService()
	}
	OneagentConfSection := cfg.Section(OneagentConfSectionName)
	for configKey, ref := range configKeyMapper {
		if OneagentConfSection.HasKey(configKey) {
			*ref = string(cfg.Section(OneagentConfSectionName).Key(configKey).String())
		}
	}
	if (ApmLicensekey == "") || (ApmAgentStartTime == "") || (ApmAgentId == "") || (AgentKey == "") {
		logger.InfoLog("Some mandatory config is missing. Aboring the service")
		stopOneagentService()
	}
	logger.InfoLog("Successfully read configuration options from oneagentconf.ini file")
}

func DecryptLicenseKey() {
	block, err := aes.NewCipher([]byte(ApmAgentStartTime))
	if err != nil {
		logger.InfoLog("Error while decrypting License key %v", err)
		stopOneagentService()
	}

	// Decode the base64-encoded encrypted string
	ciphertext, err := base64.StdEncoding.DecodeString(ApmLicensekey)
	if err != nil {
		logger.InfoLog("Error while decrypting License key %v", err)
		stopOneagentService()
	}

	if len(ciphertext) < aes.BlockSize {
		logger.InfoLog("Error while decrypting License key: ciphertext too short")
		stopOneagentService()
	}

	stream := cipher.NewCBCDecrypter(block, []byte(ApmAgentId))

	plaintext := make([]byte, len(ciphertext))
	stream.CryptBlocks(plaintext, ciphertext)

	// Unpadding
	padding := int(plaintext[len(plaintext)-1])
	plaintext = plaintext[:len(plaintext)-padding]

	rawLicenseKey = string(plaintext)
}

func HandleOneagentConfig() {
	readOneagentConfig()
	DecryptLicenseKey()
}

func gracefulShutdown() {
	// Cleanup logic here
	logger.InfoLog("Cleaning up resources...")
	close(stop)
	logger.InfoLog("Apminsight Oneagent Linux Service stopped gracefully.")
	logger.Stop()
	os.Exit(0)
}

func setPreloader() error {
	cfg, err := ini.Load(ApmOneagentConfFilepath)
	if err != nil {
		return fmt.Errorf("failed to load ApmOneagentConfFilepath file: %w", err)
	}

	// Modify a specific field in a section
	cfg.Section(OneagentConfSectionName).Key("PRELOADER").SetValue("SET")

	// Save the changes back to the file
	err = cfg.SaveTo(ApmOneagentConfFilepath)
	if err != nil {
		return fmt.Errorf("failed to save ApmOneagentConfFilepath file: %w", err)
	}

	logger.InfoLog("INI file updated successfully, Preloader Set")
	return nil
}

func startOneagentService() {
	fmt.Println("Starting ApminsightOneagentLinux service...")
	err := setPreloader()
	if err != nil {
		logger.InfoLog("Error while linking Oneagent library to Dynamic Loader %v", err)
		stopOneagentService()
	} else {
		HandleOneagentConfig()
		registerOneagentVersion()
	}

}

func stopPreloader() error {
	cfg, err := ini.Load(ApmOneagentConfFilepath)
	if err != nil {
		return fmt.Errorf("failed to load ApmOneagentConfFilepath file: %w", err)
	}

	// Modify a specific field in a section
	cfg.Section(OneagentConfSectionName).Key("PRELOADER").SetValue("UNSET")

	// Save the changes back to the file
	err = cfg.SaveTo(ApmOneagentConfFilepath)
	if err != nil {
		return fmt.Errorf("failed to save ApmOneagentConfFilepath file: %w", err)
	}

	logger.InfoLog("INI file updated successfully, Preloader Unset")
	return nil
}

func stopOneagentService() {
	fmt.Println(("Stopping ApminsightOneagentLinux service..."))
	err := stopPreloader()
	if err != nil {
		logger.InfoLog("Error while delinking Oneagent library to Dynamic Loder %v", err)
	}
	gracefulShutdown()
}

func main() {
	signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)
	startLogger()
	command := os.Args[1]

	switch command {
	case "start":
		startOneagentService()
	case "stop":
		stopOneagentService()
	}

	<-stop
	stopOneagentService()
}
