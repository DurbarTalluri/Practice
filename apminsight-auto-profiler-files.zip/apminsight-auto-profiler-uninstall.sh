#!/bin/sh
APMINSIGHT_BRAND="Site24x7"
DATAEXPORTER_NAME="S247DataExporter"
APMINSIGHT_BRAND_LCASE=$(echo "$APMINSIGHT_BRAND" | sed 's/[A-Z]/\L&/g')
APMINSIGHT_BRAND_UCASE=$(echo "$APMINSIGHT_BRAND" | sed 's/[a-z]/\U&/g')
AGENT_INSTALLATION_PATH="/opt/$APMINSIGHT_BRAND/apminsight"
AGENT_ROOT_DIR="/opt/$APMINSIGHT_BRAND"
APMINSIGHT_SERVICE_FILE="$APMINSIGHT_BRAND_LCASE""apmautoprofiler.service"
APMINSIGHT_PRELOADER_FILENAME="lib"$APMINSIGHT_BRAND_LCASE"apmautoprofilerloader.so"
APMINSIGHT_USER="$APMINSIGHT_BRAND_LCASE-user"
UNINSTALL_SCRIPT_DIRECTORY_PATH="$(dirname "$(readlink -f "$0")")"
INSTALL_LOG_FILE_PATH="$(echo "$UNINSTALL_SCRIPT_DIRECTORY_PATH" | sed 's/\/bin//')/logs/apminsight-auto-profiler-install.log"

if [ -f "$INSTALL_LOG_FILE_PATH" ]; then
    exec >>"$INSTALL_LOG_FILE_PATH" 2>&1
fi
Log() {
    if [ -n "$1" ]; then
        echo $(date +"%F %T.%N") " $1\n"
    fi
}

Log "UNINSTALLING ApminsightAutoProfiler"
Log "$(sed -i "\|$APMINSIGHT_PRELOADER_FILENAME|d" /etc/ld.so.preload 2>&1)"
Log "$(sed -i "\|$APMINSIGHT_BRAND_UCASE|d" /etc/environment 2>&1)"
cd "$UNINSTALL_SCRIPT_DIRECTORY_PATH"
cd ../../../
Log "$(sh /opt/$DATAEXPORTER_NAME/bin/service.sh uninstall 2>&1)"
Log "$(rm -r /opt/$DATAEXPORTER_NAME 2>&1)"
Log "$(rm /lib/$APMINSIGHT_PRELOADER_FILENAME 2>&1)"
Log "$(pip uninstall --yes apminsight 2>&1)"
Log "$(systemctl stop $APMINSIGHT_SERVICE_FILE 2>&1)"
Log "$(systemctl disable $APMINSIGHT_SERVICE_FILE 2>&1)"
Log "$(rm /etc/systemd/system/$APMINSIGHT_SERVICE_FILE 2>&1)"
if grep -q '\b'$APMINSIGHT_USER'\b' /etc/sudoers; then
    Log "$(sudo sed -i '/\b'$APMINSIGHT_USER'\b/d' /etc/sudoers 2>&1)"
fi
Log "$(systemctl daemon-reload 2>&1)"
Log "$(mv $INSTALL_LOG_FILE_PATH "$(echo "$UNINSTALL_SCRIPT_DIRECTORY_PATH" | sed 's/\/apminsight\/bin//')/" 2>&1)"
Log "$(rm -r $APMINSIGHT_BRAND_LCASE/apminsight 2>&1)"