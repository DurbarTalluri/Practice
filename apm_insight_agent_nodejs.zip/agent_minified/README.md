# APM Insight for Node.js monitoring - ManageEngine Applications Manager

Monitor and optimize your Node.js application performance with Applications Manager's APM Insight agent. This agent helps you to monitor, troubleshoot and diagnose performance issues by providing code-level visibility of your Node.js applications, and captures every transaction that occurs over all the tiers of your Node.js architecture. It provides you with information on your application's response time, throughput, database operations, errors, etc., and aids you in tracking these metrics over time to identify and optimize them for enhanced performance.

Before you can use an APM Insight agent to monitor metrics, you need to install [ManageEngine Applications Manager][1] in your system.

## Table of contents:
* Installing an APM Insight agent
* Performance Metrics
* Resources
 
## Installing an APM Insight agent in Node.js
* Navigate to your Node.js application directory in terminal.
* Use the following command to install an APM Insight Node.js agent. This will create apminsight directory under 'node_modules'.
`npm i apminsight --save`
* Include the following code in the first line of your Node.js application source code, before any other require statement. Replace the variables with the values for your setup. 
```
  require('apminsight')({
  	licenseKey : '[LICENSE-KEY]',
  	appName : '[APPLICATION-NAME]',
  	port : [APPLICATION-PORT],
  	apmHost: '[APM-HOST-NAME]',
  	apmPort: [APM-SSL-PORT]
})
```
* If you use proxy connections, enter this code instead.
```
  require('apminsight')({
  	licenseKey : '[LICENSE-KEY]',
  	appName : '[APPLICATION-NAME]',
  	port : [APPLICATION-PORT],
  	apmHost: '[APM-HOST-NAME]',
  	apmPort: [APM-SSL-PORT]
  	proxyServerHost : '[PROXY-SERVER]',
  	proxyServerPort : [PROXY-PORT],
  	proxyAuthUser : '[PROXY-USERNAME]',
  	proxyAuthPassword : '[PROXY-PASSWORD]'
})
```
* Ensure that you have configured all necessary parameters.
* **Note:** You can find your license key by logging into Applications Manager, navigating to 'APM Insight' tab and then copying the License Key present in the helpcard.
* Save the file and restart your application.

## Performance Metrics

* **Components overview:** View external components connected with your application, as well as the number of ongoing and failed requests. The response time taken by each component is also tracked and shown here.

* **Apdex score:** The [Apdex score][2] serves as a direct translation of your customers' satisfaction. The score ranges from 0 to 1, with a value closer to 0 denoting frustrated users and closer to 1 denoting the maximum level of satisfaction.

* **Average Response time:** The Average response time gives you an overview of the time taken by your app to respond to a request.

* **Web transactions:** Transactions for a chosen time period are shown here along with their recent traces, including error transactions, error components, response time, throughput and HTTP components.

* **Database operations:** Database operations shows all database operations along with their count and throughput time.

* **Trace details:** Shows detailed timeline of method calls, database queries and other external compomonents. 

## Resources

Refer to our [help documentation][3] to learn more on working with APM Insight agent for Node.js monitoring in Applications Manager.

[1]: https://www.manageengine.com/products/applications_manager/download.html
[2]: https://www.manageengine.com/products/applications_manager/help/apdex-score.html
[3]: https://www.manageengine.com/products/applications_manager/help/nodejs-monitoring.html

