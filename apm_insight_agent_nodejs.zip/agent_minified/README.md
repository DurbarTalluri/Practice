# Site24x7 APM Insight for Node.js

Monitor and optimize your Node.js application performance with a Site24x7 APM Insight agent. This agent provides you information on your application's response time, throughput, database operations, and errors. Track these metrics over time to identify where to optimize them for enhanced performance.

Before you can use an APM Insight agent to monitor metrics, you need a [Site24x7 account.][1]

To install APM Insight Node.js agent, follow the below given instructions.

## Table of contents:
* Installation steps for Node.js agent v4.0 and above
* Installation steps for Node.js agents v2.x and v3.x
* Performance Metrics
 
## Installation steps for Node.js agent v4.o and above
* Open your Node.js application.
* Access the node package manager (NPM).
* Use the following command to install an APM Insight Node.js agent from NPM. This will create a directory named apminsight under node_modules.
`npm i apminsight --save`
* You can either create a file and add the configuration values to it, or you can set the configuration values as environment variables.
    * Create a new file named apminsightnode.json and place it in the directory where you run the application. Add the below code snippet to the file.   
     ```
        {"licenseKey" : "<license-key>",
         "appName" : "<application-name>",
         "port" : <application-port> }
    ```
    If you use proxy connections, enter this code instead.
    ```
        {"licenseKey" : "<license-key>",
        "appName" : "<application-name>",
        "port" : <application-port>,
        "proxyServerHost" : "<proxy-server>",
        "proxyServerPort" : <proxy-port>,
        "proxyAuthUser" : "<proxy-user-name>",
        "proxyAuthPassword" : "<proxy-password>"}
    ```
    * You can set configuration values as environment variables using the following keys:
    licenseKey - APMINSIGHT_LICENSE_KEY
    appName - APMINSIGHT_APP_NAME
    port - APMINSIGHT_PORT
    proxyServerHost - APMINSIGHT_PROXYSERVER_HOST
    proxyServerPort - APMINSIGHT_PROXYSERVER_PORT
    proxyAuthUser - APMINSIGHT_PROXYAUTH_USER
    proxyAuthPassword - APMINSIGHT_PROXYAUTH_PASSWORD
* Include the given code in the first line of your Node.js application start file, before any other require statements.

    If using Common JS:
    ```
        require('apminsight');
    ```
    If using ES:
    ```
        import apminsight from 'apminsight';
    ```
    If using TypeScript:
    ```
        import AgentAPI from  'apminsight';
        AgentAPI.config();
    ```
    You can alternatively follow any of the methods below, which are common across all JavaScript types.
    Using environmental variable:
    ```
    export NODE_OPTIONS="-r apminsight"
    ```
    Include the require statement in the start script or when you start your application. 
    ```
    node -r apminsight my-start-file.js
    ```
> Note: 
* -r is used to pre-load the specified module (apminsight module here) at startup.
* Only CommonJS modules support -r. Use --import to pre-load a TypeScript or ECMAScript module.

* Optional: For additional Node.js runtime-level statistics, ensure the [@apminsight/native-stats][2] package is installed.
* Restart your application and perform a few transactions to view data in the APM Insight client. 


## Installation steps for Node.js agents v2.x and v3.x
We highly recommend you download the latest version of the APM Insight Node.js agent. However, if you need to download agent versions v2.x or v3.x for some reason, kindly refer to the [help documentation][3] for the installation steps. 

## Performance Metrics
* **Apdex score:** The Apdex score serves as a direct translation of your customers' satisfaction. The score ranges from 0 to 1, with a value closer to 0 denoting frustrated users and closer to 1 denoting the maximum level of satisfaction.

* **Average Response time:** The Average response time gives you an overview of the time taken by your app to respond to a request.

* **Components overview:** [View external components connected with your application][4], as well as the number of ongoing and failed requests. The response time taken by each component is also tracked and shown here.

* **Web transactions:** Transactions for a chosen time period are shown here along with their recent traces, including error transactions, error components, response time, throughput and HTTP components.

* **Database operations:** Database operations shows all database operations along with their count and throughput time.

* **Trace details:** Shows detailed timeline of method calls, database queries and other external compomonents. 

* **RUM integration:** [Integrate your Node.js application with Site24x7 real user monitoring][5] (RUM) to get real-time data, including browser details, JS errors, Ajax calls, and region-specific performance of your application.

[1]: https://www.site24x7.com/application-performance-monitoring.html
[2]: https://www.npmjs.com/package/@apminsight/native-stats
[3]: https://www.site24x7.com/help/apm/nodejs-agent/Install-Node.js-Agent.html#below4.x
[4]: https://www.site24x7.com/application-dependency-maps.html
[5]: https://www.site24x7.com/help/apm/rum.html