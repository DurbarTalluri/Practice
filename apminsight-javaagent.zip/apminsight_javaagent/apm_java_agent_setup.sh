#!/bin/bash

PATH=/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin:.
OS_BINARY_TYPE=''
OS_NAME=`uname -s`
OS_ARCH=`uname -m`
SUCCESS=0
WARNING=1
FAILURE=2
BOOL_TRUE='True'
BOOL_FALSE='False'
ECHO_PRINT=5
PRODUCT_NAME='Site24x7 APM Insight'

NONROOT_INSTALLATION='0'

#LOCAL_SETUP=$BOOL_TRUE
LOCAL_SETUP=$BOOL_FALSE

#local
LOCAL_SERVER='http://build/me/me_agent/webhost/giri7_branch/Feb_22_2018_3/scripts'

#livebuild
SERVER='https://staticdownloads.site24x7.com/apminsight/agents'
AGENT_INSTALL_FILE='apminsight-javaagent.zip'

DOWNLOAD_URL=""

print_green() {
    printf "\033[32m%s\033[0m\n" "$*"
}

print_console() {
    printf "%s\n" "$*"
}

print_red() {
    printf "\033[31m%s\033[0m\n" "$*"
}


print_done() {
    print_green "Done"
}

`command -v which 2>/dev/null 1>/dev/null`
if [ $? = 0 ]; then
    COMMAND_CHECKER="which"
else
    COMMAND_CHECKER="command -v"
fi

if [ $(command -v curl) ]; then
    DOWNLOAD_CMD="curl -Lo"
    print_green "curl detected"
elif [ $(command -v wget) ]; then
        DOWNLOAD_CMD="wget -O"
        print_green "wget detected"
else
    DOWNLOAD_CMD=''
    print_red "Both curl and wget not present hence exiting"
    exit $FAILURE
fi

log() {
	if [ "$1" = "$ECHO_PRINT" ]; then
		echo "$2"
	fi
}

command_test() {
    $COMMAND_CHECKER $1 2>/dev/null 1>/dev/null
    if [ $? -ne 0 ]; then
    	ERROR_MSG=$ERROR_MSG" $1"
    	SEVERE_FLAG=$BOOL_TRUE
    fi
}

utilityCheck() {
	ERROR_MSG='Please install the following utility : '
	SEVERE_FLAG=$BOOL_FALSE
	command_test awk "mandatory"
	command_test sed "mandatory"
	command_test unzip "mandatory"
 	if [ "$SEVERE_FLAG" = "$BOOL_TRUE" ]; then
 		print_red $ERROR_MSG
 		exit $FAILURE
 	fi
}

detectOs(){
	if [ "$OS_NAME" = "Linux" ]; then
		print_green "detected os is linux"
	else
		IS_VENV_SUPPORT_NEEDED=$BOOL_TRUE
	fi
	print_green "Detected OS : $OS_NAME"
}

format_version() {
        echo "$@" | awk -F. '{ printf("%03d%03d%03d\n", $1,$2,$3); }';
}

checkShellUtility(){
	if command -v bash; then
    	SHELL_UTILITY="bash"
    else
    	SHELL_UTILITY="sh"
    fi
}

checkForBinSupport(){
	checkShellUtility
	detectOs
}

setDownloadUrl() {
	if [ "$LOCAL_SETUP" = "$BOOL_TRUE" ]; then
		DOWNLOAD_URL="$LOCAL_SERVER/$AGENT_INSTALL_FILE"
	else
		DOWNLOAD_URL="$SERVER/$AGENT_INSTALL_FILE"
	fi
	print_green "Download url : $DOWNLOAD_URL"
}

isRootUser() {
	if [ "$NONROOT_INSTALLATION" = "1" ]; then
		SUDO=''
	elif [ "$(id -u)" != "0" ]; then
		SUDO="sudo -E"
        fi
}

setInstallDir() {
	if [ "$APPLICATION_NAME" == "" ] && [ "$APP_SERVER_PORT" == "" ]; then
		print_red "Application name and port number is not provided. Provide any one for successfull installation"
		exit $FAILURE
	else
		if [ "$APPLICATION_NAME" != "" ]; then
			INSTALL_LOCATION+="$APPLICATION_NAME"
		elif [ "$APP_SERVER_PORT" != "" ]; then
			INSTALL_LOCATION+="$APP_SERVER_PORT"
		else
			INSTALL_LOCATION+=''
		fi
	fi
}

createDirIfNotExists() {
	if [ -d "$1" ]; then
		print_red "APM Insight agent already installed"
		exit $FAILURE
	else
		$SUDO mkdir -p "$1"
		if [ "$?" != "0" ]; then
			print_red "Error creating directory $1"
			exit $FAILURE
		fi
	fi
	print_green "Installing agent in $1"
}

installAgent() {
	isRootUser
	utilityCheck
	checkForBinSupport
	setDownloadUrl
	echo ""
	echo "      +---------------------------------------------------------------------------------------------------------------------------------------------------+"
	echo "      |																			  |"	
	echo "      |							      Site24x7 APM Insight Java Agent Installation 	  				          |"
	echo "      |																			  |"
	echo "      +---------------------------------------------------------------------------------------------------------------------------------------------------+"
	echo ""	
	echo ""
	
	setInstallDir
	createDirIfNotExists "$INSTALL_LOCATION"
	$SUDO $DOWNLOAD_CMD $AGENT_INSTALL_FILE $DOWNLOAD_URL
	print_green "Agent downloaded successfully"

	$SUDO unzip -oq $AGENT_INSTALL_FILE -d $INSTALL_LOCATION

	$SUDO chmod -R 777 $INSTALL_LOCATION
	if [ $? != 0 ]; then
		print_red "Error in providing permissions for directory $INSTALL_LOCATION"
		exit $FAILURE
	fi

	$SUDO rm -f $AGENT_INSTALL_FILE

	$SUDO sed -i -e "s/license.key=.*/license.key=$AGENT_LICENSE_KEY/g" $INSTALL_LOCATION/apminsight.conf
	if [ "$APPLICATION_NAME" != "" ]; then
		$SUDO sed -i -e "s/application.name=.*/application.name=$APPLICATION_NAME/g" $INSTALL_LOCATION/apminsight.conf
	fi

	if [ "$APP_SERVER_PORT" != "" ]; then
		$SUDO sed -i -e "s/agent.server.port=.*/agent.server.port=$APP_SERVER_PORT/g" $INSTALL_LOCATION/apminsight.conf
	fi

	if [ "$AGENT_PROXY_DETAILS" != "" ]; then
		PROXY_USER=`echo $AGENT_PROXY_DETAILS | awk -F@ '{print $1}' | awk -F: '{print $1}'`
		PROXY_PSWD=`echo $AGENT_PROXY_DETAILS | awk -F@ '{print $1}' | awk -F: '{print $2}'`
		PROXY_HOST=`echo $AGENT_PROXY_DETAILS | awk -F@ '{print $2}' | awk -F: '{print $1}'`
		PROXY_PORT=`echo $AGENT_PROXY_DETAILS | awk -F@ '{print $2}' | awk -F: '{print $2}'`

		$SUDO sed -i -e "s/behind.proxy=.*/behind.proxy=true/g" $INSTALL_LOCATION/apminsight.conf
		$SUDO sed -i -e "s/#proxy.server.host=.*/proxy.server.host=$PROXY_HOST/g" $INSTALL_LOCATION/apminsight.conf
		$SUDO sed -i -e "s/#proxy.server.port=.*/proxy.server.port=$PROXY_PORT/g" $INSTALL_LOCATION/apminsight.conf
		$SUDO sed -i -e "s/#proxy.auth.username=.*/proxy.auth.username=$PROXY_USER/g" $INSTALL_LOCATION/apminsight.conf
		$SUDO sed -i -e "s/#proxy.auth.password=.*/proxy.auth.password=$PROXY_PSWD/g" $INSTALL_LOCATION/apminsight.conf
	fi
	print_green "APM Insight agent installation complete"
	print_green "Please add \"-javaagent:$INSTALL_LOCATION/apminsight-javaagent.jar\" parameter to your application JVM arguments and restart the application"
	print_done
}

usage() {
	log $ECHO_PRINT ""
	log $ECHO_PRINT "Usage :"
	log $ECHO_PRINT '	Install command   : bash -c "$(curl -sL https://staticdownloads.site24x7.com/server/APMInstallScript.sh)" readlink [options] -key=<device_key> -sp=<app_server_path>'
	log $ECHO_PRINT ""	
	log $ECHO_PRINT "Options:"
	log $ECHO_PRINT "	-h                            Print usage information"
	log $ECHO_PRINT "	-proxy                        Set proxy to connect to the site24x7 server, if needed. For example -proxy=username:password@host:port, if there is no username and passowrd for proxy server then use -proxy=host:port"
	log $ECHO_PRINT "	-port                         Port number(any) in which the application is running. Default 8080"
	log $ECHO_PRINT "	-an,-AN                       Display name of the server"
#	log $ECHO_PRINT "	-sp,-SP                       Application server path"
	log $ECHO_PRINT ""
	exit $FAILURE
}

parseInput() {
	while [ "$1" != "" ]; do
        	PARAM=`echo $1 | awk -F= '{print $1}'`
        	VALUE=`echo $1 | awk -F= '{print $2}'`
        	case $PARAM in
			-h|--help)
				usage
				;;
			# -nr|-nonroot)
			# 	NONROOT_INSTALLATION='1'
			# 	;;
			# -path)
			# 	INSTALL_LOCATION=$VALUE
			# 	INSTALL_LOCATION+='/apminsight/'
			# 	;;
			-key)
				AGENT_LICENSE_KEY=$VALUE
				;;
			-proxy)
				AGENT_PROXY_DETAILS=$VALUE
				;;
			-port)
				APP_SERVER_PORT=$VALUE
				;;
			-an|-AN)
				APPLICATION_NAME=$VALUE
				;;
			-sp|-SP)
				APP_SERVER_PATH=$VALUE
				;;
			*)
				log $ECHO_PRINT ""
                log $ECHO_PRINT "Unknown installation parameter : $PARAM"
                usage
            	;;
		esac
		shift
	done
	if [ "$AGENT_LICENSE_KEY" = "" ] || [ "$APP_SERVER_PATH" = "" ]; then
		usage
	else
		NONROOT_INSTALLATION='1'
		INSTALL_LOCATION="$HOME/apminsight/"
		installAgent
		printf "\n"
	fi
}

main() {
	parseInput "$@"
}

main "$@"
