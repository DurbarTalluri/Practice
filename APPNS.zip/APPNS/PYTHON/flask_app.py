from flask import Flask

res = '''{
  "apm_agents_download_info": {
    "JAVA": {
      "agent_version": "7.4.0",
      "agent_download_url": "https://raw.githubusercontent.com/DurbarTalluri/Practice/main/apminsight-javaagent.zip",
      "agent_checksum_val": "1ae43ecb7a7d09d6d3b79c7f072966a6177947d1c69279acb48a765db7103786"
    },
    "PYTHON": {
      "agent_version": "1.6.3",
      "agent_download_url": "https://raw.githubusercontent.com/DurbarTalluri/Practice/main/apm_insight_agent_python.zip",
      "agent_checksum_url": "https://raw.githubusercontent.com/DurbarTalluri/Practice/main/apm_insight_agent_python.zip.sha256"
    },
    "NODEJS": {
      "agent_version": "5.0.0",
      "agent_download_url": "https://raw.githubusercontent.com/DurbarTalluri/Practice/main/apm_insight_agent_nodejs.zip",
      "agent_checksum_val": "d8864e9d68f6f82db61bc686c382b4e2f96cd3afc9dc02a55915aea843c138ca"
    },
    "DOTNET": {
      "agent_version": "1.0.1",
      "agent_version_info": "1.0.1",
      "agent_download_url": "https://raw.githubusercontent.com/DurbarTalluri/Practice/main/apminsight-dotnetcoreagent-linux.sh",
      "agent_checksum_val": "df2d22e9ace93f14d9b1ef753afdd41623718303d1a5aafb69d7c719552f95b9"
    },
    "DATAEXPORTER": {
      "agent_version": "1.8.1",
      "agent_download_url": "https://staticdownloads.site24x7.com/apminsight/S247DataExporter/linux/InstallDataExporter.sh",
      "agent_checksum_val": "9a7cfed1124762bb2706ef0ceb7524b63050c4b5cdac75ad30397ec4da298f53"
    },
    "EBPF": {
      "agent_version": "1.0.0",
      "agent_version_info": "1.0.0",
      "agent_download_url": "https://raw.githubusercontent.com/DurbarTalluri/Practice/main/Site24x7_EBPF_APM.zip",
      "agent_checksum_val": "f6565f1dedc89dee7c860f78064cd29b1812bf7a931fd051cc6e8580dca53f71"
    }
  },
  "process_monitoring_profile": {
    "process_monitoring_rules": [
      {
        "process_monitoring_conditions": [
          {
            "monitoring_condition_operator": "contains",
            "monitoring_condition_parameter": "command",
            "monitoring_condition_parameter_value": "python3"
          }
        ],
        "process_monitoring_status": "monitor",
        "ebpf_enabled": true
      },
      {
        "process_monitoring_conditions": [
          {
            "monitoring_condition_operator": "is",
            "monitoring_condition_parameter": "command",
            "monitoring_condition_parameter_value": "java"
          }
        ],
        "process_monitoring_status": "monitor",
        "ebpf_enabled": true
      },
      {
        "process_monitoring_conditions": [
          {
            "monitoring_condition_operator": "contains",
            "monitoring_condition_parameter": "command",
            "monitoring_condition_parameter_value": "node"
          },
          {
            "monitoring_condition_operator": "contains",
            "monitoring_condition_parameter": "commandline",
            "monitoring_condition_parameter_value": "index"
          }
        ],
        "process_monitoring_status": "monitor"
      },
      {
        "process_monitoring_conditions": [
          {
            "monitoring_condition_operator": "contains",
            "monitoring_condition_parameter": "command",
            "monitoring_condition_parameter_value": "python3"
          },
          {
            "monitoring_condition_operator": "contains",
            "monitoring_condition_parameter": "commandline",
            "monitoring_condition_parameter_value": "a"
          }
        ],
        "process_monitoring_status": "monitor"
      },
      {
        "process_monitoring_conditions": [
          {
            "monitoring_condition_operator": "contains",
            "monitoring_condition_parameter": "command",
            "monitoring_condition_parameter_value": "a"
          },
          {
            "monitoring_condition_operator": "contains",
            "monitoring_condition_parameter": "commandline",
            "monitoring_condition_parameter_value": "as"
          }
        ],
        "process_monitoring_status": "monitor"
      },
      {
        "process_monitoring_conditions": [
          {
            "monitoring_condition_operator": "contains",
            "monitoring_condition_parameter": "command",
            "monitoring_condition_parameter_value": "a"
          }
        ],
        "process_monitoring_status": "monitor"
      }
    ],
    "process_monitoring_groups": {
      "PYTHON-/home/durbar-11363/Documents/archive/ONEAGENT_INTEGRATION/MOCK_SERVER-python3 app.py": "monitor",
      "PYTHON-/home/durbar-11363/Documents/archive/ONEAGENT_INTEGRATION/APPNS/PYTHON-python3 flask_app.py": "monitor"
    }
  }
}'''
application = Flask(__name__)

@application.route('/arh/autoprofiler_register', methods=['GET', 'POST'])
def simple():
    return res
@application.route('/', methods=['GET', 'POST'])
def index():
    res = {"resuolt":True}
    return res
if __name__ == '__main__':

    application.run(host='0.0.0.0',debug = False, port=5000)