$w3svcRegistryPath = "HKLM:\SYSTEM\CurrentControlSet\Services\W3SVC"
$wasRegistryPath = "HKLM:\SYSTEM\CurrentControlSet\Services\WAS"
$environmentKey = "Environment"
$global:isDotNetAgentExists = 0;
$global:isGlobalInstall = 0;

	
Function RemoveEnvironmentSetting([string]$registryPath, [string]$name)
{
	$exists = 0;
	
	try {
		Get-ItemProperty -Path $registryPath | Select-Object -ExpandProperty $name -ErrorAction Stop | Out-Null	
		$exists = 1;
	}
	catch {
		$exists = 0;
	}
	
	$isDotNetAgentRunning = 0;
	$serviceName = 'apminsightdotnetagent'
	
	if (Get-Service $serviceName -ErrorAction SilentlyContinue)	
	{
		$global:isDotNetAgentExists = 1;
		$objService = Get-Service $serviceName;
		if ($objService.Status -eq 'Running')
		{
			$isDotNetAgentRunning = 1;
		}
	}

	if ($exists -eq 1) {
		try {
			$environmentString = (Get-ItemProperty -Path $registryPath -Name $name).Environment;
			$newEnvironmentValue = @();
			ForEach ($line in $($environmentString -split "`r`n")) {
				if($line.Contains("CORECLR_ENABLE_PROFILING=")) {
					continue; }
				elseif ($line.Contains("CORECLR_PROFILER=")) {
					continue; }
				elseif ($line.Contains("CORECLR_SITE24X7_HOME=")) {
					continue; }
				elseif ($line.Contains("CORECLR_PROFILER_PATH_64=")) {
					continue; }
				elseif ($line.Contains("CORECLR_PROFILER_PATH_32=")) {
					continue; }
							
				elseif ($line.Contains("COR_ENABLE_PROFILING=")) 
				{
					if ($global:isDotNetAgentExists -eq 1)
					{
						if ($isDotNetAgentRunning -eq 1)
						{
						
							$newEnvironmentValue += "COR_ENABLE_PROFILING=1"
						}
						else
						{
							$newEnvironmentValue += "COR_ENABLE_PROFILING=0"
						}
						continue; 
					}
					else
					{
						continue; 
					}
				}
				elseif ($line.Contains("COR_PROFILER=")) 
				{
					if ($global:isDotNetAgentExists -eq 1)
					{
						$newEnvironmentValue += "COR_PROFILER={989D151B-3F31-482E-926F-2E95D274BD36}"
						continue; 
					}
					else
					{
						continue; 
					}
				}
					
				elseif ($line.Contains("COR_PROFILER_PATH_64=")) {
					continue; }
				elseif ($line.Contains("COR_PROFILER_PATH_32=")) {
					continue; }
				elseif ($line.Contains("DOTNET_ADDITIONAL_DEPS=")) {
					continue; }
				elseif ($line.Contains("DOTNET_SHARED_STORE=")) {
					continue; }
				elseif ($line.Contains("S247_LICENSE_KEY=")) {
					continue; }
				elseif ($line.Contains("SITE24X7_APP_NAME=")) {
					continue; }
				else {
					$newEnvironmentValue += $line; }
			}
			
			if($newEnvironmentValue.length -eq 0)
			{
				RemoveRegistryItem $registryPath $name
			}
			else
			{
				CreateNewRegistryItem $registryPath $name $newEnvironmentValue
			}
		}
		catch {
			WRITE-WARNING "Failed modifying environment variable. Please contact support."
		}
	}
}

Function CreateNewRegistryItem([string]$registryPath, [string]$name, [string[]]$newRegistryValue) 
{
	New-ItemProperty -Path $registryPath `
		-Name $name `
		-Value $newRegistryValue `
		-PropertyType MultiString `
		-Force | Out-Null
}

Function RemoveRegistryItem([string]$registryPath, [string]$name) 
{
	Remove-ItemProperty -Path $registryPath -Name $name
}

Function IsAdmin() 
{
    ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
}

Function CheckAdminRights() {
    If (-Not(IsAdmin) -And ($installType -eq "global")) {
        Write-Host "You must have administrator rights to uninstall the agent. Please run this script from an elevated shell."
        exit
    }
}

Function CheckInstall() {
	# Get the value of the environment variable "CORECLR_ENABLE_PROFILING"
	$coreclrEnableProfiling = [Environment]::GetEnvironmentVariable("CORECLR_ENABLE_PROFILING", "Machine")

	# Get the value of the environment variable "CORECLR_PROFILER"
	$coreclrProfiler = [Environment]::GetEnvironmentVariable("CORECLR_PROFILER", "Machine")
	
	if($coreclrEnableProfiling -eq 1 -and $coreclrProfiler -eq "{9D363A5F-ED5F-4AAC-B456-75AFFA6AA0C8}"){
		$global:isGlobalInstall = 1;
	}
}

Write-Host "
Uninstalling .NET Core Agent..."

CheckAdminRights

if ((Test-Path -Path $w3svcRegistryPath) -and (Test-Path -Path $wasRegistryPath)) 
{
	RemoveEnvironmentSetting $w3svcRegistryPath $environmentKey
	RemoveEnvironmentSetting $wasRegistryPath $environmentKey
}

[Environment]::SetEnvironmentVariable("COR_ENABLE_PROFILING", $null)
[Environment]::SetEnvironmentVariable("COR_PROFILER", $null)

if ($global:isDotNetAgentExists -eq 0)
{
	[Environment]::SetEnvironmentVariable("COR_ENABLE_PROFILING",$null,"Machine")
	[Environment]::SetEnvironmentVariable("COR_PROFILER",$null,"Machine")
}
[Environment]::SetEnvironmentVariable("CORECLR_ENABLE_PROFILING", $null)

CheckInstall

if($global:isGlobalInstall -eq 1){
	[Environment]::SetEnvironmentVariable("CORECLR_ENABLE_PROFILING", $null, "Machine")
	[Environment]::SetEnvironmentVariable("COR_PROFILER_PATH_64",$null,"Machine")
	[Environment]::SetEnvironmentVariable("COR_PROFILER_PATH_32",$null,"Machine")
	[Environment]::SetEnvironmentVariable("CORECLR_PROFILER",$null,"Machine")
	[Environment]::SetEnvironmentVariable("CORECLR_SITE24X7_HOME",$null,"Machine")
	[Environment]::SetEnvironmentVariable("CORECLR_PROFILER_PATH_64",$null,"Machine")
	[Environment]::SetEnvironmentVariable("CORECLR_PROFILER_PATH_32",$null,"Machine")
	[Environment]::SetEnvironmentVariable("DOTNET_ADDITIONAL_DEPS",$null,"Machine")
	[Environment]::SetEnvironmentVariable("DOTNET_SHARED_STORE",$null,"Machine")
	[Environment]::SetEnvironmentVariable("S247_LICENSE_KEY",$null,"Machine")
}

Write-Host "
The APM Insight .NET Core agent is removed successfully. Restart .NET Core applications to take effect. Reset IIS if the applications are hosted in IIS.
"
# SIG # Begin signature block
# MIIzfgYJKoZIhvcNAQcCoIIzbzCCM2sCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDp04VE8/cndo3U
# 60RQ2YrO2o4YxwvDekWuNu+Ec19FbqCCGAMwggROMIIDNqADAgECAg0B7l8Wnf+X
# NStkZdZqMA0GCSqGSIb3DQEBCwUAMFcxCzAJBgNVBAYTAkJFMRkwFwYDVQQKExBH
# bG9iYWxTaWduIG52LXNhMRAwDgYDVQQLEwdSb290IENBMRswGQYDVQQDExJHbG9i
# YWxTaWduIFJvb3QgQ0EwHhcNMTgwOTE5MDAwMDAwWhcNMjgwMTI4MTIwMDAwWjBM
# MSAwHgYDVQQLExdHbG9iYWxTaWduIFJvb3QgQ0EgLSBSMzETMBEGA1UEChMKR2xv
# YmFsU2lnbjETMBEGA1UEAxMKR2xvYmFsU2lnbjCCASIwDQYJKoZIhvcNAQEBBQAD
# ggEPADCCAQoCggEBAMwldpB5BngiFvXAg7aEyiie/QV2EcWtiHL8RgJDx7KKnQRf
# JMsuS+FggkbhUqsMgUdwbN1k0ev1LKMPgj0MK66X17YUhhB5uzsTgHeMCOFJ0mpi
# Lx9e+pZo34knlTifBtc+ycsmWQ1z3rDI6SYOgxXG71uL0gRgykmmKPZpO/bLyCiR
# 5Z2KYVc3rHQU3HTgOu5yLy6c+9C7v/U9AOEGM+iCK65TpjoWc4zdQQ4gOsC0p6Hp
# sk+QLjJg6VfLuQSSaGjlOCZgdbKfd/+RFO+uIEn8rUAVSNECMWEZXriX7613t2Sa
# er9fwRPvm2L7DWzgVGkWqQPabumDk3F2xmmFghcCAwEAAaOCASIwggEeMA4GA1Ud
# DwEB/wQEAwIBBjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBSP8Et/qC5FJK5N
# UPpjmove4t0bvDAfBgNVHSMEGDAWgBRge2YaRQ2XyolQL30EzTSo//z9SzA9Bggr
# BgEFBQcBAQQxMC8wLQYIKwYBBQUHMAGGIWh0dHA6Ly9vY3NwLmdsb2JhbHNpZ24u
# Y29tL3Jvb3RyMTAzBgNVHR8ELDAqMCigJqAkhiJodHRwOi8vY3JsLmdsb2JhbHNp
# Z24uY29tL3Jvb3QuY3JsMEcGA1UdIARAMD4wPAYEVR0gADA0MDIGCCsGAQUFBwIB
# FiZodHRwczovL3d3dy5nbG9iYWxzaWduLmNvbS9yZXBvc2l0b3J5LzANBgkqhkiG
# 9w0BAQsFAAOCAQEAI3Dpz+K+9VmulEJvxEMzqs0/OrlkF/JiBktI8UCIBheh/qvR
# XzzGM/Lzjt0fHT7MGmCZggusx/x+mocqpX0PplfurDtqhdbevUBj+K2myIiwEvz2
# Qd8PCZceOOpTn74F9D7q059QEna+CYvCC0h9Hi5R9o1T06sfQBuKju19+095VnBf
# DNOOG7OncA03K5eVq9rgEmscQM7Fx37twmJY7HftcyLCivWGQ4it6hNu/dj+Qi+5
# fV6tGO+UkMo9J6smlJl1x8vTe/fKTNOvUSGSW4R9K58VP3TLUeiegw4WbxvnRs4j
# vfnkoovSOWuqeRyRLOJhJC2OKkhwkMQexejgcDCCBaIwggSKoAMCAQICEHgDGEJF
# cIpBz28BuO60qVQwDQYJKoZIhvcNAQEMBQAwTDEgMB4GA1UECxMXR2xvYmFsU2ln
# biBSb290IENBIC0gUjMxEzARBgNVBAoTCkdsb2JhbFNpZ24xEzARBgNVBAMTCkds
# b2JhbFNpZ24wHhcNMjAwNzI4MDAwMDAwWhcNMjkwMzE4MDAwMDAwWjBTMQswCQYD
# VQQGEwJCRTEZMBcGA1UEChMQR2xvYmFsU2lnbiBudi1zYTEpMCcGA1UEAxMgR2xv
# YmFsU2lnbiBDb2RlIFNpZ25pbmcgUm9vdCBSNDUwggIiMA0GCSqGSIb3DQEBAQUA
# A4ICDwAwggIKAoICAQC2LcUw3Xroq5A9A3KwOkuZFmGy5f+lZx03HOV+7JODqoT1
# o0ObmEWKuGNXXZsAiAQl6fhokkuC2EvJSgPzqH9qj4phJ72hRND99T8iwqNPkY2z
# BbIogpFd+1mIBQuXBsKY+CynMyTuUDpBzPCgsHsdTdKoWDiW6d/5G5G7ixAs0sdD
# HaIJdKGAr3vmMwoMWWuOvPSrWpd7f65V+4TwgP6ETNfiur3EdaFvvWEQdESymAfi
# dKv/aNxsJj7pH+XgBIetMNMMjQN8VbgWcFwkeCAl62dniKu6TjSYa3AR3jjK1L6h
# wJzh3x4CAdg74WdDhLbP/HS3L4Sjv7oJNz1nbLFFXBlhq0GD9awd63cNRkdzzr+9
# lZXtnSuIEP76WOinV+Gzz6ha6QclmxLEnoByPZPcjJTfO0TmJoD80sMD8IwM0kXW
# LuePmJ7mBO5Cbmd+QhZxYucE+WDGZKG2nIEhTivGbWiUhsaZdHNnMXqR8tSMeW58
# prt+Rm9NxYUSK8+aIkQIqIU3zgdhVwYXEiTAxDFzoZg1V0d+EDpF2S2kUZCYqaAH
# N8RlGqocaxZ396eX7D8ZMJlvMfvqQLLn0sT6ydDwUHZ0WfqNbRcyvvjpfgP054d1
# mtRKkSyFAxMCK0KA8olqNs/ITKDOnvjLja0Wp9Pe1ZsYp8aSOvGCY/EuDiRk3wID
# AQABo4IBdzCCAXMwDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMD
# MA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFB8Av0aACvx4ObeltEPZVlC7zpY7
# MB8GA1UdIwQYMBaAFI/wS3+oLkUkrk1Q+mOai97i3Ru8MHoGCCsGAQUFBwEBBG4w
# bDAtBggrBgEFBQcwAYYhaHR0cDovL29jc3AuZ2xvYmFsc2lnbi5jb20vcm9vdHIz
# MDsGCCsGAQUFBzAChi9odHRwOi8vc2VjdXJlLmdsb2JhbHNpZ24uY29tL2NhY2Vy
# dC9yb290LXIzLmNydDA2BgNVHR8ELzAtMCugKaAnhiVodHRwOi8vY3JsLmdsb2Jh
# bHNpZ24uY29tL3Jvb3QtcjMuY3JsMEcGA1UdIARAMD4wPAYEVR0gADA0MDIGCCsG
# AQUFBwIBFiZodHRwczovL3d3dy5nbG9iYWxzaWduLmNvbS9yZXBvc2l0b3J5LzAN
# BgkqhkiG9w0BAQwFAAOCAQEArPfMFYsweagdCyiIGQnXHH/+hr17WjNuDWcOe2LZ
# 4RhcsL0TXR0jrjlQdjeqRP1fASNZhlZMzK28ZBMUMKQgqOA/6Jxy3H7z2Awjuqgt
# qjz27J+HMQdl9TmnUYJ14fIvl/bR4WWWg2T+oR1R+7Ukm/XSd2m8hSxc+lh30a6n
# sQvi1ne7qbQ0SqlvPfTzDZVd5vl6RbAlFzEu2/cPaOaDH6n35dSdmIzTYUsvwyh+
# et6TDrR9oAptksS0Zj99p1jurPfswwgBqzj8ChypxZeyiMgJAhn2XJoa8U1sMNSz
# BqsAYEgNeKvPF62Sk2Igd3VsvcgytNxN69nfwZCWKb3BfzCCBuYwggTOoAMCAQIC
# EHe9DgOhtwj4VKsGchDZBEcwDQYJKoZIhvcNAQELBQAwUzELMAkGA1UEBhMCQkUx
# GTAXBgNVBAoTEEdsb2JhbFNpZ24gbnYtc2ExKTAnBgNVBAMTIEdsb2JhbFNpZ24g
# Q29kZSBTaWduaW5nIFJvb3QgUjQ1MB4XDTIwMDcyODAwMDAwMFoXDTMwMDcyODAw
# MDAwMFowWTELMAkGA1UEBhMCQkUxGTAXBgNVBAoTEEdsb2JhbFNpZ24gbnYtc2Ex
# LzAtBgNVBAMTJkdsb2JhbFNpZ24gR0NDIFI0NSBDb2RlU2lnbmluZyBDQSAyMDIw
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA1kJN+eNPxiP0bB2BpjD3
# SD3P0OWN5SAilgdENV0Gzw8dcGDmJlT6UyNgAqhfAgL3jsluPal4Bb2O9U8ZJJl8
# zxEWmx97a9Kje2hld6vYsSw/03IGMlxbrFBnLCVNVgY2/MFiTH19hhaVml1UulDQ
# sH+iRBnp1m5sPhPCnxHUXzRbUWgxYwr4W9DeullfMa+JaDhAPgjoU2dOY7Yhju/d
# jYVBVZ4cvDfclaDEcacfG6VJbgogWX6Jo1gVlwAlad/ewmpQZU5T+2uhnxgeig5f
# VF694FvP8gwE0t4IoRAm97Lzei7CjpbBP86l2vRZKIw3ZaExlguOpHZ3FUmEZoIl
# 50MKd1KxmVFC/6Gy3ZzS3BjZwYapQB1Bl2KGvKj/osdjFwb9Zno2lAEgiXgfkPR7
# qVJOak9UBiqAr57HUEL6ZQrjAfSxbqwOqOOBGag4yJ4DKIakdKdHlX5yWip7FWoc
# xGnmsL5AGZnL0n1VTiKcEOChW8OzLnqLxN7xSx+MKHkwRX9sE7Y9LP8tSooq7CgP
# LcrUnJiKSm1aNiwv37rL4kFKCHcYiK01YZQS86Ry6+42nqdRJ5E896IazPyH5Zfh
# UYdp6SLMg8C3D0VsB+FDT9SMSs7PY7G1pBB6+Q0MKLBrNP4haCdv7Pj6JoRbdULN
# iSZ5WZ1rq2NxYpAlDQgg8f8CAwEAAaOCAa4wggGqMA4GA1UdDwEB/wQEAwIBhjAT
# BgNVHSUEDDAKBggrBgEFBQcDAzASBgNVHRMBAf8ECDAGAQH/AgEAMB0GA1UdDgQW
# BBTas43AJJCja3fTDKBZ3SFnZHYLeDAfBgNVHSMEGDAWgBQfAL9GgAr8eDm3pbRD
# 2VZQu86WOzCBkwYIKwYBBQUHAQEEgYYwgYMwOQYIKwYBBQUHMAGGLWh0dHA6Ly9v
# Y3NwLmdsb2JhbHNpZ24uY29tL2NvZGVzaWduaW5ncm9vdHI0NTBGBggrBgEFBQcw
# AoY6aHR0cDovL3NlY3VyZS5nbG9iYWxzaWduLmNvbS9jYWNlcnQvY29kZXNpZ25p
# bmdyb290cjQ1LmNydDBBBgNVHR8EOjA4MDagNKAyhjBodHRwOi8vY3JsLmdsb2Jh
# bHNpZ24uY29tL2NvZGVzaWduaW5ncm9vdHI0NS5jcmwwVgYDVR0gBE8wTTBBBgkr
# BgEEAaAyATIwNDAyBggrBgEFBQcCARYmaHR0cHM6Ly93d3cuZ2xvYmFsc2lnbi5j
# b20vcmVwb3NpdG9yeS8wCAYGZ4EMAQQBMA0GCSqGSIb3DQEBCwUAA4ICAQAIiHIm
# xq/6rF8GwKqMkNrQssCil/9uEzIWVP0+9DARn4+Y+ZtS3fKiFu7ZeJWmmnxhuAS1
# +OvL9GERM/ZlJbcRQovYaW7H/5W0gUOpfq6/gtZNzBGjg3FqEF4ZBafnbH9W9Khc
# w04JrVlruPl+pS64/N4OwqD7sATUExvHJ6m5qi0xO89GTJ3rTOy8Lpzxh6N/OGlf
# QUBn9lN96kHvjj37qdQROEbfPOv2zSK9E83w4eblM6C+POR41RvMIPIwc7AiHPaE
# 1ptcAALhKFJL/xJLQOrusBoGBp6E5ufw24RG+3PZK0K2yVc0xxbApushuaoO9/7b
# yuu8F8u4Z+vjPk/bqZSGZFXJCQrA2QRxShFLWmTDvHh4rUxHJmUHmdXNNmChM1Oz
# 9nsq1YlAPHGlq/iZWf3jm5JL3QW9Cwx4BivPU9i9EppbJ4aFP5G+4HiAc1Tfpx1n
# K2q2rk2JgCQIUnBQ8wH/RK4vmuDhSQjh4VvXONGeCoqdlCebyqO52+I2auNvuVhi
# 4DZ4NgH6waeJeiZTo1y70rLristjCC/+HvNWKeI1m9j/6aW9bUtZLIksL1K7tSmQ
# 2kNHvHLdvNm/gMHcsKu0Sx1YNjdk65vhhReaKaL95gjSkv+g+Hzh6afRMI5fJlAr
# x6Lil3eK79hNPibrmUBg8zxnDLYIcik1U4E03DCCBx0wggUFoAMCAQICDESFWejV
# n+BWKZ5ujzANBgkqhkiG9w0BAQsFADBZMQswCQYDVQQGEwJCRTEZMBcGA1UEChMQ
# R2xvYmFsU2lnbiBudi1zYTEvMC0GA1UEAxMmR2xvYmFsU2lnbiBHQ0MgUjQ1IENv
# ZGVTaWduaW5nIENBIDIwMjAwHhcNMjMxMjExMTcwMDM2WhcNMjYxMDA5MDc0MDU4
# WjCBijELMAkGA1UEBhMCSU4xEzARBgNVBAgTClRhbWlsIE5hZHUxEDAOBgNVBAcT
# B0NoZW5uYWkxKTAnBgNVBAoTIFpPSE8gQ29ycG9yYXRpb24gUHJpdmF0ZSBMaW1p
# dGVkMSkwJwYDVQQDEyBaT0hPIENvcnBvcmF0aW9uIFByaXZhdGUgTGltaXRlZDCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAIv3aVIEAUL2uenwgJAgsw6f
# /MPdcNb9g1z/B/dStszWc6nv3v50+eFt/pPGZptdHPG0yDbvXL+Iu9Z4x4SJmgDO
# +vMtHzTymdri0thZ+Y5Xn5sHDY9IhrqiF2iGouAvG9YixX+7ZwJr7/BwAmev4H4V
# eHYkT2LAlhftKLiWhTnwz6z2w1dGXehgr0IXutgclVstDYXLBOFRUjf8ZVbI7OF9
# y/Xa9SNwIwPRBztwn+j66qnTBhBr3kcAn0mol7kO2C5ZwASkV8bnF911/kRhNrWx
# SfQpWH+QZhAXwUzoKQcTzZiXcgzk2TqbKvDlo+ARmKvTJrZt7kvlVafXE4MIB6rk
# iUGJHAqSNc26pZZTVyjB+2uIA+3IYQf2NmkFH8Hg1zWb74hQ0X92F4pblYhZzzHY
# Dpu6pbmlvCMsR6AiywCw6BL8LwB6c06z0YWMGWDJfOOfbqTVgtQHbn2YQXDtrwMS
# 5hgUS3qLZ54CowbY1ES89UciATNFZyg/tJEtO0o9zFy8SaUVGRRP9Zoz3dC41D+a
# xaYzJkFD0vw4L4e3VkZH1MwAv8mYh7Qos/0jAQRwmLGQDDacInGsZBcHnc8C744m
# t4PCJ/vYl1jLH4CQ3ioGk384AYHP0H/WgCAXFFNOvIYBWBGXPJV80g1bvmUGfdOc
# OP+jGgHX1oP6mjaX0X7dAgMBAAGjggGxMIIBrTAOBgNVHQ8BAf8EBAMCB4AwgZsG
# CCsGAQUFBwEBBIGOMIGLMEoGCCsGAQUFBzAChj5odHRwOi8vc2VjdXJlLmdsb2Jh
# bHNpZ24uY29tL2NhY2VydC9nc2djY3I0NWNvZGVzaWduY2EyMDIwLmNydDA9Bggr
# BgEFBQcwAYYxaHR0cDovL29jc3AuZ2xvYmFsc2lnbi5jb20vZ3NnY2NyNDVjb2Rl
# c2lnbmNhMjAyMDBWBgNVHSAETzBNMEEGCSsGAQQBoDIBMjA0MDIGCCsGAQUFBwIB
# FiZodHRwczovL3d3dy5nbG9iYWxzaWduLmNvbS9yZXBvc2l0b3J5LzAIBgZngQwB
# BAEwCQYDVR0TBAIwADBFBgNVHR8EPjA8MDqgOKA2hjRodHRwOi8vY3JsLmdsb2Jh
# bHNpZ24uY29tL2dzZ2NjcjQ1Y29kZXNpZ25jYTIwMjAuY3JsMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFNqzjcAkkKNrd9MMoFndIWdkdgt4MB0GA1Ud
# DgQWBBQAEYFD6bVlLVlpKYdhLAjp9JgOnTANBgkqhkiG9w0BAQsFAAOCAgEAhvMF
# 2tjnlwBnEkHISuHLDUQPA9YtCX1xxUHFUMvf85Flz0WFpW3GoGy0Zj831s2tSVbV
# 7mIptXjkMx7yUHMgeu01ptEWPqEEfAmKJz9ewSbyP0xt8bDHdG/YNnV6V+umbBRR
# 3qaRqnErOXp4ZnGKCAoD5XtZwqvncWpvYUGzLh1kzU9ThCm/fn0ywv5/pdvzt0To
# QFBxTwvsbhYP+p9icosezdSV+3Fr4LT3kAs/6bXEQjBd2tZdBS0W93GKvXTJQTGI
# g2515rygwEj0R+sAOyxNy31RUTgi54/2OhRJ3rQUGwxZ9IonTfTBp659J3Xk+JPv
# NhsdIEVcr9PNy9V3CZ7MpQwUBOqiaULYr+5WKOrbbeZKUI+zVIRH0PyKr0z5y3hk
# em5bhDsjfuKQignV1sIMngC++gQaI27gz/RLDCxsvX+6IelsDaAAPnYGevvDqyN7
# ksIw2+jBs7BWMk/SRjxHCBb3u3U3BZfVfR3JjJng4dMi5EV0wrws2fGMmFdPZTps
# 2M1akw6ruwA7pCc69faOGbqcLw52y4+oxOfHJM/zpgQ75AtmgYN3nh1G/L+ZsNa5
# II6e8wsCbwryw6vVu0g2TxdQ2RaTeNje2ROKgoq++cwKUp7AYQvzVLB1OddsTYxh
# qkXuVpQEtgvWqZOAv9SRi3lRap1Ycg045uMShwoxghrRMIIazQIBATBpMFkxCzAJ
# BgNVBAYTAkJFMRkwFwYDVQQKExBHbG9iYWxTaWduIG52LXNhMS8wLQYDVQQDEyZH
# bG9iYWxTaWduIEdDQyBSNDUgQ29kZVNpZ25pbmcgQ0EgMjAyMAIMRIVZ6NWf4FYp
# nm6PMA0GCWCGSAFlAwQCAQUAoIHAMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqGSIb3DQEJBDEiBCCZ
# +knsHJwEd3eO+GggYsgn1qr5Yx64XfiumI1nF+Ax7zBUBgorBgEEAYI3AgEMMUYw
# RKBCgEAAWgBPAEgATwAgAEMAbwByAHAAbwByAGEAdABpAG8AbgAgAFAAcgBpAHYA
# YQB0AGUAIABMAGkAbQBpAHQAZQBkMA0GCSqGSIb3DQEBAQUABIICAHwyWRdLqtGF
# iWqBA3i3lHjkcpbEpwqjcl2KUDZjTIBQrk0iVIoDrVesZIRpu5enHpYvjAHWTbDD
# PLEREGT9CzWFWz1CtmLNwGaJT0nlizBpkYp8eX/tt+Q7L3MHcq/uR12PqRF3M19p
# 8wP7MpSHUnY8ipAYzJFWc3wfoGK1ot1dCGaz52AWuqcTDE4OFTdLv2XY2BFuCnjc
# rqHeFs35v+GwlRXkW2vGp7uLu8Hx5qqSMXD39FpU1bE+UCOE3CXyY9qJxbWrajJA
# Md508xn15UExJP3ysmr5suk9ZUf8+t7nbx22ESQlbaN6C4px/IUsI1UqT/CSfE1K
# 3TxwtIl56k/e9YrvSeeExygIJYUeMjsjU9CyA3qr2fBbnXT7nDrhobRtEfIjf/Su
# YHMu9BdjU6Hd/bVRAiJUsRY9hHqH9qcte1/D33EqxIMoOQOZmrAriE7kcOy2GhQw
# 09Fn8w9Ab2Uh5yc8x+8mpNpdIk+O9EOvz+xtpsnaUPxhg9lxxkNq+tDjULs0qPPj
# 1oDd/aTtqpSBJkuaJ+w8V1HdZ6KFg9qKnV4Hy2cPzbLLf6TA5WyAYFTfYy0EM0Ag
# gDJCAwO5rI36RleKtLCTzsji4rlwZpt5nDk23EFAhS5UutJZ71i+rEtvz/q0qu9c
# hwuxATxYN1hVE5SnMdmmyFZO0wikf0vvoYIXdjCCF3IGCisGAQQBgjcDAwExghdi
# MIIXXgYJKoZIhvcNAQcCoIIXTzCCF0sCAQMxDzANBglghkgBZQMEAgEFADB3Bgsq
# hkiG9w0BCRABBKBoBGYwZAIBAQYJYIZIAYb9bAcBMDEwDQYJYIZIAWUDBAIBBQAE
# IHfLc3k+WyXIxuMfn5FLjzLBPYJSRhNCuLzkiaMFM0S2AhA2Er0mhragLP2DcSsZ
# JTWqGA8yMDI1MDYxOTEwNTkxM1qgghM6MIIG7TCCBNWgAwIBAgIQCoDvGEuN8QWC
# 0cR2p5V0aDANBgkqhkiG9w0BAQsFADBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMO
# RGlnaUNlcnQsIEluYy4xQTA/BgNVBAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgVGlt
# ZVN0YW1waW5nIFJTQTQwOTYgU0hBMjU2IDIwMjUgQ0ExMB4XDTI1MDYwNDAwMDAw
# MFoXDTM2MDkwMzIzNTk1OVowYzELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lD
# ZXJ0LCBJbmMuMTswOQYDVQQDEzJEaWdpQ2VydCBTSEEyNTYgUlNBNDA5NiBUaW1l
# c3RhbXAgUmVzcG9uZGVyIDIwMjUgMTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCC
# AgoCggIBANBGrC0Sxp7Q6q5gVrMrV7pvUf+GcAoB38o3zBlCMGMyqJnfFNZx+wvA
# 69HFTBdwbHwBSOeLpvPnZ8ZN+vo8dE2/pPvOx/Vj8TchTySA2R4QKpVD7dvNZh6w
# W2R6kSu9RJt/4QhguSssp3qome7MrxVyfQO9sMx6ZAWjFDYOzDi8SOhPUWlLnh00
# Cll8pjrUcCV3K3E0zz09ldQ//nBZZREr4h/GI6Dxb2UoyrN0ijtUDVHRXdmncOOM
# A3CoB/iUSROUINDT98oksouTMYFOnHoRh6+86Ltc5zjPKHW5KqCvpSduSwhwUmot
# uQhcg9tw2YD3w6ySSSu+3qU8DD+nigNJFmt6LAHvH3KSuNLoZLc1Hf2JNMVL4Q1O
# pbybpMe46YceNA0LfNsnqcnpJeItK/DhKbPxTTuGoX7wJNdoRORVbPR1VVnDuSeH
# VZlc4seAO+6d2sC26/PQPdP51ho1zBp+xUIZkpSFA8vWdoUoHLWnqWU3dCCyFG1r
# oSrgHjSHlq8xymLnjCbSLZ49kPmk8iyyizNDIXj//cOgrY7rlRyTlaCCfw7aSURO
# wnu7zER6EaJ+AliL7ojTdS5PWPsWeupWs7NpChUk555K096V1hE0yZIXe+giAwW0
# 0aHzrDchIc2bQhpp0IoKRR7YufAkprxMiXAJQ1XCmnCfgPf8+3mnAgMBAAGjggGV
# MIIBkTAMBgNVHRMBAf8EAjAAMB0GA1UdDgQWBBTkO/zyMe39/dfzkXFjGVBDz2GM
# 6DAfBgNVHSMEGDAWgBTvb1NK6eQGfHrK4pBW9i/USezLTjAOBgNVHQ8BAf8EBAMC
# B4AwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwgZUGCCsGAQUFBwEBBIGIMIGFMCQG
# CCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wXQYIKwYBBQUHMAKG
# UWh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNFRp
# bWVTdGFtcGluZ1JTQTQwOTZTSEEyNTYyMDI1Q0ExLmNydDBfBgNVHR8EWDBWMFSg
# UqBQhk5odHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRU
# aW1lU3RhbXBpbmdSU0E0MDk2U0hBMjU2MjAyNUNBMS5jcmwwIAYDVR0gBBkwFzAI
# BgZngQwBBAIwCwYJYIZIAYb9bAcBMA0GCSqGSIb3DQEBCwUAA4ICAQBlKq3xHCcE
# ua5gQezRCESeY0ByIfjk9iJP2zWLpQq1b4URGnwWBdEZD9gBq9fNaNmFj6Eh8/Ym
# RDfxT7C0k8FUFqNh+tshgb4O6Lgjg8K8elC4+oWCqnU/ML9lFfim8/9yJmZSe2F8
# AQ/UdKFOtj7YMTmqPO9mzskgiC3QYIUP2S3HQvHG1FDu+WUqW4daIqToXFE/JQ/E
# ABgfZXLWU0ziTN6R3ygQBHMUBaB5bdrPbF6MRYs03h4obEMnxYOX8VBRKe1uNnzQ
# VTeLni2nHkX/QqvXnNb+YkDFkxUGtMTaiLR9wjxUxu2hECZpqyU1d0IbX6Wq8/gV
# utDojBIFeRlqAcuEVT0cKsb+zJNEsuEB7O7/cuvTQasnM9AWcIQfVjnzrvwiCZ85
# EE8LUkqRhoS3Y50OHgaY7T/lwd6UArb+BOVAkg2oOvol/DJgddJ35XTxfUlQ+8Hg
# gt8l2Yv7roancJIFcbojBcxlRcGG0LIhp6GvReQGgMgYxQbV1S3CrWqZzBt1R9xJ
# gKf47CdxVRd/ndUlQ05oxYy2zRWVFjF7mcr4C34Mj3ocCVccAvlKV9jEnstrniLv
# UxxVZE/rptb7IRE2lskKPIJgbaP5t2nGj/ULLi49xTcBZU8atufk+EMF/cWuiC7P
# OGT75qaL6vdCvHlshtjdNXOCIUjsarfNZzCCBrQwggScoAMCAQICEA3HrFcF/yGZ
# LkBDIgw6SYYwDQYJKoZIhvcNAQELBQAwYjELMAkGA1UEBhMCVVMxFTATBgNVBAoT
# DERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UE
# AxMYRGlnaUNlcnQgVHJ1c3RlZCBSb290IEc0MB4XDTI1MDUwNzAwMDAwMFoXDTM4
# MDExNDIzNTk1OVowaTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJ
# bmMuMUEwPwYDVQQDEzhEaWdpQ2VydCBUcnVzdGVkIEc0IFRpbWVTdGFtcGluZyBS
# U0E0MDk2IFNIQTI1NiAyMDI1IENBMTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCC
# AgoCggIBALR4MdMKmEFyvjxGwBysddujRmh0tFEXnU2tjQ2UtZmWgyxU7UNqEY81
# FzJsQqr5G7A6c+Gh/qm8Xi4aPCOo2N8S9SLrC6Kbltqn7SWCWgzbNfiR+2fkHUil
# jNOqnIVD/gG3SYDEAd4dg2dDGpeZGKe+42DFUF0mR/vtLa4+gKPsYfwEu7EEbkC9
# +0F2w4QJLVSTEG8yAR2CQWIM1iI5PHg62IVwxKSpO0XaF9DPfNBKS7Zazch8NF5v
# p7eaZ2CVNxpqumzTCNSOxm+SAWSuIr21Qomb+zzQWKhxKTVVgtmUPAW35xUUFREm
# DrMxSNlr/NsJyUXzdtFUUt4aS4CEeIY8y9IaaGBpPNXKFifinT7zL2gdFpBP9qh8
# SdLnEut/GcalNeJQ55IuwnKCgs+nrpuQNfVmUB5KlCX3ZA4x5HHKS+rqBvKWxdCy
# QEEGcbLe1b8Aw4wJkhU1JrPsFfxW1gaou30yZ46t4Y9F20HHfIY4/6vHespYMQmU
# iote8ladjS/nJ0+k6MvqzfpzPDOy5y6gqztiT96Fv/9bH7mQyogxG9QEPHrPV6/7
# umw052AkyiLA6tQbZl1KhBtTasySkuJDpsZGKdlsjg4u70EwgWbVRSX1Wd4+zoFp
# p4Ra+MlKM2baoD6x0VR4RjSpWM8o5a6D8bpfm4CLKczsG7ZrIGNTAgMBAAGjggFd
# MIIBWTASBgNVHRMBAf8ECDAGAQH/AgEAMB0GA1UdDgQWBBTvb1NK6eQGfHrK4pBW
# 9i/USezLTjAfBgNVHSMEGDAWgBTs1+OC0nFdZEzfLmc/57qYrhwPTzAOBgNVHQ8B
# Af8EBAMCAYYwEwYDVR0lBAwwCgYIKwYBBQUHAwgwdwYIKwYBBQUHAQEEazBpMCQG
# CCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQQYIKwYBBQUHMAKG
# NWh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRSb290
# RzQuY3J0MEMGA1UdHwQ8MDowOKA2oDSGMmh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydFRydXN0ZWRSb290RzQuY3JsMCAGA1UdIAQZMBcwCAYGZ4EMAQQC
# MAsGCWCGSAGG/WwHATANBgkqhkiG9w0BAQsFAAOCAgEAF877FoAc/gc9EXZxML2+
# C8i1NKZ/zdCHxYgaMH9Pw5tcBnPw6O6FTGNpoV2V4wzSUGvI9NAzaoQk97frPBtI
# j+ZLzdp+yXdhOP4hCFATuNT+ReOPK0mCefSG+tXqGpYZ3essBS3q8nL2UwM+NMvE
# uBd/2vmdYxDCvwzJv2sRUoKEfJ+nN57mQfQXwcAEGCvRR2qKtntujB71WPYAgwPy
# WLKu6RnaID/B0ba2H3LUiwDRAXx1Neq9ydOal95CHfmTnM4I+ZI2rVQfjXQA1WSj
# jf4J2a7jLzWGNqNX+DF0SQzHU0pTi4dBwp9nEC8EAqoxW6q17r0z0noDjs6+BFo+
# z7bKSBwZXTRNivYuve3L2oiKNqetRHdqfMTCW/NmKLJ9M+MtucVGyOxiDf06VXxy
# KkOirv6o02OoXN4bFzK0vlNMsvhlqgF2puE6FndlENSmE+9JGYxOGLS/D284NHNb
# oDGcmWXfwXRy4kbu4QFhOm0xJuF2EZAOk5eCkhSxZON3rGlHqhpB/8MluDezooIs
# 8CVnrpHMiD2wL40mm53+/j7tFaxYKIqL0Q4ssd8xHZnIn/7GELH3IdvG2XlM9q7W
# P/UwgOkw/HQtyRN62JK4S1C8uw3PdBunvAZapsiI5YKdvlarEvf8EA+8hcpSM9LH
# JmyrxaFtoza2zNaQ9k+5t1wwggWNMIIEdaADAgECAhAOmxiO+dAt5+/bUOIIQBha
# MA0GCSqGSIb3DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNVBAMTG0RpZ2lD
# ZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBaFw0zMTExMDky
# MzU5NTlaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0
# ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAL/mkHNo
# 3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/zG6Q4FutW
# xpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZanMylNEQ
# RBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7sWxq868nP
# zaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL2pNe3I6P
# gNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfbBHMqbpEB
# fCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3JFxGj2T3
# wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3cAORFJYm2
# mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqxYxhElRp2
# Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0viastkF1
# 3nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aLT8LWRV+d
# IPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIBNjAPBgNVHRMB
# Af8EBTADAQH/MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwPTzAfBgNVHSME
# GDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMCAYYweQYIKwYB
# BQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20w
# QwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2Vy
# dEFzc3VyZWRJRFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0aHR0cDovL2Ny
# bDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDARBgNV
# HSAECjAIMAYGBFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0NcVec4X6CjdBs9
# thbX979XB72arKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnovLbc47/T/gLn4
# offyct4kvFIDyE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65ZyoUi0mcudT6cG
# AxN3J0TU53/oWajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFWjuyk1T3osdz9
# HNj0d1pcVIxv76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPFmCLBsln1VWvP
# J6tsds5vIy30fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9ztwGpn1eqXiji
# uZQxggN8MIIDeAIBATB9MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2Vy
# dCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3RhbXBp
# bmcgUlNBNDA5NiBTSEEyNTYgMjAyNSBDQTECEAqA7xhLjfEFgtHEdqeVdGgwDQYJ
# YIZIAWUDBAIBBQCggdEwGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMBwGCSqG
# SIb3DQEJBTEPFw0yNTA2MTkxMDU5MTNaMCsGCyqGSIb3DQEJEAIMMRwwGjAYMBYE
# FN1iMKyGCi0wa9o4sWh5UjAH+0F+MC8GCSqGSIb3DQEJBDEiBCAofHMEPu7pJZdh
# V/GaDRuhUrUcfF8vtzbOhoYQV5X9CzA3BgsqhkiG9w0BCRACLzEoMCYwJDAiBCBK
# oD+iLNdchMVck4+CjmdrnK7Ksz/jbSaaozTxRhEKMzANBgkqhkiG9w0BAQEFAASC
# AgBiE7RrhXd7c8Vz6uO1rk8c6fbbBOdgfuEPG8gAx5EYBuLfjMv5f61rZ9LWifuw
# vUI/39yHXubVa+UpuhBEhUDW40J+NAz2d/Ko1r838mHeDyxgN9/Howaqnl3TX8IL
# 93aYSCdiJs8Dv4JR1xNWa6rIlPk6DBc17Dd4q58v+uih6946NOXgbmF/qwSc5wNz
# 5p04bMaXYK3olHfoEYJzEE9Vr375EIWlS5WiDH/pzu7o9K/XMOwKY14GK1nNbWMZ
# Zp5PjdPcDBLS/22toTmenL2y3IKQy3FO9tcKfAhQQFnOMbZV7KF7fYz6BvUGug5P
# Nqvz1QDcoua18cztN8c4w3VErWsPbUj2eVhfweGqkdDpwnayMBbwQ7a7UvTZen4V
# pNlIbmqxJzLGZjnKa4e14QA612WBUcidnzseg3s4ipTRwffgtTd6u5PZopsvSCzg
# hMOKSVTTvK5/u4Pph4ufUo2/OOfhHPq8o2k2E0tlQshUo4iP7IoqK6eElSn14sfd
# U1aWXUYrxp/m+zXJ+cBKFHGWPppfTs8nSkH77o1bdd2r5JbMhk/YF1Mt9KsJVwNh
# Jyv2FcyCSlz+0mB0Bw4mzE/KNqTuw2GjoRujrxaMDmbXhSecT/8YYaYnNtEYwnPf
# fDoRNUINPp34VtnZsN0fJcTrhklwdYOartb8saJ1rEr4Xw==
# SIG # End signature block
