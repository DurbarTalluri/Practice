param (
    [string]$Destination,
    [ValidateSet('local', 'global')][string]$InstallType,
    [string]$LicenseKey,
	[string]$AppName,
	[switch]$IncludeDotNetFramework,
    [switch]$ResetIIS,
	[switch]$ForceUpdate,
    [switch]$Help,
	[switch]$IgnoreFolderPermission,
	[switch]$IsBehindProxy,
	[string]$ProxyHost,
	[int]$ProxyPort,
	[string]$ProxyUser,
	[string]$ProxyPassword,
	[switch]$DisableAppFilter
)

$AgentVersion = "6.9.2"

$w3svcRegistryPath = "HKLM:\SYSTEM\CurrentControlSet\Services\W3SVC"
$wasRegistryPath = "HKLM:\SYSTEM\CurrentControlSet\Services\WAS"
$environmentKey = "Environment"
$profilerId = "{9D363A5F-ED5F-4AAC-B456-75AFFA6AA0C8}"
$Saltkey=""
$InitVector=""
$EncryptLKey=""

$SupportedVersions = @('netcoreapp2.0','netcoreapp2.1','netcoreapp2.2','netcoreapp2.2','netcoreapp3.0','netcoreapp3.1','net5.0','net6.0','net7.0','net8.0')
$Platforms = @('x64','x86')

[bool] $IsUpdateFound = $false

Function InstallAgent()
{
	try
	{
	    $agentPath = (Join-Path $Destination "Site24x7DotNetCoreAgent")		
		$isVersionInfoExists = Test-Path (Join-Path $agentPath "version.info")

		if ($isVersionInfoExists) 
		{
			$installedAgentVersionString = Get-Content (Join-Path $agentPath "version.info")		
		
			$currentVersionNumber = $installedAgentVersionString -replace '\.',''
			$newVersionNumber = $AgentVersion -replace '\.',''
		
			if ($currentVersionNumber -lt $newVersionNumber) 
			{
				$IsUpdateFound = $true
				$userInput = "Y"
				if(-Not($ForceUpdate))
				{
					$agentMessage = "
APM Insight .NET core agent is already installed in the given location. Currently installed agent version is $installedAgentVersionString. Do you want to upgrade to $AgentVersion [Y/N]?"
					$userInput = Read-Host -Prompt $agentMessage
				}
				
				if ($userInput -eq "N" -OR $userInput -eq "n") 
				{
					Print("Setting the agent environment with the existing version $installedAgentVersionString.")
					SetEnvironmentVariables $agentPath 
				}
				elseif ($userInput -eq "Y" -OR $userInput -eq "y") 
				{
					Print("Upgrading the agent to the version $AgentVersion.")
					CopyFiles $agentPath
				}
				else
				{
					Print("Enter valid input.")
				}
				Print("The APM Insight .NET Core agent version $AgentVersion is set up successfully. Reset IIS, if you hosted the applications in IIS.")
			}
			elseif($currentVersionNumber -eq $newVersionNumber) 
			{
				Print("Same version of agent is found. Setting the agent environment for the version $installedAgentVersionString.")
				SetEnvironmentVariables $agentPath 
				Print("The APM Insight .NET Core agent version $AgentVersion is set up successfully. Reset IIS, if you hosted the applications in IIS.")
			}	
			else
			{
				Print("Higher version of agent is found. Upgrade could not be proceeded.")
			}
		}
		else
		{
			Print-Color -message "Setting up the APM Insight .NET Core agent version $AgentVersion." -Color Green	
			CopyFiles $agentPath
			Print-Color -message "The APM Insight .NET Core agent version $AgentVersion is set up successfully." -Color Green
			
			Print-Color -message "Kindly do the below steps to finish the configuration: `n  1. For IIS hosted applications, edit the below config file.  `n`t$agentPath\DotNetAgent\appfilter.config `n  2. For standalone and Desktop applications, edit the below config file. `n`t$agentPath\DotNetAgent\netcore_appfilter.config `n 3. For Windows Services, edit the below config file. `n`t$agentPath\DotNetAgent\windowsservice_appfilter.config " -Color Yellow

			Print-Color -message "Reset IIS or Restart .NET Core applications/services to start monitoring." -Color Yellow

			Print-Color -message "For more information, please refer to: https://www.site24x7.com/help/apm/dotnet-agent/configure-appfilters-net-core.html`n" -Color Yellow
		}
	 }
	 catch [Exception]
	 {
		Write-Warning $_.Exception.Message;
	 }
}

Function Print([string]$message)
{
	Write-Host "
$message"
}

Function Print-Color([string]$message, [ConsoleColor[]]$Color)
{
	Write-Host "
$message" -ForeGround $Color
}

Function CopyFiles([string]$agentPath)
{
	$isFolderExists = Test-Path $agentPath
	if (-Not $isFolderExists) {
		New-Item $agentPath -type Directory | Out-Null
	}
	
	if(-Not($IsUpdateFound) -AND -Not($IgnoreFolderPermission))	{
		SetFolderPermissions $agentPath
	}
	$resolvedPath = (Resolve-Path -Path $agentPath).Path
	
	try
	{
		Get-ChildItem -Path $resolvedPath\NETFramework -Filter "*.dll" -Recurse | Rename-Item -NewName {$_.name -replace '.dll', '_old.dll' }
		Get-ChildItem -Path $resolvedPath\store -Filter "*.dll" -Recurse | Rename-Item -NewName {$_.name -replace '.dll', '_old.dll' }
		Get-ChildItem -Path $resolvedPath\x64 -Filter "*.dll" -Recurse | Rename-Item -NewName {$_.name -replace '.dll', '_old.dll' }
		Get-ChildItem -Path $resolvedPath\x86 -Filter "*.dll" -Recurse | Rename-Item -NewName {$_.name -replace '.dll', '_old.dll' }
	}
	catch [Exception]
	{
		Write-Warning $_.Exception.Message;
	}
		
	CopyAgentFiles $resolvedPath

	if(-Not($IsUpdateFound))
	{
		SetEnvironmentVariables $resolvedPath 
	 
		ModifyConfiguration $resolvedPath	
	}
		
	[string]$agentFile = $resolvedPath + "\store\";
	Get-ChildItem -Path $agentFile -Recurse | Unblock-File
		
	CreateVersionInfoFile $resolvedPath
}

Function CopyAgentFiles([string]$resolvedPath)
{	
	try
	{
		$additionalDepsPath = (Join-Path $resolvedPath "additionalDeps")	
		$isAdditionalDepsExists = Test-Path $additionalDepsPath
		if ($isAdditionalDepsExists)
		{
			Remove-Item $additionalDepsPath -Recurse
		}
	}
	catch [Exception]
	{
		Write-Warning $_.Exception.Message;
	}
	
	Copy-Item "$PSScriptRoot\Agent\Deps\additionalDeps" $resolvedPath -Recurse -Force
	Copy-Item "$PSScriptRoot\Agent\AgentDiagnostics" $resolvedPath -Recurse -Force
	if(-Not($IsUpdateFound))
	{
		Copy-Item "$PSScriptRoot\Agent\DotNetCoreAgent" $resolvedPath -Recurse -Force
	}
	Copy-Item "$PSScriptRoot\Agent\packages\NETFramework" $resolvedPath -Recurse -Force
	Copy-Item "$PSScriptRoot\Agent\packages\x64" $resolvedPath -Recurse -Force
	Copy-Item "$PSScriptRoot\Agent\packages\x86" $resolvedPath -Recurse -Force
	
	foreach ($platform in $Platforms) {
		foreach ($folderName in $SupportedVersions) {	
			if (!(Test-Path $resolvedPath\store\$platform\$folderName\dotnetagent\1.0.0\lib\netcoreapp2.0)) {
				New-Item $resolvedPath\store\$platform\$folderName\dotnetagent\1.0.0\lib\netcoreapp2.0 -type Directory | Out-Null
			}
			Copy-Item "$PSScriptRoot\Agent\packages\AnyCPU\DotNetAgent.dll" $resolvedPath\store\$platform\$folderName\dotnetagent\1.0.0\lib\netcoreapp2.0 -Force
			
			if (!(Test-Path $resolvedPath\store\$platform\$folderName\dotnetagent.util\1.0.0\lib\netcoreapp2.0)) {
				New-Item $resolvedPath\store\$platform\$folderName\dotnetagent.util\1.0.0\lib\netcoreapp2.0 -type Directory | Out-Null
			}
			Copy-Item "$PSScriptRoot\Agent\packages\AnyCPU\DotNetAgent.Util.dll" $resolvedPath\store\$platform\$folderName\dotnetagent.util\1.0.0\lib\netcoreapp2.0 -Force
			
			if (!(Test-Path $resolvedPath\store\$platform\$folderName\site24x7.agent.api\1.0.0\lib\netcoreapp2.0)) {
				New-Item $resolvedPath\store\$platform\$folderName\site24x7.agent.api\1.0.0\lib\netcoreapp2.0 -type Directory | Out-Null
			}
			Copy-Item "$PSScriptRoot\Agent\packages\AnyCPU\Site24x7.Agent.Api.dll" $resolvedPath\store\$platform\$folderName\site24x7.agent.api\1.0.0\lib\netcoreapp2.0 -Force
			
			if (!(Test-Path $resolvedPath\store\$platform\$folderName\autoupdate\1.0.0\lib\netcoreapp2.0)) {
				New-Item $resolvedPath\store\$platform\$folderName\autoupdate\1.0.0\lib\netcoreapp2.0 -type Directory | Out-Null
			}
			Copy-Item "$PSScriptRoot\Agent\packages\AnyCPU\AutoUpdate.dll" $resolvedPath\store\$platform\$folderName\autoupdate\1.0.0\lib\netcoreapp2.0 -Force
		}
	}
}

Function ModifyConfiguration([string]$agentPath)
{
	$EncryptLKey = Encrypt-AES($LicenseKey) 
    [string]$filePath = $agentPath + "\DotNetCoreAgent\apminsight.conf";
	if (Test-Path -Path $filePath) {
		(Get-Content $filePath ).Replace('license.key=','license.key='+$EncryptLKey) | Out-File $filePath
		(Get-Content $filePath ).Replace('agent_start_time=','agent_start_time='+$Saltkey) | Out-File $filePath
		(Get-Content $filePath ).Replace('agent_id=','agent_id='+$InitVector) | Out-File $filePath
		If ($IsBehindProxy) {
			(Get-Content $filePath ).Replace('behind.proxy=false','behind.proxy=true') | Out-File $filePath
			(Get-Content $filePath ).Replace('proxy.server.host=proxyserver','proxy.server.host='+$ProxyHost) | Out-File $filePath
			(Get-Content $filePath ).Replace('proxy.server.port=proxyport','proxy.server.port='+$ProxyPort) | Out-File $filePath
			(Get-Content $filePath ).Replace('proxy.auth.username=proxyuser','proxy.auth.username='+$ProxyUser) | Out-File $filePath
			(Get-Content $filePath ).Replace('proxy.auth.password=proxypassword','proxy.auth.password='+$ProxyPassword) | Out-File $filePath
		}
		if($DisableAppFilter)
		{
			DisableAppFilterInConfig $filePath
		}
	}
}

Function DisableAppFilterInConfig([string]$agentConfigFilePath)
{	
	$keyValueToFind = "enable.appfilter="
	$keyValueToAddOrReplace = "enable.appfilter=false"
	$fileContent = Get-Content -Path $agentConfigFilePath
	$found = $false

	for ($i = 0; $i -lt $fileContent.Length; $i++) {
		if ($fileContent[$i] -match $keyValueToFind) {
			$fileContent[$i] = $keyValueToAddOrReplace
			$found = $true
			break
		}
	}

	if (-not $found) {
		$fileContent += $keyValueToAddOrReplace
	}

	$fileContent | Set-Content -Path $agentConfigFilePath
}


Function SetEnvironmentVariables([string]$installPath) {
	if ($InstallType -eq "global") {
		SetLocalEnvironment($installPath);
		SetGlobalEnvironment($installPath);
	}
	else {
		SetLocalEnvironment($installPath);
			
		if ((Test-Path -Path $w3svcRegistryPath) -and (Test-Path -Path $wasRegistryPath)) {
			#Setting Profiler Environment in registry for IIS starts.
			$environmentValue = GetEnvironmentSettingValue($installPath);
			SetRegistryEnvironment $w3svcRegistryPath $environmentKey $environmentValue $installPath
			SetRegistryEnvironment $wasRegistryPath $environmentKey $environmentValue $installPath
			#Setting Profiler Environment in registry for IIS ends.
		}
	}
}

Function SetLocalEnvironment([string]$installPath)
{
	if($IncludeDotNetFramework)
	{
		[Environment]::SetEnvironmentVariable("COR_ENABLE_PROFILING", "1")
		[Environment]::SetEnvironmentVariable("COR_PROFILER", $profilerId)
		[Environment]::SetEnvironmentVariable("COR_PROFILER_PATH_64", (Join-Path $installPath "NETFramework\x64\ClrProfilerAgent.dll"))
		[Environment]::SetEnvironmentVariable("COR_PROFILER_PATH_32", (Join-Path $installPath "NETFramework\x86\ClrProfilerAgent.dll"))	
	}
	[Environment]::SetEnvironmentVariable("CORECLR_ENABLE_PROFILING", "1")
	[Environment]::SetEnvironmentVariable("CORECLR_PROFILER", $profilerId)
	[Environment]::SetEnvironmentVariable("CORECLR_SITE24X7_HOME", $installPath)
	[Environment]::SetEnvironmentVariable("CORECLR_PROFILER_PATH_64", (Join-Path $installPath "x64\ClrProfilerAgent.dll"))
	[Environment]::SetEnvironmentVariable("CORECLR_PROFILER_PATH_32", (Join-Path $installPath "x86\ClrProfilerAgent.dll"))
	[Environment]::SetEnvironmentVariable("DOTNET_ADDITIONAL_DEPS", (Join-Path $installPath "additionalDeps;"))
	[Environment]::SetEnvironmentVariable("DOTNET_SHARED_STORE", (Join-Path $installPath "store;"))
	[Environment]::SetEnvironmentVariable("S247_LICENSE_KEY", $LicenseKey)	
	if($DisableAppFilter -and $AppName -ne "")
	{
		[Environment]::SetEnvironmentVariable("SITE24X7_APP_NAME", $AppName)
	}
}

Function SetGlobalEnvironment([string]$installPath)
{
	if($IncludeDotNetFramework)
	{
		[Environment]::SetEnvironmentVariable("COR_ENABLE_PROFILING", "1", "Machine")
		[Environment]::SetEnvironmentVariable("COR_PROFILER", $profilerId, "Machine")
		[Environment]::SetEnvironmentVariable("COR_PROFILER_PATH_64", (Join-Path $installPath "NETFramework\x64\ClrProfilerAgent.dll"), "Machine")
		[Environment]::SetEnvironmentVariable("COR_PROFILER_PATH_32", (Join-Path $installPath "NETFramework\x86\ClrProfilerAgent.dll"), "Machine")
	}
	[Environment]::SetEnvironmentVariable("CORECLR_ENABLE_PROFILING", "1", "Machine")
	[Environment]::SetEnvironmentVariable("CORECLR_PROFILER", $profilerId, "Machine")
	[Environment]::SetEnvironmentVariable("CORECLR_SITE24X7_HOME", $installPath, "Machine")		
	[Environment]::SetEnvironmentVariable("CORECLR_PROFILER_PATH_64", (Join-Path $installPath "x64\ClrProfilerAgent.dll"), "Machine")
	[Environment]::SetEnvironmentVariable("CORECLR_PROFILER_PATH_32", (Join-Path $installPath "x86\ClrProfilerAgent.dll"), "Machine")
	[Environment]::SetEnvironmentVariable("DOTNET_ADDITIONAL_DEPS", (Join-Path $installPath "additionalDeps;"), "Machine")
	[Environment]::SetEnvironmentVariable("DOTNET_SHARED_STORE", (Join-Path $installPath "store;"), "Machine")
	[Environment]::SetEnvironmentVariable("S247_LICENSE_KEY", $LicenseKey, "Machine")
	if($DisableAppFilter -and $AppName -ne "")
	{
		[Environment]::SetEnvironmentVariable("SITE24X7_APP_NAME", $AppName, "Machine")
	}
}

Function SetRegistryEnvironment([string]$registryPath, [string]$name, [string[]]$value, [string]$installPath)
{
	$exists = 0;
	
	try {
		Get-ItemProperty -Path $registryPath | Select-Object -ExpandProperty $name -ErrorAction Stop | Out-Null	
		$exists = 1;
	}
	catch {
		$exists = 0;
	}

	if ($exists -eq 0) {
		CreateNewRegistryItem $registryPath $name $value
	}
	else {
		try {
			$environmentString = (Get-ItemProperty -Path $registryPath -Name $name).Environment;
			$newEnvironmentValue = @();
			ForEach ($line in $($environmentString -split "`r`n")) {
				if($line.Contains("CORECLR_ENABLE_PROFILING=") -Or $line.Contains("CORECLR_PROFILER=") -Or $line.Contains("CORECLR_SITE24X7_HOME=") -Or $line.Contains("CORECLR_PROFILER_PATH_64=") -Or $line.Contains("CORECLR_PROFILER_PATH_32=") -Or $line.Contains("DOTNET_ADDITIONAL_DEPS=") -Or $line.Contains("DOTNET_SHARED_STORE=") -Or $line.Contains("S247_LICENSE_KEY=") -Or $line.Contains("SITE24X7_APP_NAME=") -Or
				($IncludeDotNetFramework -And ($line.Contains("COR_ENABLE_PROFILING=") -Or $line.Contains("COR_PROFILER=") -Or $line.Contains("COR_PROFILER_PATH_64=") -Or $line.Contains("COR_PROFILER_PATH_32=")))) {
				}
				else {
					$newEnvironmentValue += $line; 
				}
			}
			
			$newEnvironmentValue += $value;
			
			CreateNewRegistryItem $registryPath $name $newEnvironmentValue
		}
		catch {
			WRITE-WARNING "Failed modifying environment variable. Please contact support."
		}
	}
}

Function GetEnvironmentSettingValue([string]$installPath) 
{
	$environmentVal = @();
	if($IncludeDotNetFramework)
	{
		$environmentVal += "COR_ENABLE_PROFILING=1";
		$environmentVal += ("COR_PROFILER=" + $profilerId);
		$environmentVal += ("COR_PROFILER_PATH_64=" + (Join-Path $installPath "NETFramework\x64\ClrProfilerAgent.dll"));
		$environmentVal += ("COR_PROFILER_PATH_32=" + (Join-Path $installPath "NETFramework\x86\ClrProfilerAgent.dll"));
	}
	$environmentVal += "CORECLR_ENABLE_PROFILING=1";
	$environmentVal += ("CORECLR_PROFILER=" + $profilerId); 
	$environmentVal += ("CORECLR_SITE24X7_HOME=" + $installPath);
	$environmentVal += ("CORECLR_PROFILER_PATH_64=" + (Join-Path $installPath "x64\ClrProfilerAgent.dll")); 
	$environmentVal += ("CORECLR_PROFILER_PATH_32=" + (Join-Path $installPath "x86\ClrProfilerAgent.dll")); 
	$environmentVal += ("DOTNET_ADDITIONAL_DEPS=" + (Join-Path $installPath "additionalDeps;")); 
	$environmentVal += ("DOTNET_SHARED_STORE=" + (Join-Path $installPath "store;"));
	$environmentVal += ("S247_LICENSE_KEY=" + $LicenseKey);
	if($DisableAppFilter -and $AppName -ne "")
	{
		$environmentVal += ("SITE24X7_APP_NAME=" + $AppName);
	}
	
	return $environmentVal;
}

Function CreateNewRegistryItem([string]$registryPath, [string]$name, [string[]]$newRegistryValue) 
{
	New-ItemProperty -Path $registryPath `
		-Name $name `
		-Value $newRegistryValue `
		-PropertyType MultiString `
		-Force | Out-Null
}

Function IsAdmin() 
{
    ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
}

Function ValidateParameters() 
{
    if ($InstallType) { $InstallType = $InstallType.ToLower().Trim()}
    if ($Destination) { $Destination = $Destination.Trim()}
    if ($LicenseKey) { $LicenseKey = $LicenseKey.Trim()}
    if ($AppName) { $AppName = $AppName.Trim() }

    [bool] $flag = $false
	$Tab = [char]9
	
    If (-Not($Destination)) {
        Print-Color -message "$Tab * Please provide -Destination parameter." -Color Yellow
		$flag = $true
    }
    
    If (-Not($InstallType)) {
        Print-Color -message  "$Tab * Please provide -InstallType parameter as global or local." -Color Yellow
		$flag = $true
    }
    
    If (-Not($LicenseKey)) {
        Print-Color -message  "$Tab * Please provide -LicenseKey parameter." -Color Yellow
		$flag = $true
    }
	If ($IsBehindProxy) {
		If (-Not($ProxyHost)) {
			Print-Color -message  "$Tab * Please provide -ProxyHost parameter." -Color Yellow
			$flag = $true
		}
		If (-Not($ProxyPort)) {
			Print-Color -message  "$Tab * Please provide -ProxyPort parameter and the value should not be zero." -Color Yellow
			$flag = $true
		}
    }
	
	if($flag)
	{
		exit
	}
}

If ($Help) {
    Get-Content "InstallAgentHelp.txt"
    exit
}

Function CreateVersionInfoFile([string]$agentPath)
{
	$AgentVersion | Set-Content (Join-Path $agentPath "version.info")
}

Function CheckAdminRights() {
    If (-Not(IsAdmin) -And ($installType -eq "global")) {
        Write-Host "You must have administrator rights to install the agent globally. Please run this script from an elevated shell."
        exit
    }
    
    If (-Not(IsAdmin) -And $ResetIIS) {
        Write-Host "You must have administrator rights to perform an IISReset. Please run this script from an elevated shell."
        exit
    }
}

Function SetFolderPermissions($directory) {
	try
	{
		$acl = (Get-Item $directory).GetAccessControl('Access')
		$rule1 = New-Object System.Security.AccessControl.FileSystemAccessRule("IIS_IUSRS", "FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")
		$acl.AddAccessRule($rule1)
		$rule2 = New-Object System.Security.AccessControl.FileSystemAccessRule("BUILTIN\Administrators", "FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")
		$acl.AddAccessRule($rule2)
		$rule3 = New-Object System.Security.AccessControl.FileSystemAccessRule([System.Security.Principal.WindowsIdentity]::GetCurrent().Name, "FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")
		$acl.AddAccessRule($rule3)
		$acl.SetAccessRuleProtection($True,$False)
		Set-Acl $directory $acl
	}
	catch {
		WRITE-WARNING "Failed setting folder permission. Kindly ignore."
	}
}

function Encrypt-AES {
    param (
        [string]$originalStr
    )

    if (-not $originalStr) {
        throw "No String For Encryption"
    }

    try {
        $aesCrypt = New-Object System.Security.Cryptography.AesCryptoServiceProvider
		$Saltkey = Generate-RandomSaltKey -size 32
        $aesCrypt.Key = [Convert]::FromBase64String($Saltkey)
		$InitVector = Generate-RandomIV -size 16
        $aesCrypt.IV = [Convert]::FromBase64String($InitVector)
        $aesCrypt.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7
        $aesCrypt.Mode = [System.Security.Cryptography.CipherMode]::CBC

        $encryptor = $aesCrypt.CreateEncryptor()
        
        $msEncrypt = New-Object System.IO.MemoryStream
        $csEncrypt = New-Object System.Security.Cryptography.CryptoStream $msEncrypt, $encryptor, [System.Security.Cryptography.CryptoStreamMode]::Write
        $swEncrypt = New-Object System.IO.StreamWriter $csEncrypt
        $swEncrypt.Write($originalStr)
        $swEncrypt.Close()
        $csEncrypt.Close()
        $msEncrypt.Close()

        return [Convert]::ToBase64String($msEncrypt.ToArray())
    } catch {
        Write-Error "Error in Encrypt-AES: $_"
        throw
    }
}

function Generate-RandomSaltKey {
    param (
        [int]$size = 32
    )

    $salt = New-Object byte[] $size
    $rng = New-Object System.Security.Cryptography.RNGCryptoServiceProvider
    $rng.GetBytes($salt)
    return [Convert]::ToBase64String($salt)
}

function Generate-RandomIV {
    param (
        [int]$size = 16
    )

    $iv = New-Object byte[] $size
    $rng = New-Object System.Security.Cryptography.RNGCryptoServiceProvider
    $rng.GetBytes($iv)
    return [Convert]::ToBase64String($iv)
}

ValidateParameters
CheckAdminRights
InstallAgent

# SIG # Begin signature block
# MIIzfwYJKoZIhvcNAQcCoIIzcDCCM2wCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAMEIZDhV9XSciI
# qApDRVXAGP9iqKvCc3jbFiKRCC2TiqCCGAMwggROMIIDNqADAgECAg0B7l8Wnf+X
# NStkZdZqMA0GCSqGSIb3DQEBCwUAMFcxCzAJBgNVBAYTAkJFMRkwFwYDVQQKExBH
# bG9iYWxTaWduIG52LXNhMRAwDgYDVQQLEwdSb290IENBMRswGQYDVQQDExJHbG9i
# YWxTaWduIFJvb3QgQ0EwHhcNMTgwOTE5MDAwMDAwWhcNMjgwMTI4MTIwMDAwWjBM
# MSAwHgYDVQQLExdHbG9iYWxTaWduIFJvb3QgQ0EgLSBSMzETMBEGA1UEChMKR2xv
# YmFsU2lnbjETMBEGA1UEAxMKR2xvYmFsU2lnbjCCASIwDQYJKoZIhvcNAQEBBQAD
# ggEPADCCAQoCggEBAMwldpB5BngiFvXAg7aEyiie/QV2EcWtiHL8RgJDx7KKnQRf
# JMsuS+FggkbhUqsMgUdwbN1k0ev1LKMPgj0MK66X17YUhhB5uzsTgHeMCOFJ0mpi
# Lx9e+pZo34knlTifBtc+ycsmWQ1z3rDI6SYOgxXG71uL0gRgykmmKPZpO/bLyCiR
# 5Z2KYVc3rHQU3HTgOu5yLy6c+9C7v/U9AOEGM+iCK65TpjoWc4zdQQ4gOsC0p6Hp
# sk+QLjJg6VfLuQSSaGjlOCZgdbKfd/+RFO+uIEn8rUAVSNECMWEZXriX7613t2Sa
# er9fwRPvm2L7DWzgVGkWqQPabumDk3F2xmmFghcCAwEAAaOCASIwggEeMA4GA1Ud
# DwEB/wQEAwIBBjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBSP8Et/qC5FJK5N
# UPpjmove4t0bvDAfBgNVHSMEGDAWgBRge2YaRQ2XyolQL30EzTSo//z9SzA9Bggr
# BgEFBQcBAQQxMC8wLQYIKwYBBQUHMAGGIWh0dHA6Ly9vY3NwLmdsb2JhbHNpZ24u
# Y29tL3Jvb3RyMTAzBgNVHR8ELDAqMCigJqAkhiJodHRwOi8vY3JsLmdsb2JhbHNp
# Z24uY29tL3Jvb3QuY3JsMEcGA1UdIARAMD4wPAYEVR0gADA0MDIGCCsGAQUFBwIB
# FiZodHRwczovL3d3dy5nbG9iYWxzaWduLmNvbS9yZXBvc2l0b3J5LzANBgkqhkiG
# 9w0BAQsFAAOCAQEAI3Dpz+K+9VmulEJvxEMzqs0/OrlkF/JiBktI8UCIBheh/qvR
# XzzGM/Lzjt0fHT7MGmCZggusx/x+mocqpX0PplfurDtqhdbevUBj+K2myIiwEvz2
# Qd8PCZceOOpTn74F9D7q059QEna+CYvCC0h9Hi5R9o1T06sfQBuKju19+095VnBf
# DNOOG7OncA03K5eVq9rgEmscQM7Fx37twmJY7HftcyLCivWGQ4it6hNu/dj+Qi+5
# fV6tGO+UkMo9J6smlJl1x8vTe/fKTNOvUSGSW4R9K58VP3TLUeiegw4WbxvnRs4j
# vfnkoovSOWuqeRyRLOJhJC2OKkhwkMQexejgcDCCBaIwggSKoAMCAQICEHgDGEJF
# cIpBz28BuO60qVQwDQYJKoZIhvcNAQEMBQAwTDEgMB4GA1UECxMXR2xvYmFsU2ln
# biBSb290IENBIC0gUjMxEzARBgNVBAoTCkdsb2JhbFNpZ24xEzARBgNVBAMTCkds
# b2JhbFNpZ24wHhcNMjAwNzI4MDAwMDAwWhcNMjkwMzE4MDAwMDAwWjBTMQswCQYD
# VQQGEwJCRTEZMBcGA1UEChMQR2xvYmFsU2lnbiBudi1zYTEpMCcGA1UEAxMgR2xv
# YmFsU2lnbiBDb2RlIFNpZ25pbmcgUm9vdCBSNDUwggIiMA0GCSqGSIb3DQEBAQUA
# A4ICDwAwggIKAoICAQC2LcUw3Xroq5A9A3KwOkuZFmGy5f+lZx03HOV+7JODqoT1
# o0ObmEWKuGNXXZsAiAQl6fhokkuC2EvJSgPzqH9qj4phJ72hRND99T8iwqNPkY2z
# BbIogpFd+1mIBQuXBsKY+CynMyTuUDpBzPCgsHsdTdKoWDiW6d/5G5G7ixAs0sdD
# HaIJdKGAr3vmMwoMWWuOvPSrWpd7f65V+4TwgP6ETNfiur3EdaFvvWEQdESymAfi
# dKv/aNxsJj7pH+XgBIetMNMMjQN8VbgWcFwkeCAl62dniKu6TjSYa3AR3jjK1L6h
# wJzh3x4CAdg74WdDhLbP/HS3L4Sjv7oJNz1nbLFFXBlhq0GD9awd63cNRkdzzr+9
# lZXtnSuIEP76WOinV+Gzz6ha6QclmxLEnoByPZPcjJTfO0TmJoD80sMD8IwM0kXW
# LuePmJ7mBO5Cbmd+QhZxYucE+WDGZKG2nIEhTivGbWiUhsaZdHNnMXqR8tSMeW58
# prt+Rm9NxYUSK8+aIkQIqIU3zgdhVwYXEiTAxDFzoZg1V0d+EDpF2S2kUZCYqaAH
# N8RlGqocaxZ396eX7D8ZMJlvMfvqQLLn0sT6ydDwUHZ0WfqNbRcyvvjpfgP054d1
# mtRKkSyFAxMCK0KA8olqNs/ITKDOnvjLja0Wp9Pe1ZsYp8aSOvGCY/EuDiRk3wID
# AQABo4IBdzCCAXMwDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMD
# MA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFB8Av0aACvx4ObeltEPZVlC7zpY7
# MB8GA1UdIwQYMBaAFI/wS3+oLkUkrk1Q+mOai97i3Ru8MHoGCCsGAQUFBwEBBG4w
# bDAtBggrBgEFBQcwAYYhaHR0cDovL29jc3AuZ2xvYmFsc2lnbi5jb20vcm9vdHIz
# MDsGCCsGAQUFBzAChi9odHRwOi8vc2VjdXJlLmdsb2JhbHNpZ24uY29tL2NhY2Vy
# dC9yb290LXIzLmNydDA2BgNVHR8ELzAtMCugKaAnhiVodHRwOi8vY3JsLmdsb2Jh
# bHNpZ24uY29tL3Jvb3QtcjMuY3JsMEcGA1UdIARAMD4wPAYEVR0gADA0MDIGCCsG
# AQUFBwIBFiZodHRwczovL3d3dy5nbG9iYWxzaWduLmNvbS9yZXBvc2l0b3J5LzAN
# BgkqhkiG9w0BAQwFAAOCAQEArPfMFYsweagdCyiIGQnXHH/+hr17WjNuDWcOe2LZ
# 4RhcsL0TXR0jrjlQdjeqRP1fASNZhlZMzK28ZBMUMKQgqOA/6Jxy3H7z2Awjuqgt
# qjz27J+HMQdl9TmnUYJ14fIvl/bR4WWWg2T+oR1R+7Ukm/XSd2m8hSxc+lh30a6n
# sQvi1ne7qbQ0SqlvPfTzDZVd5vl6RbAlFzEu2/cPaOaDH6n35dSdmIzTYUsvwyh+
# et6TDrR9oAptksS0Zj99p1jurPfswwgBqzj8ChypxZeyiMgJAhn2XJoa8U1sMNSz
# BqsAYEgNeKvPF62Sk2Igd3VsvcgytNxN69nfwZCWKb3BfzCCBuYwggTOoAMCAQIC
# EHe9DgOhtwj4VKsGchDZBEcwDQYJKoZIhvcNAQELBQAwUzELMAkGA1UEBhMCQkUx
# GTAXBgNVBAoTEEdsb2JhbFNpZ24gbnYtc2ExKTAnBgNVBAMTIEdsb2JhbFNpZ24g
# Q29kZSBTaWduaW5nIFJvb3QgUjQ1MB4XDTIwMDcyODAwMDAwMFoXDTMwMDcyODAw
# MDAwMFowWTELMAkGA1UEBhMCQkUxGTAXBgNVBAoTEEdsb2JhbFNpZ24gbnYtc2Ex
# LzAtBgNVBAMTJkdsb2JhbFNpZ24gR0NDIFI0NSBDb2RlU2lnbmluZyBDQSAyMDIw
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA1kJN+eNPxiP0bB2BpjD3
# SD3P0OWN5SAilgdENV0Gzw8dcGDmJlT6UyNgAqhfAgL3jsluPal4Bb2O9U8ZJJl8
# zxEWmx97a9Kje2hld6vYsSw/03IGMlxbrFBnLCVNVgY2/MFiTH19hhaVml1UulDQ
# sH+iRBnp1m5sPhPCnxHUXzRbUWgxYwr4W9DeullfMa+JaDhAPgjoU2dOY7Yhju/d
# jYVBVZ4cvDfclaDEcacfG6VJbgogWX6Jo1gVlwAlad/ewmpQZU5T+2uhnxgeig5f
# VF694FvP8gwE0t4IoRAm97Lzei7CjpbBP86l2vRZKIw3ZaExlguOpHZ3FUmEZoIl
# 50MKd1KxmVFC/6Gy3ZzS3BjZwYapQB1Bl2KGvKj/osdjFwb9Zno2lAEgiXgfkPR7
# qVJOak9UBiqAr57HUEL6ZQrjAfSxbqwOqOOBGag4yJ4DKIakdKdHlX5yWip7FWoc
# xGnmsL5AGZnL0n1VTiKcEOChW8OzLnqLxN7xSx+MKHkwRX9sE7Y9LP8tSooq7CgP
# LcrUnJiKSm1aNiwv37rL4kFKCHcYiK01YZQS86Ry6+42nqdRJ5E896IazPyH5Zfh
# UYdp6SLMg8C3D0VsB+FDT9SMSs7PY7G1pBB6+Q0MKLBrNP4haCdv7Pj6JoRbdULN
# iSZ5WZ1rq2NxYpAlDQgg8f8CAwEAAaOCAa4wggGqMA4GA1UdDwEB/wQEAwIBhjAT
# BgNVHSUEDDAKBggrBgEFBQcDAzASBgNVHRMBAf8ECDAGAQH/AgEAMB0GA1UdDgQW
# BBTas43AJJCja3fTDKBZ3SFnZHYLeDAfBgNVHSMEGDAWgBQfAL9GgAr8eDm3pbRD
# 2VZQu86WOzCBkwYIKwYBBQUHAQEEgYYwgYMwOQYIKwYBBQUHMAGGLWh0dHA6Ly9v
# Y3NwLmdsb2JhbHNpZ24uY29tL2NvZGVzaWduaW5ncm9vdHI0NTBGBggrBgEFBQcw
# AoY6aHR0cDovL3NlY3VyZS5nbG9iYWxzaWduLmNvbS9jYWNlcnQvY29kZXNpZ25p
# bmdyb290cjQ1LmNydDBBBgNVHR8EOjA4MDagNKAyhjBodHRwOi8vY3JsLmdsb2Jh
# bHNpZ24uY29tL2NvZGVzaWduaW5ncm9vdHI0NS5jcmwwVgYDVR0gBE8wTTBBBgkr
# BgEEAaAyATIwNDAyBggrBgEFBQcCARYmaHR0cHM6Ly93d3cuZ2xvYmFsc2lnbi5j
# b20vcmVwb3NpdG9yeS8wCAYGZ4EMAQQBMA0GCSqGSIb3DQEBCwUAA4ICAQAIiHIm
# xq/6rF8GwKqMkNrQssCil/9uEzIWVP0+9DARn4+Y+ZtS3fKiFu7ZeJWmmnxhuAS1
# +OvL9GERM/ZlJbcRQovYaW7H/5W0gUOpfq6/gtZNzBGjg3FqEF4ZBafnbH9W9Khc
# w04JrVlruPl+pS64/N4OwqD7sATUExvHJ6m5qi0xO89GTJ3rTOy8Lpzxh6N/OGlf
# QUBn9lN96kHvjj37qdQROEbfPOv2zSK9E83w4eblM6C+POR41RvMIPIwc7AiHPaE
# 1ptcAALhKFJL/xJLQOrusBoGBp6E5ufw24RG+3PZK0K2yVc0xxbApushuaoO9/7b
# yuu8F8u4Z+vjPk/bqZSGZFXJCQrA2QRxShFLWmTDvHh4rUxHJmUHmdXNNmChM1Oz
# 9nsq1YlAPHGlq/iZWf3jm5JL3QW9Cwx4BivPU9i9EppbJ4aFP5G+4HiAc1Tfpx1n
# K2q2rk2JgCQIUnBQ8wH/RK4vmuDhSQjh4VvXONGeCoqdlCebyqO52+I2auNvuVhi
# 4DZ4NgH6waeJeiZTo1y70rLristjCC/+HvNWKeI1m9j/6aW9bUtZLIksL1K7tSmQ
# 2kNHvHLdvNm/gMHcsKu0Sx1YNjdk65vhhReaKaL95gjSkv+g+Hzh6afRMI5fJlAr
# x6Lil3eK79hNPibrmUBg8zxnDLYIcik1U4E03DCCBx0wggUFoAMCAQICDESFWejV
# n+BWKZ5ujzANBgkqhkiG9w0BAQsFADBZMQswCQYDVQQGEwJCRTEZMBcGA1UEChMQ
# R2xvYmFsU2lnbiBudi1zYTEvMC0GA1UEAxMmR2xvYmFsU2lnbiBHQ0MgUjQ1IENv
# ZGVTaWduaW5nIENBIDIwMjAwHhcNMjMxMjExMTcwMDM2WhcNMjYxMDA5MDc0MDU4
# WjCBijELMAkGA1UEBhMCSU4xEzARBgNVBAgTClRhbWlsIE5hZHUxEDAOBgNVBAcT
# B0NoZW5uYWkxKTAnBgNVBAoTIFpPSE8gQ29ycG9yYXRpb24gUHJpdmF0ZSBMaW1p
# dGVkMSkwJwYDVQQDEyBaT0hPIENvcnBvcmF0aW9uIFByaXZhdGUgTGltaXRlZDCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAIv3aVIEAUL2uenwgJAgsw6f
# /MPdcNb9g1z/B/dStszWc6nv3v50+eFt/pPGZptdHPG0yDbvXL+Iu9Z4x4SJmgDO
# +vMtHzTymdri0thZ+Y5Xn5sHDY9IhrqiF2iGouAvG9YixX+7ZwJr7/BwAmev4H4V
# eHYkT2LAlhftKLiWhTnwz6z2w1dGXehgr0IXutgclVstDYXLBOFRUjf8ZVbI7OF9
# y/Xa9SNwIwPRBztwn+j66qnTBhBr3kcAn0mol7kO2C5ZwASkV8bnF911/kRhNrWx
# SfQpWH+QZhAXwUzoKQcTzZiXcgzk2TqbKvDlo+ARmKvTJrZt7kvlVafXE4MIB6rk
# iUGJHAqSNc26pZZTVyjB+2uIA+3IYQf2NmkFH8Hg1zWb74hQ0X92F4pblYhZzzHY
# Dpu6pbmlvCMsR6AiywCw6BL8LwB6c06z0YWMGWDJfOOfbqTVgtQHbn2YQXDtrwMS
# 5hgUS3qLZ54CowbY1ES89UciATNFZyg/tJEtO0o9zFy8SaUVGRRP9Zoz3dC41D+a
# xaYzJkFD0vw4L4e3VkZH1MwAv8mYh7Qos/0jAQRwmLGQDDacInGsZBcHnc8C744m
# t4PCJ/vYl1jLH4CQ3ioGk384AYHP0H/WgCAXFFNOvIYBWBGXPJV80g1bvmUGfdOc
# OP+jGgHX1oP6mjaX0X7dAgMBAAGjggGxMIIBrTAOBgNVHQ8BAf8EBAMCB4AwgZsG
# CCsGAQUFBwEBBIGOMIGLMEoGCCsGAQUFBzAChj5odHRwOi8vc2VjdXJlLmdsb2Jh
# bHNpZ24uY29tL2NhY2VydC9nc2djY3I0NWNvZGVzaWduY2EyMDIwLmNydDA9Bggr
# BgEFBQcwAYYxaHR0cDovL29jc3AuZ2xvYmFsc2lnbi5jb20vZ3NnY2NyNDVjb2Rl
# c2lnbmNhMjAyMDBWBgNVHSAETzBNMEEGCSsGAQQBoDIBMjA0MDIGCCsGAQUFBwIB
# FiZodHRwczovL3d3dy5nbG9iYWxzaWduLmNvbS9yZXBvc2l0b3J5LzAIBgZngQwB
# BAEwCQYDVR0TBAIwADBFBgNVHR8EPjA8MDqgOKA2hjRodHRwOi8vY3JsLmdsb2Jh
# bHNpZ24uY29tL2dzZ2NjcjQ1Y29kZXNpZ25jYTIwMjAuY3JsMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFNqzjcAkkKNrd9MMoFndIWdkdgt4MB0GA1Ud
# DgQWBBQAEYFD6bVlLVlpKYdhLAjp9JgOnTANBgkqhkiG9w0BAQsFAAOCAgEAhvMF
# 2tjnlwBnEkHISuHLDUQPA9YtCX1xxUHFUMvf85Flz0WFpW3GoGy0Zj831s2tSVbV
# 7mIptXjkMx7yUHMgeu01ptEWPqEEfAmKJz9ewSbyP0xt8bDHdG/YNnV6V+umbBRR
# 3qaRqnErOXp4ZnGKCAoD5XtZwqvncWpvYUGzLh1kzU9ThCm/fn0ywv5/pdvzt0To
# QFBxTwvsbhYP+p9icosezdSV+3Fr4LT3kAs/6bXEQjBd2tZdBS0W93GKvXTJQTGI
# g2515rygwEj0R+sAOyxNy31RUTgi54/2OhRJ3rQUGwxZ9IonTfTBp659J3Xk+JPv
# NhsdIEVcr9PNy9V3CZ7MpQwUBOqiaULYr+5WKOrbbeZKUI+zVIRH0PyKr0z5y3hk
# em5bhDsjfuKQignV1sIMngC++gQaI27gz/RLDCxsvX+6IelsDaAAPnYGevvDqyN7
# ksIw2+jBs7BWMk/SRjxHCBb3u3U3BZfVfR3JjJng4dMi5EV0wrws2fGMmFdPZTps
# 2M1akw6ruwA7pCc69faOGbqcLw52y4+oxOfHJM/zpgQ75AtmgYN3nh1G/L+ZsNa5
# II6e8wsCbwryw6vVu0g2TxdQ2RaTeNje2ROKgoq++cwKUp7AYQvzVLB1OddsTYxh
# qkXuVpQEtgvWqZOAv9SRi3lRap1Ycg045uMShwoxghrSMIIazgIBATBpMFkxCzAJ
# BgNVBAYTAkJFMRkwFwYDVQQKExBHbG9iYWxTaWduIG52LXNhMS8wLQYDVQQDEyZH
# bG9iYWxTaWduIEdDQyBSNDUgQ29kZVNpZ25pbmcgQ0EgMjAyMAIMRIVZ6NWf4FYp
# nm6PMA0GCWCGSAFlAwQCAQUAoIHAMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqGSIb3DQEJBDEiBCAm
# b2X+hEJXS9UDPVfVMxc+RGrzIwuLQafcqfqmwcWS6jBUBgorBgEEAYI3AgEMMUYw
# RKBCgEAAWgBPAEgATwAgAEMAbwByAHAAbwByAGEAdABpAG8AbgAgAFAAcgBpAHYA
# YQB0AGUAIABMAGkAbQBpAHQAZQBkMA0GCSqGSIb3DQEBAQUABIICAGeNQL++Q6XR
# eTIH0MzTZjbcCDI/6s9vltO3y5FyaOfYbqpSOr05BoczOeSVkeBsVJfai+Vp8vE3
# L2UOLln5TaIyZwgiVnHfwxal6gynWwShrmp7yein3UFjZz2K1O3gCOfN5tMeBy5l
# YJz4iCuPuegdUXjItnQwunivwffu3N5UBlW5XvXq0X6n+gfcJUW/D3oivQClu5ZP
# m4yjoJ+FdEnBLvI6Kgsg6KxDqOEmwBmM2T29a3soTlKi9akFBN81nTp594nQV5E9
# /xIcs1gx12w4wog0WI3RxFxJ3bGoO/cA4Qc/wKCYaKuKa56VNaf8GvS/8MO3ojYr
# IlHP4aSPBvKBHlw/0RW3fcMDa2sspiXZApDYdbqGY/85jHewtKfUrvQZwY3uB3a5
# Qi2teos6mtzd0yAfJUBCIk2yoe0p365zR3aAzJVEIAsa/7lpzYUv0nkptu28lGlV
# IqSyinI9n462hejbs0UD3C18dfXZRON/1dpE3IkyUapLA3/qb+sL0+52A7SlnxTR
# GuB030l94cX0pf4cjKEdannhG5yUCnRROVRti5Nvf237g9x1FKPZAyC8bWSq3Bkg
# cqcyx7dqwo746f7pPMfGcvJ3xg3aChP5aPT/DO0po5eLeruJ8q46gp5hrFvv0wK7
# +OVS7ARtFvtJuK3Zfdns2whQJY84EZ9woYIXdzCCF3MGCisGAQQBgjcDAwExghdj
# MIIXXwYJKoZIhvcNAQcCoIIXUDCCF0wCAQMxDzANBglghkgBZQMEAgEFADB4Bgsq
# hkiG9w0BCRABBKBpBGcwZQIBAQYJYIZIAYb9bAcBMDEwDQYJYIZIAWUDBAIBBQAE
# IPp7YT5Kcq2DlQgAE4tVzozv6kP6yLVTZoutmlOfPJRWAhEA4KaYRs+udU0gCEb9
# GjDObxgPMjAyNTA2MTkxMDU4MzdaoIITOjCCBu0wggTVoAMCAQICEAqA7xhLjfEF
# gtHEdqeVdGgwDQYJKoZIhvcNAQELBQAwaTELMAkGA1UEBhMCVVMxFzAVBgNVBAoT
# DkRpZ2lDZXJ0LCBJbmMuMUEwPwYDVQQDEzhEaWdpQ2VydCBUcnVzdGVkIEc0IFRp
# bWVTdGFtcGluZyBSU0E0MDk2IFNIQTI1NiAyMDI1IENBMTAeFw0yNTA2MDQwMDAw
# MDBaFw0zNjA5MDMyMzU5NTlaMGMxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdp
# Q2VydCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNlcnQgU0hBMjU2IFJTQTQwOTYgVGlt
# ZXN0YW1wIFJlc3BvbmRlciAyMDI1IDEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDQRqwtEsae0OquYFazK1e6b1H/hnAKAd/KN8wZQjBjMqiZ3xTWcfsL
# wOvRxUwXcGx8AUjni6bz52fGTfr6PHRNv6T7zsf1Y/E3IU8kgNkeECqVQ+3bzWYe
# sFtkepErvUSbf+EIYLkrLKd6qJnuzK8Vcn0DvbDMemQFoxQ2Dsw4vEjoT1FpS54d
# NApZfKY61HAldytxNM89PZXUP/5wWWURK+IfxiOg8W9lKMqzdIo7VA1R0V3Zp3Dj
# jANwqAf4lEkTlCDQ0/fKJLKLkzGBTpx6EYevvOi7XOc4zyh1uSqgr6UnbksIcFJq
# LbkIXIPbcNmA98Oskkkrvt6lPAw/p4oDSRZreiwB7x9ykrjS6GS3NR39iTTFS+EN
# TqW8m6THuOmHHjQNC3zbJ6nJ6SXiLSvw4Smz8U07hqF+8CTXaETkVWz0dVVZw7kn
# h1WZXOLHgDvundrAtuvz0D3T+dYaNcwafsVCGZKUhQPL1naFKBy1p6llN3QgshRt
# a6Eq4B40h5avMcpi54wm0i2ePZD5pPIssoszQyF4//3DoK2O65Uck5Wggn8O2klE
# TsJ7u8xEehGifgJYi+6I03UuT1j7FnrqVrOzaQoVJOeeStPeldYRNMmSF3voIgMF
# tNGh86w3ISHNm0IaadCKCkUe2LnwJKa8TIlwCUNVwppwn4D3/Pt5pwIDAQABo4IB
# lTCCAZEwDAYDVR0TAQH/BAIwADAdBgNVHQ4EFgQU5Dv88jHt/f3X85FxYxlQQ89h
# jOgwHwYDVR0jBBgwFoAU729TSunkBnx6yuKQVvYv1Ensy04wDgYDVR0PAQH/BAQD
# AgeAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMIGVBggrBgEFBQcBAQSBiDCBhTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMF0GCCsGAQUFBzAC
# hlFodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRU
# aW1lU3RhbXBpbmdSU0E0MDk2U0hBMjU2MjAyNUNBMS5jcnQwXwYDVR0fBFgwVjBU
# oFKgUIZOaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0
# VGltZVN0YW1waW5nUlNBNDA5NlNIQTI1NjIwMjVDQTEuY3JsMCAGA1UdIAQZMBcw
# CAYGZ4EMAQQCMAsGCWCGSAGG/WwHATANBgkqhkiG9w0BAQsFAAOCAgEAZSqt8Rwn
# BLmuYEHs0QhEnmNAciH45PYiT9s1i6UKtW+FERp8FgXRGQ/YAavXzWjZhY+hIfP2
# JkQ38U+wtJPBVBajYfrbIYG+Dui4I4PCvHpQuPqFgqp1PzC/ZRX4pvP/ciZmUnth
# fAEP1HShTrY+2DE5qjzvZs7JIIgt0GCFD9ktx0LxxtRQ7vllKluHWiKk6FxRPyUP
# xAAYH2Vy1lNM4kzekd8oEARzFAWgeW3az2xejEWLNN4eKGxDJ8WDl/FQUSntbjZ8
# 0FU3i54tpx5F/0Kr15zW/mJAxZMVBrTE2oi0fcI8VMbtoRAmaaslNXdCG1+lqvP4
# FbrQ6IwSBXkZagHLhFU9HCrG/syTRLLhAezu/3Lr00GrJzPQFnCEH1Y58678Igmf
# ORBPC1JKkYaEt2OdDh4GmO0/5cHelAK2/gTlQJINqDr6JfwyYHXSd+V08X1JUPvB
# 4ILfJdmL+66Gp3CSBXG6IwXMZUXBhtCyIaehr0XkBoDIGMUG1dUtwq1qmcwbdUfc
# SYCn+OwncVUXf53VJUNOaMWMts0VlRYxe5nK+At+DI96HAlXHAL5SlfYxJ7La54i
# 71McVWRP66bW+yERNpbJCjyCYG2j+bdpxo/1Cy4uPcU3AWVPGrbn5PhDBf3Frogu
# zzhk++ami+r3Qrx5bIbY3TVzgiFI7Gq3zWcwgga0MIIEnKADAgECAhANx6xXBf8h
# mS5AQyIMOkmGMA0GCSqGSIb3DQEBCwUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yNTA1MDcwMDAwMDBaFw0z
# ODAxMTQyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3RhbXBpbmcg
# UlNBNDA5NiBTSEEyNTYgMjAyNSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQC0eDHTCphBcr48RsAcrHXbo0ZodLRRF51NrY0NlLWZloMsVO1DahGP
# NRcybEKq+RuwOnPhof6pvF4uGjwjqNjfEvUi6wuim5bap+0lgloM2zX4kftn5B1I
# pYzTqpyFQ/4Bt0mAxAHeHYNnQxqXmRinvuNgxVBdJkf77S2uPoCj7GH8BLuxBG5A
# vftBdsOECS1UkxBvMgEdgkFiDNYiOTx4OtiFcMSkqTtF2hfQz3zQSku2Ws3IfDRe
# b6e3mmdglTcaarps0wjUjsZvkgFkriK9tUKJm/s80FiocSk1VYLZlDwFt+cVFBUR
# Jg6zMUjZa/zbCclF83bRVFLeGkuAhHiGPMvSGmhgaTzVyhYn4p0+8y9oHRaQT/ao
# fEnS5xLrfxnGpTXiUOeSLsJygoLPp66bkDX1ZlAeSpQl92QOMeRxykvq6gbylsXQ
# skBBBnGy3tW/AMOMCZIVNSaz7BX8VtYGqLt9MmeOreGPRdtBx3yGOP+rx3rKWDEJ
# lIqLXvJWnY0v5ydPpOjL6s36czwzsucuoKs7Yk/ehb//Wx+5kMqIMRvUBDx6z1ev
# +7psNOdgJMoiwOrUG2ZdSoQbU2rMkpLiQ6bGRinZbI4OLu9BMIFm1UUl9VnePs6B
# aaeEWvjJSjNm2qA+sdFUeEY0qVjPKOWug/G6X5uAiynM7Bu2ayBjUwIDAQABo4IB
# XTCCAVkwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQU729TSunkBnx6yuKQ
# VvYv1Ensy04wHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMIMHcGCCsGAQUFBwEBBGswaTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAC
# hjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAgBgNVHSAEGTAXMAgGBmeBDAEE
# AjALBglghkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggIBABfO+xaAHP4HPRF2cTC9
# vgvItTSmf83Qh8WIGjB/T8ObXAZz8OjuhUxjaaFdleMM0lBryPTQM2qEJPe36zwb
# SI/mS83afsl3YTj+IQhQE7jU/kXjjytJgnn0hvrV6hqWGd3rLAUt6vJy9lMDPjTL
# xLgXf9r5nWMQwr8Myb9rEVKChHyfpzee5kH0F8HABBgr0UdqirZ7bowe9Vj2AIMD
# 8liyrukZ2iA/wdG2th9y1IsA0QF8dTXqvcnTmpfeQh35k5zOCPmSNq1UH410ANVk
# o43+Cdmu4y81hjajV/gxdEkMx1NKU4uHQcKfZxAvBAKqMVuqte69M9J6A47OvgRa
# Ps+2ykgcGV00TYr2Lr3ty9qIijanrUR3anzEwlvzZiiyfTPjLbnFRsjsYg39OlV8
# cipDoq7+qNNjqFzeGxcytL5TTLL4ZaoBdqbhOhZ3ZRDUphPvSRmMThi0vw9vODRz
# W6AxnJll38F0cuJG7uEBYTptMSbhdhGQDpOXgpIUsWTjd6xpR6oaQf/DJbg3s6KC
# LPAlZ66RzIg9sC+NJpud/v4+7RWsWCiKi9EOLLHfMR2ZyJ/+xhCx9yHbxtl5TPau
# 1j/1MIDpMPx0LckTetiSuEtQvLsNz3Qbp7wGWqbIiOWCnb5WqxL3/BAPvIXKUjPS
# xyZsq8WhbaM2tszWkPZPubdcMIIFjTCCBHWgAwIBAgIQDpsYjvnQLefv21DiCEAY
# WjANBgkqhkiG9w0BAQwFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNl
# cnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdp
# Q2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMjIwODAxMDAwMDAwWhcNMzExMTA5
# MjM1OTU5WjBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkw
# FwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhEaWdpQ2VydCBUcnVz
# dGVkIFJvb3QgRzQwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC/5pBz
# aN675F1KPDAiMGkz7MKnJS7JIT3yithZwuEppz1Yq3aaza57G4QNxDAf8xukOBbr
# VsaXbR2rsnnyyhHS5F/WBTxSD1Ifxp4VpX6+n6lXFllVcq9ok3DCsrp1mWpzMpTR
# EEQQLt+C8weE5nQ7bXHiLQwb7iDVySAdYyktzuxeTsiT+CFhmzTrBcZe7FsavOvJ
# z82sNEBfsXpm7nfISKhmV1efVFiODCu3T6cw2Vbuyntd463JT17lNecxy9qTXtyO
# j4DatpGYQJB5w3jHtrHEtWoYOAMQjdjUN6QuBX2I9YI+EJFwq1WCQTLX2wRzKm6R
# AXwhTNS8rhsDdV14Ztk6MUSaM0C/CNdaSaTC5qmgZ92kJ7yhTzm1EVgX9yRcRo9k
# 98FpiHaYdj1ZXUJ2h4mXaXpI8OCiEhtmmnTK3kse5w5jrubU75KSOp493ADkRSWJ
# tppEGSt+wJS00mFt6zPZxd9LBADMfRyVw4/3IbKyEbe7f/LVjHAsQWCqsWMYRJUa
# dmJ+9oCw++hkpjPRiQfhvbfmQ6QYuKZ3AeEPlAwhHbJUKSWJbOUOUlFHdL4mrLZB
# dd56rF+NP8m800ERElvlEFDrMcXKchYiCd98THU/Y+whX8QgUWtvsauGi0/C1kVf
# nSD8oR7FwI+isX4KJpn15GkvmB0t9dmpsh3lGwIDAQABo4IBOjCCATYwDwYDVR0T
# AQH/BAUwAwEB/zAdBgNVHQ4EFgQU7NfjgtJxXWRM3y5nP+e6mK4cD08wHwYDVR0j
# BBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wDgYDVR0PAQH/BAQDAgGGMHkGCCsG
# AQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29t
# MEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNl
# cnRBc3N1cmVkSURSb290Q0EuY3J0MEUGA1UdHwQ+MDwwOqA4oDaGNGh0dHA6Ly9j
# cmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwEQYD
# VR0gBAowCDAGBgRVHSAAMA0GCSqGSIb3DQEBDAUAA4IBAQBwoL9DXFXnOF+go3Qb
# PbYW1/e/Vwe9mqyhhyzshV6pGrsi+IcaaVQi7aSId229GhT0E0p6Ly23OO/0/4C5
# +KH38nLeJLxSA8hO0Cre+i1Wz/n096wwepqLsl7Uz9FDRJtDIeuWcqFItJnLnU+n
# BgMTdydE1Od/6Fmo8L8vC6bp8jQ87PcDx4eo0kxAGTVGamlUsLihVo7spNU96LHc
# /RzY9HdaXFSMb++hUD38dglohJ9vytsgjTVgHAIDyyCwrFigDkBjxZgiwbJZ9VVr
# zyerbHbObyMt9H5xaiNrIv8SuFQtJ37YOtnwtoeW/VvRXKwYw02fc7cBqZ9Xql4o
# 4rmUMYIDfDCCA3gCAQEwfTBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNl
# cnQsIEluYy4xQTA/BgNVBAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgVGltZVN0YW1w
# aW5nIFJTQTQwOTYgU0hBMjU2IDIwMjUgQ0ExAhAKgO8YS43xBYLRxHanlXRoMA0G
# CWCGSAFlAwQCAQUAoIHRMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAcBgkq
# hkiG9w0BCQUxDxcNMjUwNjE5MTA1ODM3WjArBgsqhkiG9w0BCRACDDEcMBowGDAW
# BBTdYjCshgotMGvaOLFoeVIwB/tBfjAvBgkqhkiG9w0BCQQxIgQgnSs/CsaYjwLC
# 9PjZkQCXv5LB8qtYQGCwkm9cG7DzegowNwYLKoZIhvcNAQkQAi8xKDAmMCQwIgQg
# SqA/oizXXITFXJOPgo5na5yuyrM/420mmqM08UYRCjMwDQYJKoZIhvcNAQEBBQAE
# ggIAgvQdjjnopoT6DCcZYGDhWRiUFajYiPeYsXWwbo3hQ6Hdg3lwqABJWw1QeFXa
# IM3yi708KBu9tVgRcYvTMVO8gC3QtUKGETv0Zkz5sNHVkb2wXYJUYsp2Lc0bfex3
# 6K0kbU1eUGM/bKaWYp3hkM+btl6KZDZC8zJ2n1LsFAN7WoMr3WpMqEBw+j6L7SWq
# GZNGlrP7Oxth8FXQ1X0jVwu5tl2qc5O6lvHc0aIFU5fn/Xi98OYmxvuijnyy9Men
# QV5rey4chMafOlmUjpC9N1ypFTNAx/mT5A30OULGgmcLUZD6+6KT8+5Q3VPO4mF3
# scHQcPtzQ64r7HqiBUdYfHofZzs4gzDiLhdXg37fubWMmhXduitrlPflCb5zmX6n
# pPS+ATtm5Bh5/6eS1gcCfrX+ZoO9eXmnvFPdcBfmFkhlqkpKw/iQxHpC7COmE8Hk
# mbRde1apC7RrbYX0Jo65fpFbl814ycFBeT4F2EvkS32WC1gcm/Tv+VkogsGRFML9
# 6XMTVrScK4YNjyG2Fm9et1LLYeo9Mv58IS33tNHslSzo5LGfVJVLgjnqc0WVzFVw
# lRrN2qYI69rJE/QtTk5ROD6WR/dGqEW0rOSydpLmrtnRsv30IjLJHIaXlKTnEwmW
# rcvDTCCG75uxilRqqlgXS08hFz5bybYZ/Lfbn55hv638sF0=
# SIG # End signature block
