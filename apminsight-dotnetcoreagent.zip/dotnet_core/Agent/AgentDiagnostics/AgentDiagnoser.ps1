﻿Write-Progress -Activity "Collecting diagnostics information for .NET Core agent" -Status "Please wait"  

try
{
$w3svc = Get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W3SVC 
$was = Get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\WAS 
$OFS = "`r`n"

$parentPath = Split-Path $PSScriptRoot -Parent
$versionPath = (Join-Path $parentPath "version.info")	

$AgentDiagnosticsPath = ".\AgentDiagnostics"

if (Test-Path $AgentDiagnosticsPath) { Remove-Item $AgentDiagnosticsPath -Recurse; }

$result = New-Item -ItemType directory -Path $AgentDiagnosticsPath
$path = (Resolve-Path -Path $AgentDiagnosticsPath).Path
$applicationEventLog = "$path\Application.evtx"
$systemInfofile = "$AgentDiagnosticsPath\system.info"
$diagnosticFile = ".\AgentDiagnostics.zip"
#-------------------------------------------------------------------------------------

systeminfo | Out-File -FilePath $systemInfofile -NoClobber

Add-Content $systemInfofile "$OFS--------------HKLM:\SYSTEM\ControlSet001\Services\W3SVC:Environment----------"
$w3svc.Environment | Out-File -FilePath $systemInfofile -NoClobber -Append

Add-Content $systemInfofile "$OFS--------------HKLM:\SYSTEM\ControlSet001\Services\WAS:Environment----------"
$was.Environment | Out-File -FilePath $systemInfofile -NoClobber -Append


Add-Content $systemInfofile "$OFS--------------Global:Environment----------"
echo "CORECLR_ENABLE_PROFILING=$env:CORECLR_ENABLE_PROFILING" | Out-File -FilePath $systemInfofile -NoClobber -Append
echo "CORECLR_PROFILER=$env:CORECLR_PROFILER" | Out-File -FilePath $systemInfofile -NoClobber -Append
echo "CORECLR_PROFILER_PATH_64=$env:CORECLR_PROFILER_PATH_64" | Out-File -FilePath $systemInfofile -NoClobber -Append
echo "CORECLR_PROFILER_PATH_32=$env:CORECLR_PROFILER_PATH_32" | Out-File -FilePath $systemInfofile -NoClobber -Append
echo "CORECLR_SITE24X7_HOME=$env:CORECLR_SITE24X7_HOME" | Out-File -FilePath $systemInfofile -NoClobber -Append
echo "DOTNET_ADDITIONAL_DEPS=$env:DOTNET_ADDITIONAL_DEPS" | Out-File -FilePath $systemInfofile -NoClobber -Append
echo "DOTNET_SHARED_STORE=$env:DOTNET_SHARED_STORE" | Out-File -FilePath $systemInfofile -NoClobber -Append
echo "S247_LICENSE_KEY=$env:S247_LICENSE_KEY" | Out-File -FilePath $systemInfofile -NoClobber -Append
echo "COR_ENABLE_PROFILING=$env:COR_ENABLE_PROFILING" | Out-File -FilePath $systemInfofile -NoClobber -Append
echo "COR_PROFILER=$env:COR_PROFILER" | Out-File -FilePath $systemInfofile -NoClobber -Append

Add-Content $systemInfofile "$OFS--------------.NET Core info----------"
dotnet --info | Out-File -FilePath $systemInfofile -NoClobber -Append

#Reading .NET Core process with environment variables--------------------------
Add-Content $systemInfofile "$OFS***************************.NET Core processes***********************************"
$currentPath = (Get-Location).Path

try 
{
	$Assembly = [System.Reflection.Assembly]::LoadFrom("$currentPath\ProcessUtil.dll");

	$processes = get-process | where {$_.ProcessName -eq "w3wp"}

	foreach ($process in $processes)
	{ 
		try {
				Add-Content $systemInfofile "$OFS--------------Process Id : $($process.Id) -------------------"
				Get-Process -Id $process.Id | Out-File -FilePath $systemInfofile -NoClobber -Append -Width 100
				[ProcessUtil.Util.ProcessExtensions]::GetEnvironmentVariables($process.Id) | Out-File -FilePath $systemInfofile -NoClobber -Append
				Add-Content $systemInfofile "$OFS---------------------------------------------------"
			}
		catch {
				Add-Content $systemInfofile $_
		}
	}

	$processes = get-process | where {$_.ProcessName -eq "dotnet"}
	foreach ($process in $processes) 
	{  
		try {
				Add-Content $systemInfofile "$OFS--------------Process Id : $($process.Id) -------------------"
				Get-Process -Id $process.Id | Out-File -FilePath $systemInfofile -NoClobber -Append -Width 100
				[ProcessUtil.Util.ProcessExtensions]::GetEnvironmentVariables($process.Id) | Out-File -FilePath $systemInfofile -NoClobber -Append
				Add-Content $systemInfofile "$OFS---------------------------------------------------"
			}
		catch {
				Add-Content $systemInfofile $_
		}
	}
}
catch {
	Add-Content $systemInfofile $_
}
#-------------------------------------------------------------------------
Add-Content $systemInfofile "$OFS*********************************************************************************************"
#Exporting eventlog
$eventLog = (Get-WmiObject -Class Win32_NTEventlogFile | Where-Object LogfileName -EQ 'Application').BackupEventlog($applicationEventLog)

#Copying the agent log files
Copy-Item (Join-Path $parentPath "DotNetAgent") -destination $AgentDiagnosticsPath -recurse -for
Copy-Item $versionPath -destination $AgentDiagnosticsPath -recurse -for


$compress = @{
LiteralPath= $AgentDiagnosticsPath
CompressionLevel = "Fastest"
DestinationPath = $diagnosticFile
}
Compress-Archive @compress -Force

Remove-Item $AgentDiagnosticsPath -Recurse

Write-Host "Diagnostics zip file is generated." 
Write-Host "Send the file AgentDiagnostics.zip to support@site24x7.com for analysis." 
}
catch
{
    "An error occurred:"
    Write-Error $_
    Add-Content $systemInfofile "$OFS-------------Error in Agent Diagnostics script.---------------"
    Add-Content $systemInfofile $_
    Write-Host "If you find the AgentDiagnostics folder with the some log files, kindly zip the folder and send it to support@site24x7.com for analysis."
}


# SIG # Begin signature block
# MIIzfwYJKoZIhvcNAQcCoIIzcDCCM2wCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBRKvr82Rz51xHJ
# LU+vZYO+TKeLiY9/ULh759RFMgx5BaCCGAMwggROMIIDNqADAgECAg0B7l8Wnf+X
# NStkZdZqMA0GCSqGSIb3DQEBCwUAMFcxCzAJBgNVBAYTAkJFMRkwFwYDVQQKExBH
# bG9iYWxTaWduIG52LXNhMRAwDgYDVQQLEwdSb290IENBMRswGQYDVQQDExJHbG9i
# YWxTaWduIFJvb3QgQ0EwHhcNMTgwOTE5MDAwMDAwWhcNMjgwMTI4MTIwMDAwWjBM
# MSAwHgYDVQQLExdHbG9iYWxTaWduIFJvb3QgQ0EgLSBSMzETMBEGA1UEChMKR2xv
# YmFsU2lnbjETMBEGA1UEAxMKR2xvYmFsU2lnbjCCASIwDQYJKoZIhvcNAQEBBQAD
# ggEPADCCAQoCggEBAMwldpB5BngiFvXAg7aEyiie/QV2EcWtiHL8RgJDx7KKnQRf
# JMsuS+FggkbhUqsMgUdwbN1k0ev1LKMPgj0MK66X17YUhhB5uzsTgHeMCOFJ0mpi
# Lx9e+pZo34knlTifBtc+ycsmWQ1z3rDI6SYOgxXG71uL0gRgykmmKPZpO/bLyCiR
# 5Z2KYVc3rHQU3HTgOu5yLy6c+9C7v/U9AOEGM+iCK65TpjoWc4zdQQ4gOsC0p6Hp
# sk+QLjJg6VfLuQSSaGjlOCZgdbKfd/+RFO+uIEn8rUAVSNECMWEZXriX7613t2Sa
# er9fwRPvm2L7DWzgVGkWqQPabumDk3F2xmmFghcCAwEAAaOCASIwggEeMA4GA1Ud
# DwEB/wQEAwIBBjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBSP8Et/qC5FJK5N
# UPpjmove4t0bvDAfBgNVHSMEGDAWgBRge2YaRQ2XyolQL30EzTSo//z9SzA9Bggr
# BgEFBQcBAQQxMC8wLQYIKwYBBQUHMAGGIWh0dHA6Ly9vY3NwLmdsb2JhbHNpZ24u
# Y29tL3Jvb3RyMTAzBgNVHR8ELDAqMCigJqAkhiJodHRwOi8vY3JsLmdsb2JhbHNp
# Z24uY29tL3Jvb3QuY3JsMEcGA1UdIARAMD4wPAYEVR0gADA0MDIGCCsGAQUFBwIB
# FiZodHRwczovL3d3dy5nbG9iYWxzaWduLmNvbS9yZXBvc2l0b3J5LzANBgkqhkiG
# 9w0BAQsFAAOCAQEAI3Dpz+K+9VmulEJvxEMzqs0/OrlkF/JiBktI8UCIBheh/qvR
# XzzGM/Lzjt0fHT7MGmCZggusx/x+mocqpX0PplfurDtqhdbevUBj+K2myIiwEvz2
# Qd8PCZceOOpTn74F9D7q059QEna+CYvCC0h9Hi5R9o1T06sfQBuKju19+095VnBf
# DNOOG7OncA03K5eVq9rgEmscQM7Fx37twmJY7HftcyLCivWGQ4it6hNu/dj+Qi+5
# fV6tGO+UkMo9J6smlJl1x8vTe/fKTNOvUSGSW4R9K58VP3TLUeiegw4WbxvnRs4j
# vfnkoovSOWuqeRyRLOJhJC2OKkhwkMQexejgcDCCBaIwggSKoAMCAQICEHgDGEJF
# cIpBz28BuO60qVQwDQYJKoZIhvcNAQEMBQAwTDEgMB4GA1UECxMXR2xvYmFsU2ln
# biBSb290IENBIC0gUjMxEzARBgNVBAoTCkdsb2JhbFNpZ24xEzARBgNVBAMTCkds
# b2JhbFNpZ24wHhcNMjAwNzI4MDAwMDAwWhcNMjkwMzE4MDAwMDAwWjBTMQswCQYD
# VQQGEwJCRTEZMBcGA1UEChMQR2xvYmFsU2lnbiBudi1zYTEpMCcGA1UEAxMgR2xv
# YmFsU2lnbiBDb2RlIFNpZ25pbmcgUm9vdCBSNDUwggIiMA0GCSqGSIb3DQEBAQUA
# A4ICDwAwggIKAoICAQC2LcUw3Xroq5A9A3KwOkuZFmGy5f+lZx03HOV+7JODqoT1
# o0ObmEWKuGNXXZsAiAQl6fhokkuC2EvJSgPzqH9qj4phJ72hRND99T8iwqNPkY2z
# BbIogpFd+1mIBQuXBsKY+CynMyTuUDpBzPCgsHsdTdKoWDiW6d/5G5G7ixAs0sdD
# HaIJdKGAr3vmMwoMWWuOvPSrWpd7f65V+4TwgP6ETNfiur3EdaFvvWEQdESymAfi
# dKv/aNxsJj7pH+XgBIetMNMMjQN8VbgWcFwkeCAl62dniKu6TjSYa3AR3jjK1L6h
# wJzh3x4CAdg74WdDhLbP/HS3L4Sjv7oJNz1nbLFFXBlhq0GD9awd63cNRkdzzr+9
# lZXtnSuIEP76WOinV+Gzz6ha6QclmxLEnoByPZPcjJTfO0TmJoD80sMD8IwM0kXW
# LuePmJ7mBO5Cbmd+QhZxYucE+WDGZKG2nIEhTivGbWiUhsaZdHNnMXqR8tSMeW58
# prt+Rm9NxYUSK8+aIkQIqIU3zgdhVwYXEiTAxDFzoZg1V0d+EDpF2S2kUZCYqaAH
# N8RlGqocaxZ396eX7D8ZMJlvMfvqQLLn0sT6ydDwUHZ0WfqNbRcyvvjpfgP054d1
# mtRKkSyFAxMCK0KA8olqNs/ITKDOnvjLja0Wp9Pe1ZsYp8aSOvGCY/EuDiRk3wID
# AQABo4IBdzCCAXMwDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMD
# MA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFB8Av0aACvx4ObeltEPZVlC7zpY7
# MB8GA1UdIwQYMBaAFI/wS3+oLkUkrk1Q+mOai97i3Ru8MHoGCCsGAQUFBwEBBG4w
# bDAtBggrBgEFBQcwAYYhaHR0cDovL29jc3AuZ2xvYmFsc2lnbi5jb20vcm9vdHIz
# MDsGCCsGAQUFBzAChi9odHRwOi8vc2VjdXJlLmdsb2JhbHNpZ24uY29tL2NhY2Vy
# dC9yb290LXIzLmNydDA2BgNVHR8ELzAtMCugKaAnhiVodHRwOi8vY3JsLmdsb2Jh
# bHNpZ24uY29tL3Jvb3QtcjMuY3JsMEcGA1UdIARAMD4wPAYEVR0gADA0MDIGCCsG
# AQUFBwIBFiZodHRwczovL3d3dy5nbG9iYWxzaWduLmNvbS9yZXBvc2l0b3J5LzAN
# BgkqhkiG9w0BAQwFAAOCAQEArPfMFYsweagdCyiIGQnXHH/+hr17WjNuDWcOe2LZ
# 4RhcsL0TXR0jrjlQdjeqRP1fASNZhlZMzK28ZBMUMKQgqOA/6Jxy3H7z2Awjuqgt
# qjz27J+HMQdl9TmnUYJ14fIvl/bR4WWWg2T+oR1R+7Ukm/XSd2m8hSxc+lh30a6n
# sQvi1ne7qbQ0SqlvPfTzDZVd5vl6RbAlFzEu2/cPaOaDH6n35dSdmIzTYUsvwyh+
# et6TDrR9oAptksS0Zj99p1jurPfswwgBqzj8ChypxZeyiMgJAhn2XJoa8U1sMNSz
# BqsAYEgNeKvPF62Sk2Igd3VsvcgytNxN69nfwZCWKb3BfzCCBuYwggTOoAMCAQIC
# EHe9DgOhtwj4VKsGchDZBEcwDQYJKoZIhvcNAQELBQAwUzELMAkGA1UEBhMCQkUx
# GTAXBgNVBAoTEEdsb2JhbFNpZ24gbnYtc2ExKTAnBgNVBAMTIEdsb2JhbFNpZ24g
# Q29kZSBTaWduaW5nIFJvb3QgUjQ1MB4XDTIwMDcyODAwMDAwMFoXDTMwMDcyODAw
# MDAwMFowWTELMAkGA1UEBhMCQkUxGTAXBgNVBAoTEEdsb2JhbFNpZ24gbnYtc2Ex
# LzAtBgNVBAMTJkdsb2JhbFNpZ24gR0NDIFI0NSBDb2RlU2lnbmluZyBDQSAyMDIw
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA1kJN+eNPxiP0bB2BpjD3
# SD3P0OWN5SAilgdENV0Gzw8dcGDmJlT6UyNgAqhfAgL3jsluPal4Bb2O9U8ZJJl8
# zxEWmx97a9Kje2hld6vYsSw/03IGMlxbrFBnLCVNVgY2/MFiTH19hhaVml1UulDQ
# sH+iRBnp1m5sPhPCnxHUXzRbUWgxYwr4W9DeullfMa+JaDhAPgjoU2dOY7Yhju/d
# jYVBVZ4cvDfclaDEcacfG6VJbgogWX6Jo1gVlwAlad/ewmpQZU5T+2uhnxgeig5f
# VF694FvP8gwE0t4IoRAm97Lzei7CjpbBP86l2vRZKIw3ZaExlguOpHZ3FUmEZoIl
# 50MKd1KxmVFC/6Gy3ZzS3BjZwYapQB1Bl2KGvKj/osdjFwb9Zno2lAEgiXgfkPR7
# qVJOak9UBiqAr57HUEL6ZQrjAfSxbqwOqOOBGag4yJ4DKIakdKdHlX5yWip7FWoc
# xGnmsL5AGZnL0n1VTiKcEOChW8OzLnqLxN7xSx+MKHkwRX9sE7Y9LP8tSooq7CgP
# LcrUnJiKSm1aNiwv37rL4kFKCHcYiK01YZQS86Ry6+42nqdRJ5E896IazPyH5Zfh
# UYdp6SLMg8C3D0VsB+FDT9SMSs7PY7G1pBB6+Q0MKLBrNP4haCdv7Pj6JoRbdULN
# iSZ5WZ1rq2NxYpAlDQgg8f8CAwEAAaOCAa4wggGqMA4GA1UdDwEB/wQEAwIBhjAT
# BgNVHSUEDDAKBggrBgEFBQcDAzASBgNVHRMBAf8ECDAGAQH/AgEAMB0GA1UdDgQW
# BBTas43AJJCja3fTDKBZ3SFnZHYLeDAfBgNVHSMEGDAWgBQfAL9GgAr8eDm3pbRD
# 2VZQu86WOzCBkwYIKwYBBQUHAQEEgYYwgYMwOQYIKwYBBQUHMAGGLWh0dHA6Ly9v
# Y3NwLmdsb2JhbHNpZ24uY29tL2NvZGVzaWduaW5ncm9vdHI0NTBGBggrBgEFBQcw
# AoY6aHR0cDovL3NlY3VyZS5nbG9iYWxzaWduLmNvbS9jYWNlcnQvY29kZXNpZ25p
# bmdyb290cjQ1LmNydDBBBgNVHR8EOjA4MDagNKAyhjBodHRwOi8vY3JsLmdsb2Jh
# bHNpZ24uY29tL2NvZGVzaWduaW5ncm9vdHI0NS5jcmwwVgYDVR0gBE8wTTBBBgkr
# BgEEAaAyATIwNDAyBggrBgEFBQcCARYmaHR0cHM6Ly93d3cuZ2xvYmFsc2lnbi5j
# b20vcmVwb3NpdG9yeS8wCAYGZ4EMAQQBMA0GCSqGSIb3DQEBCwUAA4ICAQAIiHIm
# xq/6rF8GwKqMkNrQssCil/9uEzIWVP0+9DARn4+Y+ZtS3fKiFu7ZeJWmmnxhuAS1
# +OvL9GERM/ZlJbcRQovYaW7H/5W0gUOpfq6/gtZNzBGjg3FqEF4ZBafnbH9W9Khc
# w04JrVlruPl+pS64/N4OwqD7sATUExvHJ6m5qi0xO89GTJ3rTOy8Lpzxh6N/OGlf
# QUBn9lN96kHvjj37qdQROEbfPOv2zSK9E83w4eblM6C+POR41RvMIPIwc7AiHPaE
# 1ptcAALhKFJL/xJLQOrusBoGBp6E5ufw24RG+3PZK0K2yVc0xxbApushuaoO9/7b
# yuu8F8u4Z+vjPk/bqZSGZFXJCQrA2QRxShFLWmTDvHh4rUxHJmUHmdXNNmChM1Oz
# 9nsq1YlAPHGlq/iZWf3jm5JL3QW9Cwx4BivPU9i9EppbJ4aFP5G+4HiAc1Tfpx1n
# K2q2rk2JgCQIUnBQ8wH/RK4vmuDhSQjh4VvXONGeCoqdlCebyqO52+I2auNvuVhi
# 4DZ4NgH6waeJeiZTo1y70rLristjCC/+HvNWKeI1m9j/6aW9bUtZLIksL1K7tSmQ
# 2kNHvHLdvNm/gMHcsKu0Sx1YNjdk65vhhReaKaL95gjSkv+g+Hzh6afRMI5fJlAr
# x6Lil3eK79hNPibrmUBg8zxnDLYIcik1U4E03DCCBx0wggUFoAMCAQICDDJ6DtxO
# b0favXSfbjANBgkqhkiG9w0BAQsFADBZMQswCQYDVQQGEwJCRTEZMBcGA1UEChMQ
# R2xvYmFsU2lnbiBudi1zYTEvMC0GA1UEAxMmR2xvYmFsU2lnbiBHQ0MgUjQ1IENv
# ZGVTaWduaW5nIENBIDIwMjAwHhcNMjMxMDA5MDc0MDU4WhcNMjYxMDA5MDc0MDU4
# WjCBijELMAkGA1UEBhMCSU4xEzARBgNVBAgTClRhbWlsIE5hZHUxEDAOBgNVBAcT
# B0NoZW5uYWkxKTAnBgNVBAoTIFpPSE8gQ29ycG9yYXRpb24gUHJpdmF0ZSBMaW1p
# dGVkMSkwJwYDVQQDEyBaT0hPIENvcnBvcmF0aW9uIFByaXZhdGUgTGltaXRlZDCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBANmbLq0hdbEfruCttY2paHqA
# PsxfrfZJnXSxSwmlNT2MHHutqn/a/W3bdU+MxLThuEzO2IAi/xA4/xweBRHju9J1
# fFAZ8unJL5+Z779nsZsIMXDIqczDVFSh9uSpCailQ3kLPFt3OB9fYMtozA+W/vid
# PdYVhi82GA1s32ejrNdvc3q4Yjw6ba5o2NzkR+Wpj7qCFqiUIXPlvwk/Gaeam7pg
# FnkcSVbmfZqFHlZeEJSmG5S5j74ywAaLXWPLSaYhPvU59t/6iHzbPNLYi+M2H414
# 5SejGCOlgmeFE6wRxazJbuf0WDSLo6ZIlTzCoFu2ubsrIrJTTLPq/iNtDmykSS0Y
# MqDOXXnB0vhCp2KQ7AQAPMqQH+iIey/yIlc8qR8jGPxWPkfymxacoJLFfH4SBnIr
# JSJLwLKqhM5+vCBTlAT7MQauF8835yv+7qvuB0Epz17fcU1OrYkrpTOiMaulqo36
# YH5v5M/m4jUhU3EwhehCIVBKkB5F6aG0HTA4pp9bO3UGwUTk88tSDHUr58TSjGNv
# E/6EpPkCTBSXbmWUd6uuB/XbQ+2zAdzbxfv8+XxrJjjn+dmhDi2sS7xkav53pCDQ
# +HrSqJSl3z3ar7I8eVQp+lIdswoCEg2aatpE5i+eJ/8gc6AY04nUL4kfRpiMJF8h
# ju+ovHFEFox2xHYheffPAgMBAAGjggGxMIIBrTAOBgNVHQ8BAf8EBAMCB4AwgZsG
# CCsGAQUFBwEBBIGOMIGLMEoGCCsGAQUFBzAChj5odHRwOi8vc2VjdXJlLmdsb2Jh
# bHNpZ24uY29tL2NhY2VydC9nc2djY3I0NWNvZGVzaWduY2EyMDIwLmNydDA9Bggr
# BgEFBQcwAYYxaHR0cDovL29jc3AuZ2xvYmFsc2lnbi5jb20vZ3NnY2NyNDVjb2Rl
# c2lnbmNhMjAyMDBWBgNVHSAETzBNMEEGCSsGAQQBoDIBMjA0MDIGCCsGAQUFBwIB
# FiZodHRwczovL3d3dy5nbG9iYWxzaWduLmNvbS9yZXBvc2l0b3J5LzAIBgZngQwB
# BAEwCQYDVR0TBAIwADBFBgNVHR8EPjA8MDqgOKA2hjRodHRwOi8vY3JsLmdsb2Jh
# bHNpZ24uY29tL2dzZ2NjcjQ1Y29kZXNpZ25jYTIwMjAuY3JsMBMGA1UdJQQMMAoG
# CCsGAQUFBwMDMB8GA1UdIwQYMBaAFNqzjcAkkKNrd9MMoFndIWdkdgt4MB0GA1Ud
# DgQWBBQYDsugu1WdQ3vwoxbLpvdOAKvlGjANBgkqhkiG9w0BAQsFAAOCAgEAyI45
# wqzAU6DKgsG01TXFep4IfjBSl9SlZMmAiZm09hhgOFiBXTni4MQfc4ujNfk0mAgU
# tRoqUkkRCPONTrfjzEKW3WjGqpCGzsrqVHy5CeC6gUB+bLccuoKBEZuBIh/eW2dP
# esNm9kaxIpqJMpN772PdjTt4900lGI6uUMIWPGyHOnRUaAJdrK9kVz+3BkdMBsLC
# ONbBhgfn6dTAV8XuX6f8XXJtGmC9flB0EiKzaEb/NTkov0mt6lnN3wGh5/qzRCXe
# +dCCwO2wrm+JdPkXZu2+zWY8nVcTy3m6vuMHbHsVT7Yd7IYPEz1/pgEvw7Kwya/C
# GsMkzX0v7vz3VGoXqXgLZaqMq2YGznVXhdu3eRUR/EaD2g6zgu/Uoo2t/5tFwKZJ
# bPId2KTlLe4/ZZTpFCl8MKMfzYOev2TcwblIcyx06nwcBlwrvcGSth4ej21OTMiM
# tTRRlNySRRmaG9jDl7C4HcK9PI3ZiBsz7DHF2xh4D+UNEa0fAjo8GoOH7Gjt7OAi
# e7W7+XsBm3+znkHLiKeQHa8pRONI36VoHEhlICt3Qw+rSrQOeVoFo6kmjal7wt4g
# YpsklHaDVCpyk209GxOw/ENr0NeBSnUWPpuR2h1PxrGIziAaAGUHIb0cqphjjRb9
# 1Ox3RYZL8WOE56MRxC2U7/t2CHmnGm061Iws9T4xghrSMIIazgIBATBpMFkxCzAJ
# BgNVBAYTAkJFMRkwFwYDVQQKExBHbG9iYWxTaWduIG52LXNhMS8wLQYDVQQDEyZH
# bG9iYWxTaWduIEdDQyBSNDUgQ29kZVNpZ25pbmcgQ0EgMjAyMAIMMnoO3E5vR9q9
# dJ9uMA0GCWCGSAFlAwQCAQUAoIHAMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqGSIb3DQEJBDEiBCCm
# GDxsyD/SZ3eohuFY/b39aNFUlJiw8zXujBlq4uEiUjBUBgorBgEEAYI3AgEMMUYw
# RKBCgEAAWgBPAEgATwAgAEMAbwByAHAAbwByAGEAdABpAG8AbgAgAFAAcgBpAHYA
# YQB0AGUAIABMAGkAbQBpAHQAZQBkMA0GCSqGSIb3DQEBAQUABIICAHrU+Mtvfr9c
# 940nAy7pSlMVJ2KbRcK9ExrexT8IqGs/QFIbbD5kEb2KxMwAjq06uLG0ZBNvfJGO
# N9KL6wkDBcc3BW3l6L7NFlvK49fwI5k84BsXy/s0EEsBuVJ0HzcQ1fjhXejikady
# X5ITXD4WWKUrzAWHNdkYAMD9V9ZZ/y+E9gx6rvtL8ZKS9opsfrbtlDCel46Qano/
# SW28LIMw+MO2GVxtrbsBdRbbuP4Pry1a69KV+tlu/eu/TNwUogOpGvr6M+9GVVUs
# ZYhMoKxw3OYCfDU3jqEI0h9K2hxoCW3lLJQ0HPhkOW5b2AQMS+hy8CZmMW/7Kzd0
# 4qDibs/fpHU/Bk8c/gsf6D7Rypx8HtHLZavdx1QBDAJUPRZM6IYJQeka6vhGrVrn
# tW35meWnNh348F4IhyvehLtZGorG5PIq31FcBsgIaaicZXWaEtchbW6J7LlpzlRX
# C5GK/AFyhmOH6gb0n+/eh4sSES9OD093GrZm5jAX0w4yyYKZhiujT1bKcSuoq2jz
# S8XXFnEhXengr0HpCMYtmK29RyAB/pwVz6hKAEzcdGeMN1kf1+W3CFro4GNHi4VV
# hpNjvpoKsHNoxtIEaXGpuRTM56upTyyIwTrftr5QTGWrnO6kHGTay+knbyjTMiOP
# P76/GBKM+40oR6mMNZbBsr8EHYem3IejoYIXdzCCF3MGCisGAQQBgjcDAwExghdj
# MIIXXwYJKoZIhvcNAQcCoIIXUDCCF0wCAQMxDzANBglghkgBZQMEAgEFADB4Bgsq
# hkiG9w0BCRABBKBpBGcwZQIBAQYJYIZIAYb9bAcBMDEwDQYJYIZIAWUDBAIBBQAE
# IKeKfhkptU/OWQiXdZKApd5qV/mDSuSURzUO1Opx8vDeAhEAsvGdvXnKFBhzEJsz
# MJ08OxgPMjAyNTA2MTkxMDU5NDFaoIITOjCCBu0wggTVoAMCAQICEAqA7xhLjfEF
# gtHEdqeVdGgwDQYJKoZIhvcNAQELBQAwaTELMAkGA1UEBhMCVVMxFzAVBgNVBAoT
# DkRpZ2lDZXJ0LCBJbmMuMUEwPwYDVQQDEzhEaWdpQ2VydCBUcnVzdGVkIEc0IFRp
# bWVTdGFtcGluZyBSU0E0MDk2IFNIQTI1NiAyMDI1IENBMTAeFw0yNTA2MDQwMDAw
# MDBaFw0zNjA5MDMyMzU5NTlaMGMxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdp
# Q2VydCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNlcnQgU0hBMjU2IFJTQTQwOTYgVGlt
# ZXN0YW1wIFJlc3BvbmRlciAyMDI1IDEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDQRqwtEsae0OquYFazK1e6b1H/hnAKAd/KN8wZQjBjMqiZ3xTWcfsL
# wOvRxUwXcGx8AUjni6bz52fGTfr6PHRNv6T7zsf1Y/E3IU8kgNkeECqVQ+3bzWYe
# sFtkepErvUSbf+EIYLkrLKd6qJnuzK8Vcn0DvbDMemQFoxQ2Dsw4vEjoT1FpS54d
# NApZfKY61HAldytxNM89PZXUP/5wWWURK+IfxiOg8W9lKMqzdIo7VA1R0V3Zp3Dj
# jANwqAf4lEkTlCDQ0/fKJLKLkzGBTpx6EYevvOi7XOc4zyh1uSqgr6UnbksIcFJq
# LbkIXIPbcNmA98Oskkkrvt6lPAw/p4oDSRZreiwB7x9ykrjS6GS3NR39iTTFS+EN
# TqW8m6THuOmHHjQNC3zbJ6nJ6SXiLSvw4Smz8U07hqF+8CTXaETkVWz0dVVZw7kn
# h1WZXOLHgDvundrAtuvz0D3T+dYaNcwafsVCGZKUhQPL1naFKBy1p6llN3QgshRt
# a6Eq4B40h5avMcpi54wm0i2ePZD5pPIssoszQyF4//3DoK2O65Uck5Wggn8O2klE
# TsJ7u8xEehGifgJYi+6I03UuT1j7FnrqVrOzaQoVJOeeStPeldYRNMmSF3voIgMF
# tNGh86w3ISHNm0IaadCKCkUe2LnwJKa8TIlwCUNVwppwn4D3/Pt5pwIDAQABo4IB
# lTCCAZEwDAYDVR0TAQH/BAIwADAdBgNVHQ4EFgQU5Dv88jHt/f3X85FxYxlQQ89h
# jOgwHwYDVR0jBBgwFoAU729TSunkBnx6yuKQVvYv1Ensy04wDgYDVR0PAQH/BAQD
# AgeAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMIGVBggrBgEFBQcBAQSBiDCBhTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMF0GCCsGAQUFBzAC
# hlFodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRU
# aW1lU3RhbXBpbmdSU0E0MDk2U0hBMjU2MjAyNUNBMS5jcnQwXwYDVR0fBFgwVjBU
# oFKgUIZOaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0
# VGltZVN0YW1waW5nUlNBNDA5NlNIQTI1NjIwMjVDQTEuY3JsMCAGA1UdIAQZMBcw
# CAYGZ4EMAQQCMAsGCWCGSAGG/WwHATANBgkqhkiG9w0BAQsFAAOCAgEAZSqt8Rwn
# BLmuYEHs0QhEnmNAciH45PYiT9s1i6UKtW+FERp8FgXRGQ/YAavXzWjZhY+hIfP2
# JkQ38U+wtJPBVBajYfrbIYG+Dui4I4PCvHpQuPqFgqp1PzC/ZRX4pvP/ciZmUnth
# fAEP1HShTrY+2DE5qjzvZs7JIIgt0GCFD9ktx0LxxtRQ7vllKluHWiKk6FxRPyUP
# xAAYH2Vy1lNM4kzekd8oEARzFAWgeW3az2xejEWLNN4eKGxDJ8WDl/FQUSntbjZ8
# 0FU3i54tpx5F/0Kr15zW/mJAxZMVBrTE2oi0fcI8VMbtoRAmaaslNXdCG1+lqvP4
# FbrQ6IwSBXkZagHLhFU9HCrG/syTRLLhAezu/3Lr00GrJzPQFnCEH1Y58678Igmf
# ORBPC1JKkYaEt2OdDh4GmO0/5cHelAK2/gTlQJINqDr6JfwyYHXSd+V08X1JUPvB
# 4ILfJdmL+66Gp3CSBXG6IwXMZUXBhtCyIaehr0XkBoDIGMUG1dUtwq1qmcwbdUfc
# SYCn+OwncVUXf53VJUNOaMWMts0VlRYxe5nK+At+DI96HAlXHAL5SlfYxJ7La54i
# 71McVWRP66bW+yERNpbJCjyCYG2j+bdpxo/1Cy4uPcU3AWVPGrbn5PhDBf3Frogu
# zzhk++ami+r3Qrx5bIbY3TVzgiFI7Gq3zWcwgga0MIIEnKADAgECAhANx6xXBf8h
# mS5AQyIMOkmGMA0GCSqGSIb3DQEBCwUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yNTA1MDcwMDAwMDBaFw0z
# ODAxMTQyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3RhbXBpbmcg
# UlNBNDA5NiBTSEEyNTYgMjAyNSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQC0eDHTCphBcr48RsAcrHXbo0ZodLRRF51NrY0NlLWZloMsVO1DahGP
# NRcybEKq+RuwOnPhof6pvF4uGjwjqNjfEvUi6wuim5bap+0lgloM2zX4kftn5B1I
# pYzTqpyFQ/4Bt0mAxAHeHYNnQxqXmRinvuNgxVBdJkf77S2uPoCj7GH8BLuxBG5A
# vftBdsOECS1UkxBvMgEdgkFiDNYiOTx4OtiFcMSkqTtF2hfQz3zQSku2Ws3IfDRe
# b6e3mmdglTcaarps0wjUjsZvkgFkriK9tUKJm/s80FiocSk1VYLZlDwFt+cVFBUR
# Jg6zMUjZa/zbCclF83bRVFLeGkuAhHiGPMvSGmhgaTzVyhYn4p0+8y9oHRaQT/ao
# fEnS5xLrfxnGpTXiUOeSLsJygoLPp66bkDX1ZlAeSpQl92QOMeRxykvq6gbylsXQ
# skBBBnGy3tW/AMOMCZIVNSaz7BX8VtYGqLt9MmeOreGPRdtBx3yGOP+rx3rKWDEJ
# lIqLXvJWnY0v5ydPpOjL6s36czwzsucuoKs7Yk/ehb//Wx+5kMqIMRvUBDx6z1ev
# +7psNOdgJMoiwOrUG2ZdSoQbU2rMkpLiQ6bGRinZbI4OLu9BMIFm1UUl9VnePs6B
# aaeEWvjJSjNm2qA+sdFUeEY0qVjPKOWug/G6X5uAiynM7Bu2ayBjUwIDAQABo4IB
# XTCCAVkwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQU729TSunkBnx6yuKQ
# VvYv1Ensy04wHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMIMHcGCCsGAQUFBwEBBGswaTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAC
# hjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAgBgNVHSAEGTAXMAgGBmeBDAEE
# AjALBglghkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggIBABfO+xaAHP4HPRF2cTC9
# vgvItTSmf83Qh8WIGjB/T8ObXAZz8OjuhUxjaaFdleMM0lBryPTQM2qEJPe36zwb
# SI/mS83afsl3YTj+IQhQE7jU/kXjjytJgnn0hvrV6hqWGd3rLAUt6vJy9lMDPjTL
# xLgXf9r5nWMQwr8Myb9rEVKChHyfpzee5kH0F8HABBgr0UdqirZ7bowe9Vj2AIMD
# 8liyrukZ2iA/wdG2th9y1IsA0QF8dTXqvcnTmpfeQh35k5zOCPmSNq1UH410ANVk
# o43+Cdmu4y81hjajV/gxdEkMx1NKU4uHQcKfZxAvBAKqMVuqte69M9J6A47OvgRa
# Ps+2ykgcGV00TYr2Lr3ty9qIijanrUR3anzEwlvzZiiyfTPjLbnFRsjsYg39OlV8
# cipDoq7+qNNjqFzeGxcytL5TTLL4ZaoBdqbhOhZ3ZRDUphPvSRmMThi0vw9vODRz
# W6AxnJll38F0cuJG7uEBYTptMSbhdhGQDpOXgpIUsWTjd6xpR6oaQf/DJbg3s6KC
# LPAlZ66RzIg9sC+NJpud/v4+7RWsWCiKi9EOLLHfMR2ZyJ/+xhCx9yHbxtl5TPau
# 1j/1MIDpMPx0LckTetiSuEtQvLsNz3Qbp7wGWqbIiOWCnb5WqxL3/BAPvIXKUjPS
# xyZsq8WhbaM2tszWkPZPubdcMIIFjTCCBHWgAwIBAgIQDpsYjvnQLefv21DiCEAY
# WjANBgkqhkiG9w0BAQwFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNl
# cnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdp
# Q2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMjIwODAxMDAwMDAwWhcNMzExMTA5
# MjM1OTU5WjBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkw
# FwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhEaWdpQ2VydCBUcnVz
# dGVkIFJvb3QgRzQwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC/5pBz
# aN675F1KPDAiMGkz7MKnJS7JIT3yithZwuEppz1Yq3aaza57G4QNxDAf8xukOBbr
# VsaXbR2rsnnyyhHS5F/WBTxSD1Ifxp4VpX6+n6lXFllVcq9ok3DCsrp1mWpzMpTR
# EEQQLt+C8weE5nQ7bXHiLQwb7iDVySAdYyktzuxeTsiT+CFhmzTrBcZe7FsavOvJ
# z82sNEBfsXpm7nfISKhmV1efVFiODCu3T6cw2Vbuyntd463JT17lNecxy9qTXtyO
# j4DatpGYQJB5w3jHtrHEtWoYOAMQjdjUN6QuBX2I9YI+EJFwq1WCQTLX2wRzKm6R
# AXwhTNS8rhsDdV14Ztk6MUSaM0C/CNdaSaTC5qmgZ92kJ7yhTzm1EVgX9yRcRo9k
# 98FpiHaYdj1ZXUJ2h4mXaXpI8OCiEhtmmnTK3kse5w5jrubU75KSOp493ADkRSWJ
# tppEGSt+wJS00mFt6zPZxd9LBADMfRyVw4/3IbKyEbe7f/LVjHAsQWCqsWMYRJUa
# dmJ+9oCw++hkpjPRiQfhvbfmQ6QYuKZ3AeEPlAwhHbJUKSWJbOUOUlFHdL4mrLZB
# dd56rF+NP8m800ERElvlEFDrMcXKchYiCd98THU/Y+whX8QgUWtvsauGi0/C1kVf
# nSD8oR7FwI+isX4KJpn15GkvmB0t9dmpsh3lGwIDAQABo4IBOjCCATYwDwYDVR0T
# AQH/BAUwAwEB/zAdBgNVHQ4EFgQU7NfjgtJxXWRM3y5nP+e6mK4cD08wHwYDVR0j
# BBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wDgYDVR0PAQH/BAQDAgGGMHkGCCsG
# AQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29t
# MEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNl
# cnRBc3N1cmVkSURSb290Q0EuY3J0MEUGA1UdHwQ+MDwwOqA4oDaGNGh0dHA6Ly9j
# cmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwEQYD
# VR0gBAowCDAGBgRVHSAAMA0GCSqGSIb3DQEBDAUAA4IBAQBwoL9DXFXnOF+go3Qb
# PbYW1/e/Vwe9mqyhhyzshV6pGrsi+IcaaVQi7aSId229GhT0E0p6Ly23OO/0/4C5
# +KH38nLeJLxSA8hO0Cre+i1Wz/n096wwepqLsl7Uz9FDRJtDIeuWcqFItJnLnU+n
# BgMTdydE1Od/6Fmo8L8vC6bp8jQ87PcDx4eo0kxAGTVGamlUsLihVo7spNU96LHc
# /RzY9HdaXFSMb++hUD38dglohJ9vytsgjTVgHAIDyyCwrFigDkBjxZgiwbJZ9VVr
# zyerbHbObyMt9H5xaiNrIv8SuFQtJ37YOtnwtoeW/VvRXKwYw02fc7cBqZ9Xql4o
# 4rmUMYIDfDCCA3gCAQEwfTBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNl
# cnQsIEluYy4xQTA/BgNVBAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgVGltZVN0YW1w
# aW5nIFJTQTQwOTYgU0hBMjU2IDIwMjUgQ0ExAhAKgO8YS43xBYLRxHanlXRoMA0G
# CWCGSAFlAwQCAQUAoIHRMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAcBgkq
# hkiG9w0BCQUxDxcNMjUwNjE5MTA1OTQxWjArBgsqhkiG9w0BCRACDDEcMBowGDAW
# BBTdYjCshgotMGvaOLFoeVIwB/tBfjAvBgkqhkiG9w0BCQQxIgQgV8+RBIEUD2uN
# qosrSBzTJFqJpa1bz3iJ0P0PJf2/By0wNwYLKoZIhvcNAQkQAi8xKDAmMCQwIgQg
# SqA/oizXXITFXJOPgo5na5yuyrM/420mmqM08UYRCjMwDQYJKoZIhvcNAQEBBQAE
# ggIAlfkBhxF9ECfXy7Z8H9g1LdNCoZ/iZKVO5Ku73Ua8ZeTwPFmZ27CIvB+RQ0nH
# lzAitywWqBTOylgepgy+fKqymbV6CT6uc1WdlHL5U2ujJjxiLcHgShjgkMFXUDfX
# hZxF+ZXdC7xP4uYHDqWrUYXw/OCxiAhXrlAXPH89nYedMBHRCC05UQEbB+GapF2+
# sD1R0OfRc1k+VmKBZnzcity3Shgv9X0QOeFhsumCGukq21O3BxxSzzNqODI3A0yL
# KtKGkoTVnALHgW1PcqqB7T/B32Kbaif5ulgUPVX98fLoWxTY9A9BrMfphlB35eIr
# 7X8ol/QSHLsz/Dw9F75qixmOKC5crkL/fe1DeFEktFaSw5RaSLxS/keq+OzoClS4
# PpKtj32fClfopUWFwXHzta0shMPlGY3Cp5ZyccJAh2Dd8+LJIbAr+RToQeBXxYfY
# zRKGiL9t38wLgdCw9v6rG5bFjiwssanzpwWWGOnKpy6VNqr5oNsJ22BvnmaTZp4F
# wxVy8c73gey1gajimJlFpHMyeiF0GanSS9Uqg2HhwNQPJslum+97vhshDFIEoayI
# /8cF8pVyQTkTqhF5qB32z6rTvPD3ZgbVoee20kuANHg1AkTJaVFYf3jt77NLh1F1
# hV1P8XvIIRg42rRIoiepjo6K6wTY44merkySl/ChDLLMmvo=
# SIG # End signature block
