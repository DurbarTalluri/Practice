#!/bin/sh
gcc -c -fPIC slog.c -o slog.o
gcc -c -fPIC ini.c -o ini.o
gcc -c -fPIC cJSON.c -o cJSON.o
gcc -c -fPIC -Dsite24x7 autoprofilerloader.c -o autoprofilerloader.o
gcc -shared -Wl,-soname,autoprofilerloader.so -o autoprofilerloader.so autoprofilerloader.o ini.o slog.o cJSON.o
# sudo rm /lib/libsite24x7apmautoprofilerloader.so
# sudo cp autoprofilerloader.so /lib/libsite24x7apmautoprofilerloader.so
# sudo ldconfig