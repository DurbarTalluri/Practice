#!/bin/sh
UNINSTALL_SCRIPT_DIRECTORY_PATH="$(dirname "$(readlink -f "$0")")"
INSTALL_LOG_FILE_PATH="$(echo "$UNINSTALL_SCRIPT_DIRECTORY_PATH" | sed 's/\/bin//')/logs/apm-one-agent-installation.log"

if [ -f "$INSTALL_LOG_FILE_PATH" ]; then
    exec >>"$INSTALL_LOG_FILE_PATH" 2>&1
fi
Log() {
    if [ -n "$1" ]; then
        echo $(date +"%F %T.%N") " $1\n"
    fi
}

Log "UNINSTALLING ApminsightOneAgentLinux"
Log "$(sed -i '/libsite24x7apmoneagentloader.so$/d' /etc/ld.so.preload 2>&1)"
Log "$(sed -i '/^SITE24X7_APMINSIGHT_ONEAGENT_VERSION/d' /etc/environment 2>&1)"
cd "$UNINSTALL_SCRIPT_DIRECTORY_PATH"
cd ../../../
Log "$(sh /opt/S247DataExporter/bin/service.sh uninstall 2>&1)"
Log "$(rm -r /opt/S247DataExporter 2>&1)"
Log "$(rm /lib/libsite24x7apmoneagentloader.so 2>&1)"
Log "$(pip uninstall --yes apminsight 2>&1)"
Log "$(systemctl stop site24x7apmoneagent.service 2>&1)"
Log "$(systemctl disable site24x7apmoneagent.service 2>&1)"
Log "$(rm /etc/systemd/system/site24x7apmoneagent.service 2>&1)"
Log "$(systemctl daemon-reload 2>&1)"
Log "$(mv $INSTALL_LOG_FILE_PATH "$(echo "$UNINSTALL_SCRIPT_DIRECTORY_PATH" | sed 's/\/apmoneagent\/bin//')/" 2>&1)"
Log "$(rm -r site24x7/apmoneagent 2>&1)"
