#!/bin/sh
echo "UNINSTALLING ApminsightOneAgentLinux"
UNINSTALL_SCRIPT_DIRECTORY_PATH="$(dirname "$(readlink -f "$0")")"
INSTALL_LOG_FILE_PATH="$(echo "$UNINSTALL_SCRIPT_DIRECTORY_PATH" | sed 's/\/bin//')/logs/apm-one-agent-installation.log"
exec >>"$INSTALL_LOG_FILE_PATH" 2>&1
sed -i '/libapminsightoneagentloader.so$/d' /etc/ld.so.preload
sed -i '/^ONEAGENT/d' /etc/environment
cd "$UNINSTALL_SCRIPT_DIRECTORY_PATH"
cd ../../../
sh /opt/S247DataExporter/bin/service.sh uninstall
rm -r /opt/S247DataExporter
rm /lib/libapminsightoneagentloader.so
pip uninstall --yes apminsight
systemctl stop apminsight-oneagent-linux.service
systemctl disable apminsight-oneagent-linux.service
rm /etc/systemd/system/apminsight-oneagent-linux.service
systemctl daemon-reload
mv $INSTALL_LOG_FILE_PATH "$(echo "$UNINSTALL_SCRIPT_DIRECTORY_PATH" | sed 's/\/site24x7\/bin//')/"
rm -r site24x7/apmoneagent