# apm-insight-one-agent-linux

Apminsight One agent is a one-stop solution for monitoring your applications. Apminsight OneAgent once installed in your machine will monitor all potential applications avoiding manual installation of agents for each application irrespective of application language

## Install Apminsight One-Agent-Linux

    wget https://staticdownloads.site24x7.com/apminsight/agents/apm-one-agent-linux.sh

    sudo sh apm-one-agent-linux.sh --APMINSIGHT_LICENSE_KEY=<Your Device key>

## Configure Apminsight One-Agent-Linux

In order to configure Oneagent during installation via commandline arguments, add respective CL arguments mentioned below to the installation command

| Option | Description  |
| ------ | ------ |
| --APMINSIGHT_ONEAGENT_PATH=<One Agent installation path> | To configure a Custom path to install OneAgentLinux |
| --APMINSIGHT_PROXY_URL=<Complete Proxy Url> | To configure Proxy Url if using, Format: protocol://user:password@host:port or protocol://user@host:port or protocol://host:port" |
| --APMINSIGHT_MONITOR_GROUP=<Agent Monitor Group> | To configure Agent monitor group |

In order to configure Oneagent during installation via configuration file, create a config file with name **oneagentconf.ini** in the directory from which apm-one-agent-linux.sh is run and add respective Key Value pairs in the format mentioned below to the file

| KEY VALUE PAIR | DESCRIPTION |
| ------ | ------ |
| APMINSIGHT_PROXY_URL=<Complete Proxy Url> | To configure Proxy Url if using, Format: protocol://user:password@host:port or protocol://user@host:port or protocol://host:port" |
| APMINSIGHT_ONEAGENT_PATH=<One Agent installation path> | To configure a Custom path to install OneAgentLinux |
| APMINSIGHT_MONITOR_GROUP=<Agent Monitor Group> | To configure Agent monitor group |

OneAgentLinux configurations can be changed/added even after installation by modifying the file **oneagentconf.ini** placed at <OneagentInstallationPath>/conf

> Note: Default OneagentInstallationPath location is at /opt/site24x7/apmoneagent

To change an existing configuration, replace the existing value of a particular key with the new value

To add a configuration, please append the existing file with config info in the format `NEW_CONFIGURATION=<value>`

> Note: Modified configurations will come into affect for the processes that start after the file modification. Inorder for changes to be reflected in the existing processes, respective process need to be restarted

## Uninstall Apminsight One-Agent-Linux

Uninstall Apminsight OneAgent using the command `sudo sh <OneagentInstallationPath>/bin/uninstall.sh`

Upgrade Apminsight OneAgent using the command `sudo sh <OneagentInstallationPath>/bin/apm-one-agent-linux.sh --upgrade`
