#!/bin/bash

cd "$(dirname "$(realpath "$0")")" || {
    echo "Failed to switch to script directory"
    exit 1
}

# Define variables
Destination="/opt/manageengine"
LicenseKey=""
AppName=""
ForceUpdate=false
Help=false
IsBehindProxy=false
ProxyHost=""
ProxyPort=0
ProxyUser=""
ProxyPassword=""
DisableAppFilter=false
OfflineInstall=false
EncryptedString=""
InitVector=""
DOWNLOAD_DOMAIN="https://www.manageengine.com/products/applications_manager/54974026"
SaltKey=""
ApmHost=""
ApmPort=9090
ApmProtocolHttps=true
ExporterHost=""
ExporterStatusPort=""
ExporterDataPort=""
AutoProfilerInstall=false
AutoProfilerHomePath=""
SupportDeprecatedVersions=false

AgentVersion="7.3.0"

agentZipGLibcUrl="apminsight-dotnetcoreagent-linux.zip"
checksumGLibcUrl="apminsight-dotnetcoreagent-linux.zip.sha256"
agentZipName="apminsight-dotnetcoreagent-linux.zip"

IsUpdateFound=false

function InstallAgent() {
    if [ "$AutoProfilerInstall" = true ]; then
        InstallAgentForAutoProfiler
    else
        InstallAgentStandard
    fi
}

function InstallAgentStandard() {
    agentPath="$Destination/ManageEngineDotNetCoreAgent"
    PSScriptRoot=$(dirname "$(realpath "$0")")

    if [ "$OfflineInstall" = true ]; then
        if [ ! -d "$PSScriptRoot/Agent" ]; then
            Print "The Script is an Online Installer; remove the '-OfflineInstall' flag and try again."
            exit 1
        fi
    else
        DownloadAndExtractAgent
    fi

    if [ -f "$agentPath/version.info" ]; then
        installedAgentVersionString=$(cat "$agentPath/version.info")
        currentVersionNumber=${installedAgentVersionString//./}
        newVersionNumber=${AgentVersion//./}
        
        if [ "$currentVersionNumber" -lt "$newVersionNumber" ]; then
            IsUpdateFound=true
            userInput="Y"
            if [ "$ForceUpdate" = false ]; then
                read -p "APM Insight .NET core agent is already installed. Current version: $installedAgentVersionString. Upgrade to $AgentVersion? [Y/N] " userInput
            fi
            
            if [[ "$userInput" =~ ^[Nn]$ ]]; then
                Print "Keeping existing version $installedAgentVersionString."
                SetGlobalEnvironment "$agentPath"
            elif [[ "$userInput" =~ ^[Yy]$ ]]; then
                Print "Upgrading agent to version $AgentVersion..."
                CopyFiles "$agentPath"
                rm -rf dotnet_core_linux
            else
                Print "Invalid input. Exiting."
                exit 1
            fi
            Print "Setup complete for APM Insight .NET Core agent version $AgentVersion."
        elif [ "$currentVersionNumber" -eq "$newVersionNumber" ]; then
            Print "Agent version $installedAgentVersionString is already installed."
            SetGlobalEnvironment "$agentPath"
            Print "Setup verified for APM Insight .NET Core agent version $AgentVersion."
        else
            Print "Higher version detected. Upgrade will not proceed."
            exit 0
        fi
    else
        Print "Installing APM Insight .NET Core agent version $AgentVersion..."
        CopyFiles "$agentPath"
        if [ "$OfflineInstall" = false ]; then
            rm -rf dotnet_core_linux
        fi
        Print "Installation complete!"
        PrintUsageInstructions "$agentPath"
    fi
}

function InstallAgentForAutoProfiler() {
    Print "Installing APM Insight .NET Core agent in AutoProfiler mode..."
    Print "Library Path: $Destination"
    Print "Home Path: $AutoProfilerHomePath"
    
    PSScriptRoot=$(dirname "$(realpath "$0")")

    if [ "$OfflineInstall" = true ]; then
        if [ ! -d "$PSScriptRoot/Agent" ]; then
            Print "The Script is an Online Installer; remove the '-OfflineInstall' flag and try again."
            exit 1
        fi
    else
        DownloadAndExtractAgent
    fi
    
    CopyFilesForAutoProfiler
    
    if [ "$OfflineInstall" = false ]; then
        rm -rf dotnet_core_linux
    fi
    
    Print "AutoProfiler installation complete!"
    Print ""
    Print "Library files installed to: $Destination/ManageEngineDotNetCoreAgent"
    Print "Configuration files installed to: $AutoProfilerHomePath/ManageEngineDotNetCoreAgent"
    Print ""
}

function PrintUsageInstructions() {
    agentPath=$1
    scriptsPath="$agentPath/scripts"
    Print ""
    Print "╔════════════════════════════════════════════════════════════════════════╗"
    Print "║               ManageEngine APM Agent Successfully Installed!           ║"
    Print "╚════════════════════════════════════════════════════════════════════════╝"
    Print ""
	
	if [ "$SupportDeprecatedVersions" = true ]; then
        Print "Deprecated Versions Support (.NET Core 2.0 - 3.1) Enabled"
        Print ""
        Print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        Print "  IMPORTANT: Environment Variables Required"
        Print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        Print "  The store and additionalDeps directories have been created."
        Print "  You MUST set these environment variables before running your app:"
        Print ""
        Print "    export DOTNET_ADDITIONAL_DEPS=$agentPath/additionalDeps"
        Print "    export DOTNET_SHARED_STORE=$agentPath/store"
        Print "    dotnet run"
        Print ""
        Print "  Or add to your shell config for persistence:"
        Print ""
        Print "    echo 'export DOTNET_ADDITIONAL_DEPS=$agentPath/additionalDeps' >> ~/.bashrc"
        Print "    echo 'export DOTNET_SHARED_STORE=$agentPath/store' >> ~/.bashrc"
        Print ""
        Print "  Note: These variables are NOT set globally by the installer."
        Print "        You must set them in your application's environment."
        Print ""
        Print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        Print "  Additional Resources"
        Print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        Print "  Documentation: https://www.manageengine.com/products/applications_manager/help/apminsight-dotnet-agent.html"
        Print "  Uninstall: $agentPath/UninstallAgent.sh"
        Print ""
    else
		Print "Choose how to run your .NET application with APM monitoring:"
		Print ""
		Print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
		Print "  Method 1: Run specific .NET commands with monitoring"
		Print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
		Print "  Use the wrapper script:"
		Print ""
		Print "    $scriptsPath/run-dotnetapm.sh dotnet run"
		Print "    $scriptsPath/run-dotnetapm.sh dotnet YourApp.dll"
		Print ""
		Print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
		Print "  Method 2: Enable monitoring for your entire shell session"
		Print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
		Print "  Source the environment script (all child processes will be monitored):"
		Print ""
		Print "    source $scriptsPath/set-shell-env.sh"
		Print "    dotnet run    # Now monitored!"
		Print ""
		Print "  To make it permanent, add to your shell config:"
		Print ""
		Print "    echo 'source $scriptsPath/set-shell-env.sh' >> ~/.bashrc"
		Print ""
		Print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
		Print "  Additional Resources"
		Print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
		Print "  Documentation: https://www.manageengine.com/products/applications_manager/help/apminsight-dotnet-agent.html"
		Print "  Self-Contained Apps: https://pitstop.manageengine.com/portal/en/kb/articles/to-monitor-self-contained-net-core-applications-using-net-core-agent-loader-api"
		Print "  Uninstall: $agentPath/UninstallAgent.sh"
		Print ""
	fi
}

function DownloadAndExtractAgent() {
    
    agentUrl="${DOWNLOAD_DOMAIN}/${agentZipGLibcUrl}"
    checksumUrl="${DOWNLOAD_DOMAIN}/${checksumGLibcUrl}"
    
    if ldd --version 2>/dev/null | grep -iqE "GNU libc|Free Software Foundation"; then
        echo "Detected glibc system"
    else
        echo "Detected musl system"
    fi

    Print "Downloading agent..."
    wget -q -O "$agentZipName" "$agentUrl" || { echo "Download failed"; exit 1; }

    Print "Downloading checksum..."
    wget -q -O "checksum.txt" "$checksumUrl" || { echo "Checksum download failed"; rm "$agentZipName"; exit 1; }

    actualChecksum=$(sha256sum "$agentZipName" | awk '{print tolower(substr($1, 1, 64))}')
    expectedChecksum=$(cat checksum.txt | tr '[:upper:]' '[:lower:]' | cut -c 1-64)

    if [ "$actualChecksum" != "$expectedChecksum" ]; then
        echo "Checksum verification failed!"
        rm "$agentZipName" "checksum.txt"
        exit 1
    fi
    echo "Checksum verified ✓"

    Print "Extracting agent..."
    unzip -q "$agentZipName" || { echo "Extraction failed"; rm "$agentZipName"; exit 1; }
    
    rm "$agentZipName" "checksum.txt"
}

function Print() {
    echo -e "$1"
}

function SetupDeprecatedVersionsSupport() {
    local resolvedPath=$1
    local PSScriptRoot=$2
    
    Print "Setting up support for deprecated .NET Core versions (2.0 - 3.1)..."
    
    # Supported .NET versions
    local SUPPORTED_VERSIONS=("netcoreapp2.0" "netcoreapp2.1" "netcoreapp2.2" "netcoreapp3.0" "netcoreapp3.1" "net5.0" "net6.0" "net7.0" "net8.0")
    local PLATFORMS=("x64" "x86")
    
    # Copy additionalDeps directory from Agent/packages (accounting for case sensitivity)
    if [ -d "$PSScriptRoot/Agent/packages/additionalDeps" ]; then
        cp -r "$PSScriptRoot/Agent/packages/additionalDeps" "$resolvedPath/"
        Print "  ✓ Copied additionalDeps directory"
    elif [ -d "$PSScriptRoot/Agent/packages/additionaldeps" ]; then
        cp -r "$PSScriptRoot/Agent/packages/additionaldeps" "$resolvedPath/additionalDeps"
        Print "  ✓ Copied additionalDeps directory (lowercase source)"
    else
        Print "  ⚠ Warning: additionalDeps directory not found in package"
    fi
    
    # Find the DLL files (accounting for case sensitivity)
    local DOTNETAGENT_DLL=""
    local DOTNETAGENT_UTIL_DLL=""
    local SITE24X7_AGENT_API_DLL=""
    local AUTOUPDATE_DLL=""
    
    # Check for DLLs in netstandard2.0 directory (case-insensitive search)
    if [ -f "$resolvedPath/netstandard2.0/DotNetAgent.dll" ]; then
        DOTNETAGENT_DLL="$resolvedPath/netstandard2.0/DotNetAgent.dll"
    elif [ -f "$resolvedPath/netstandard2.0/dotnetagent.dll" ]; then
        DOTNETAGENT_DLL="$resolvedPath/netstandard2.0/dotnetagent.dll"
    fi
    
    if [ -f "$resolvedPath/netstandard2.0/DotNetAgent.Util.dll" ]; then
        DOTNETAGENT_UTIL_DLL="$resolvedPath/netstandard2.0/DotNetAgent.Util.dll"
    elif [ -f "$resolvedPath/netstandard2.0/dotnetagent.util.dll" ]; then
        DOTNETAGENT_UTIL_DLL="$resolvedPath/netstandard2.0/dotnetagent.util.dll"
    fi
    
    if [ -f "$resolvedPath/netstandard2.0/Site24x7.Agent.Api.dll" ]; then
        SITE24X7_AGENT_API_DLL="$resolvedPath/netstandard2.0/Site24x7.Agent.Api.dll"
    elif [ -f "$resolvedPath/netstandard2.0/site24x7.agent.api.dll" ]; then
        SITE24X7_AGENT_API_DLL="$resolvedPath/netstandard2.0/site24x7.agent.api.dll"
    fi
    
    if [ -f "$resolvedPath/netstandard2.0/AutoUpdate.dll" ]; then
        AUTOUPDATE_DLL="$resolvedPath/netstandard2.0/AutoUpdate.dll"
    elif [ -f "$resolvedPath/netstandard2.0/autoupdate.dll" ]; then
        AUTOUPDATE_DLL="$resolvedPath/netstandard2.0/autoupdate.dll"
    fi
    
    # Validate that we found the required DLLs
    if [ -z "$DOTNETAGENT_DLL" ] || [ -z "$DOTNETAGENT_UTIL_DLL" ] || [ -z "$SITE24X7_AGENT_API_DLL" ] || [ -z "$AUTOUPDATE_DLL" ]; then
        Print "  ⚠ Warning: Not all required DLLs found. Continuing with available DLLs..."
    fi
    
    # Create store directory structure for each platform and version
    for platform in "${PLATFORMS[@]}"; do
        for version in "${SUPPORTED_VERSIONS[@]}"; do
            # Create directory structure for dotnetagent
            if [ -n "$DOTNETAGENT_DLL" ]; then
                local target_dir="$resolvedPath/store/$platform/$version/DotNetAgent/1.0.0/lib/netcoreapp2.0"
                mkdir -p "$target_dir"
                cp "$DOTNETAGENT_DLL" "$target_dir/"
            fi
            
            # Create directory structure for dotnetagent.util
            if [ -n "$DOTNETAGENT_UTIL_DLL" ]; then
                local target_dir="$resolvedPath/store/$platform/$version/DotNetAgent.Util/1.0.0/lib/netcoreapp2.0"
                mkdir -p "$target_dir"
                cp "$DOTNETAGENT_UTIL_DLL" "$target_dir/"
            fi
            
            # Create directory structure for site24x7.agent.api
            if [ -n "$SITE24X7_AGENT_API_DLL" ]; then
                local target_dir="$resolvedPath/store/$platform/$version/Site24x7.Agent.Api/1.0.0/lib/netcoreapp2.0"
                mkdir -p "$target_dir"
                cp "$SITE24X7_AGENT_API_DLL" "$target_dir/"
            fi
            
            # Create directory structure for autoupdate
            if [ -n "$AUTOUPDATE_DLL" ]; then
                local target_dir="$resolvedPath/store/$platform/$version/AutoUpdate/1.0.0/lib/netcoreapp2.0"
                mkdir -p "$target_dir"
                cp "$AUTOUPDATE_DLL" "$target_dir/"
            fi
        done
    done
    
    Print "  ✓ Created store directory structure for deprecated versions"
    Print "  ✓ Deprecated versions support setup complete"
}

function CopyFiles() {
    agentPath=$1
    mkdir -p "$agentPath"
    resolvedPath=$(realpath "$agentPath")

    # Backup old files
    [ -d "$resolvedPath/netstandard2.0" ] && find "$resolvedPath/netstandard2.0" -name "*.dll" -exec sh -c 'mv "$0" "${0%.dll}_old.dll"' {} \; 2>/dev/null
    [ -d "$resolvedPath/x64" ] && find "$resolvedPath/x64" -name "*.so" -exec sh -c 'mv "$0" "${0%.so}_old.so"' {} \; 2>/dev/null
    [ -d "$resolvedPath/x86" ] && find "$resolvedPath/x86" -name "*.so" -exec sh -c 'mv "$0" "${0%.so}_old.so"' {} \; 2>/dev/null

	PSScriptRoot=$(dirname "$(realpath "$0")")
    [ "$OfflineInstall" = false ] && PSScriptRoot="$PSScriptRoot/dotnet_core_linux"
    
    CopyAgentFiles "$resolvedPath"
	
	# Setup deprecated versions support if flag is enabled
    if [ "$SupportDeprecatedVersions" = true ]; then
        SetupDeprecatedVersionsSupport "$resolvedPath" "$PSScriptRoot"
    fi
    
    ModifyConfiguration "$resolvedPath"
    CreateHelperScripts

    find "$resolvedPath/netstandard2.0" -type f -exec chmod +x {} \; 2>/dev/null
    [ -f "$resolvedPath/UninstallAgent.sh" ] && chmod +x "$resolvedPath/UninstallAgent.sh"
    [ -d "$resolvedPath/scripts" ] && chmod +x "$resolvedPath/scripts/"*.sh 2>/dev/null

    [ -d "$resolvedPath/DotNetCoreAgent" ] && ExecuteWithPrivilege chmod -R 777 "$resolvedPath/DotNetCoreAgent"

    SetFolderPermissions "$agentPath"
    CreateVersionInfoFile "$resolvedPath"
    SetGlobalEnvironment "$resolvedPath"
}

function CopyAgentFiles() {
    resolvedPath=$1
    PSScriptRoot=$(dirname "$(realpath "$0")")
    [ "$OfflineInstall" = false ] && PSScriptRoot="$PSScriptRoot/dotnet_core_linux"

    cp -r "$PSScriptRoot/Agent/DotNetCoreAgent" "$resolvedPath"
    cp -r "$PSScriptRoot/Agent/packages/x64" "$resolvedPath"
    cp -r "$PSScriptRoot/Agent/packages/x86" "$resolvedPath"
    mkdir -p "$resolvedPath/netstandard2.0"
    cp -r "$PSScriptRoot/Agent/packages/AnyCPU/." "$resolvedPath/netstandard2.0"
    
    # Copy scripts directory into ManageEngineDotNetCoreAgent
    if [ -d "$PSScriptRoot/Agent/packages/scripts" ]; then
        cp -r "$PSScriptRoot/Agent/packages/scripts" "$resolvedPath/"
    fi
    
    # Copy UninstallAgent.sh from package
    if [ -f "$PSScriptRoot/UninstallAgent.sh" ]; then
        cp "$PSScriptRoot/UninstallAgent.sh" "$resolvedPath/"
        chmod +x "$resolvedPath/UninstallAgent.sh"
    fi
}

function CopyFilesForAutoProfiler() {
    libPath="$Destination/ManageEngineDotNetCoreAgent"
    homePath="$AutoProfilerHomePath/ManageEngineDotNetCoreAgent"
    
    PSScriptRoot=$(dirname "$(realpath "$0")")
    [ "$OfflineInstall" = false ] && PSScriptRoot="$PSScriptRoot/dotnet_core_linux"
    
    # Create directories
    mkdir -p "$libPath"
    mkdir -p "$homePath"
    
    # Copy library files to Destination (all except DotNetCoreAgent)
    cp -r "$PSScriptRoot/Agent/packages/x64" "$libPath"
    cp -r "$PSScriptRoot/Agent/packages/x86" "$libPath"
    mkdir -p "$libPath/netstandard2.0"
    cp -r "$PSScriptRoot/Agent/packages/AnyCPU/." "$libPath/netstandard2.0"
    
    # Setup deprecated versions support if flag is enabled
    if [ "$SupportDeprecatedVersions" = true ]; then
        SetupDeprecatedVersionsSupport "$libPath" "$PSScriptRoot"
    fi
    
	# Copy scripts directory
    if [ -d "$PSScriptRoot/Agent/packages/scripts" ]; then
        cp -r "$PSScriptRoot/Agent/packages/scripts" "$libPath/"
    fi
    
    # Copy UninstallAgent.sh
    if [ -f "$PSScriptRoot/UninstallAgent.sh" ]; then
        cp "$PSScriptRoot/UninstallAgent.sh" "$libPath/"
        chmod +x "$libPath/UninstallAgent.sh"
    fi
    
    # Copy DotNetCoreAgent (config) to AutoProfilerHomePath
    cp -r "$PSScriptRoot/Agent/DotNetCoreAgent" "$homePath"
    
    # Set permissions
    find "$libPath/netstandard2.0" -type f -exec chmod +x {} \; 2>/dev/null
    [ -d "$libPath/scripts" ] && chmod +x "$libPath/scripts/"*.sh 2>/dev/null
    
    ExecuteWithPrivilege chmod -R 777 "$homePath/DotNetCoreAgent"
    ExecuteWithPrivilege chmod -R 777 "$libPath"
    
    # Create version info in lib path
    echo "$AgentVersion" > "$libPath/version.info"
}

function ModifyConfiguration() {
    [ -z "$LicenseKey" ] && return

    local encrypt_output
    encrypt_output=$(encrypt_aes "$LicenseKey") || { Print "Error: Encryption failed"; exit 1; }

    # Parse the output using ::: as delimiter
    local EncryptedString=$(echo "$encrypt_output" | cut -d':' -f1)
    local SaltKey=$(echo "$encrypt_output" | cut -d':' -f4)
    local InitVector=$(echo "$encrypt_output" | cut -d':' -f7)
    
    # Debug: Verify values were extracted
    if [ -z "$EncryptedString" ] || [ -z "$SaltKey" ] || [ -z "$InitVector" ]; then
        Print "Error: Failed to parse encryption output"
        Print "  Raw output: $encrypt_output"
        Print "  EncryptedString empty: $([ -z "$EncryptedString" ] && echo 'YES' || echo 'NO')"
        Print "  SaltKey empty: $([ -z "$SaltKey" ] && echo 'YES' || echo 'NO')"
        Print "  InitVector empty: $([ -z "$InitVector" ] && echo 'YES' || echo 'NO')"
        exit 1
    fi
	
    agentPath=$1
    filePath="$agentPath/DotNetCoreAgent/apminsight.conf"
    
    if [ -f "$filePath" ]; then
        sed -i "s|license.key=.*|license.key=$EncryptedString|" "$filePath"
        sed -i "s|apminsight_agent_start_time=.*|apminsight_agent_start_time=$SaltKey|" "$filePath"
        sed -i "s|apminsight_agent_id=.*|apminsight_agent_id=$InitVector|" "$filePath"
        
        # Handle APM host/port/protocol settings (only if exporter is not used)
        if [ -z "$ExporterHost" ] && [ -z "$ExporterStatusPort" ] && [ -z "$ExporterDataPort" ]; then
            if [ -n "$ApmHost" ]; then
                sed -i "s|apm.host=.*|apm.host=$ApmHost|" "$filePath"
            fi
            if [ -n "$ApmPort" ]; then
                sed -i "s|apm.port=.*|apm.port=$ApmPort|" "$filePath"
            fi
            if [ "$ApmProtocolHttps" = true ]; then
                sed -i "s|apm.protocol.https=.*|apm.protocol.https=true|" "$filePath"
            else
                sed -i "s|apm.protocol.https=.*|apm.protocol.https=false|" "$filePath"
            fi
        fi
        
        # Handle communication mode and exporter settings
        if [ -n "$ExporterHost" ] || [ -n "$ExporterStatusPort" ] || [ -n "$ExporterDataPort" ]; then
            # Using exporter service
            sed -i "s|manageengine_communication_mode=.*|manageengine_communication_mode=ExporterService|" "$filePath"
            [ -n "$ExporterHost" ] && sed -i "s|apm_exporter_host=.*|apm_exporter_host=$ExporterHost|" "$filePath"
            [ -n "$ExporterStatusPort" ] && sed -i "s|apm_exporter_status_port=.*|apm_exporter_status_port=$ExporterStatusPort|" "$filePath"
            [ -n "$ExporterDataPort" ] && sed -i "s|apm_exporter_data_port=.*|apm_exporter_data_port=$ExporterDataPort|" "$filePath"
        else
            # Direct communication mode
            sed -i "s|manageengine_communication_mode=.*|manageengine_communication_mode=direct|" "$filePath"
        fi
        
        if [ "$IsBehindProxy" = true ]; then
            sed -i "s/behind.proxy=false/behind.proxy=true/" "$filePath"
            sed -i "s/proxy.server.host=proxyserver/proxy.server.host=$ProxyHost/" "$filePath"
            sed -i "s/proxy.server.port=proxyport/proxy.server.port=$ProxyPort/" "$filePath"
            sed -i "s/proxy.auth.username=proxyuser/proxy.auth.username=$ProxyUser/" "$filePath"
            sed -i "s/proxy.auth.password=proxypassword/proxy.auth.password=$ProxyPassword/" "$filePath"
        fi
        
        [ "$DisableAppFilter" = true ] && DisableAppFilterInConfig "$filePath"
    fi
}

function DisableAppFilterInConfig() {
    local filePath=$1
    local keyValue="enable.appfilter=false"
    
    if grep -q "enable.appfilter=" "$filePath"; then
        sed -i "s/enable.appfilter=.*/enable.appfilter=false/" "$filePath"
    else
        echo "$keyValue" >> "$filePath"
    fi
}

function CreateHelperScripts() {
    # Scripts are already copied by CopyAgentFiles function
    # Just ensure they have execute permissions
    scriptsDir="$Destination/ManageEngineDotNetCoreAgent/scripts"
    if [ -d "$scriptsDir" ]; then
        chmod +x "$scriptsDir/"*.sh 2>/dev/null
    fi
}

function SetGlobalEnvironment() {
    agentPath=$1
    scriptsPath="$agentPath/scripts"
    
    # Clean up old env vars
    ExecuteWithPrivilege sed -i '/^CORECLR_ENABLE_PROFILING=/d' /etc/environment 2>/dev/null
    ExecuteWithPrivilege sed -i '/^CORECLR_PROFILER=/d' /etc/environment 2>/dev/null
    ExecuteWithPrivilege sed -i '/^CORECLR_PROFILER_PATH_64=/d' /etc/environment 2>/dev/null
    ExecuteWithPrivilege sed -i '/^CORECLR_PROFILER_PATH_32=/d' /etc/environment 2>/dev/null
    ExecuteWithPrivilege sed -i '/^DOTNET_STARTUP_HOOKS=/d' /etc/environment 2>/dev/null
    ExecuteWithPrivilege sed -i '/^APMINSIGHT_LICENSEKEY=/d' /etc/environment 2>/dev/null
    ExecuteWithPrivilege sed -i '/^APMINSIGHT_APP_NAME=/d' /etc/environment 2>/dev/null
    ExecuteWithPrivilege sed -i '/^MANAGEENGINE_COMMUNICATION_MODE=/d' /etc/environment 2>/dev/null
    ExecuteWithPrivilege sed -i '/^DOTNETCOREAGENT_HOME=/d' /etc/environment 2>/dev/null
    ExecuteWithPrivilege sed -i '/^APMINSIGHT_SCRIPTS_PATH=/d' /etc/environment 2>/dev/null
    ExecuteWithPrivilege sed -i '/^DOTNET_ADDITIONAL_DEPS=/d' /etc/environment 2>/dev/null
    ExecuteWithPrivilege sed -i '/^DOTNET_SHARED_STORE=/d' /etc/environment 2>/dev/null
    
    # Set agent home and scripts path
    echo "DOTNETCOREAGENT_HOME=$agentPath" | ExecuteWithPrivilege tee -a /etc/environment > /dev/null
    echo "APMINSIGHT_SCRIPTS_PATH=$scriptsPath" | ExecuteWithPrivilege tee -a /etc/environment > /dev/null
}

# Helper function to execute commands with or without sudo
function ExecuteWithPrivilege() {
    if [ "$EUID" -eq 0 ]; then
        # Already root, execute directly
        "$@"
    else
        # Not root, use sudo
        sudo "$@"
    fi
}

function ValidateParameters() {
    Destination=$(echo "$Destination" | xargs)
    LicenseKey=$(echo "$LicenseKey" | xargs)
    
    [ -z "$Destination" ] && Destination="/opt/manageengine"
    
    # AutoProfiler mode validation
    if [ "$AutoProfilerInstall" = true ]; then
        if [ -z "$AutoProfilerHomePath" ]; then
            Print "Error: -AutoProfilerHomePath is required when using -AutoProfilerInstall"
            exit 1
        fi
        # No need for license key or APM settings in AutoProfiler mode
        return
    fi

	# At least one host must be provided
	if [[ -z "$ApmHost" && -z "$ExporterHost" ]]; then
		Print "Error: Either -ApmHost or -ExporterHost is required. Use -Help for usage."
		exit 1
	fi

	# If ExporterHost is provided, ports are mandatory
	if [[ -n "$ExporterHost" && ( -z "$ExporterDataPort" || -z "$ExporterStatusPort" ) ]]; then
		Print "Error: -ExporterHost requires both -ExporterDataPort and -ExporterStatusPort."
		exit 1
	fi
    
    # Standard mode validation
    if [ "$IsBehindProxy" = true ]; then
        [ -z "$ProxyHost" ] && { Print "Error: -ProxyHost required"; exit 1; }
        [ "$ProxyPort" -eq 0 ] && { Print "Error: -ProxyPort required"; exit 1; }
    fi
}

function CreateVersionInfoFile() {
    echo "$AgentVersion" > "$1/version.info"
}

function CheckAdminRights() {
    if [ "$EUID" -ne 0 ]; then
        Print "Error: This script requires sudo privileges"
        exit 1
    fi
}

function SetFolderPermissions() {
    ACTUAL_USER=${SUDO_USER:-$USER}
    ExecuteWithPrivilege chown -R "$ACTUAL_USER":"$ACTUAL_USER" "$1"
    ExecuteWithPrivilege chmod -R 755 "$1"
}

function generate_random_key() {
    local size=${1:-32}
    # Generate exactly the required number of random bytes (not base64)
    openssl rand -hex $size | cut -c1-$((size * 2)) | xxd -r -p | base64 | tr -d '\n' | head -c $size
}

function encrypt_aes() {
    local originalStr="$1"

    if [ -z "$originalStr" ]; then
        echo "Error: No string for encryption" >&2
        return 1
    fi

    # Build agent_id (16 digits): {2 random}{YY}{MM}{DD}{HH}{MM}{SS}{2 random}
    local r1=$(( RANDOM % 90 + 10 ))
    local r2=$(( RANDOM % 90 + 10 ))
    local datePart=$(date '+%y%m%d%H%M%S')
    local InitVector="${r1}${datePart}${r2}"

    # Build start_time (32 digits): agent_id + 16 random digits
    local r3=$(( RANDOM % 9000 + 1000 ))
    local r4=$(( RANDOM % 9000 + 1000 ))
    local r5=$(( RANDOM % 9000 + 1000 ))
    local r6=$(( RANDOM % 9000 + 1000 ))
    local SaltKey="${InitVector}${r3}${r4}${r5}${r6}"

    # Validate lengths
    if [ ${#InitVector} -ne 16 ]; then
        echo "Error: IV generation failed (expected 16 digits, got ${#InitVector})" >&2
        return 1
    fi
    if [ ${#SaltKey} -ne 32 ]; then
        echo "Error: Key generation failed (expected 32 digits, got ${#SaltKey})" >&2
        return 1
    fi

    # The C# Decrypt uses Encoding.UTF8.GetBytes(keyString) to get the AES key/IV bytes.
    # So the actual key bytes are the ASCII values of the digit characters.
    # We must do the same here: convert each ASCII char to its hex value for openssl -K/-iv.
    local SaltKeyHex=$(echo -n "$SaltKey" | od -A n -t x1 | tr -d ' \n')
    local InitVectorHex=$(echo -n "$InitVector" | od -A n -t x1 | tr -d ' \n')

    # Encrypt using AES-256-CBC
    local EncryptedString
    EncryptedString=$(echo -n "$originalStr" | openssl enc -aes-256-cbc -base64 \
        -K "$SaltKeyHex" -iv "$InitVectorHex" 2>/dev/null | tr -d '\n')

    if [ $? -ne 0 ] || [ -z "$EncryptedString" ]; then
        echo "Error: Encryption failed" >&2
        return 1
    fi

    echo "${EncryptedString}:::${SaltKey}:::${InitVector}"
    return 0
}

# Parse arguments
while [ $# -gt 0 ]; do
    case "$1" in
        -Destination) Destination="$2"; shift 2 ;;
        -LicenseKey) LicenseKey="$2"; shift 2 ;;
        -AppName) AppName="$2"; shift 2 ;;
        -ForceUpdate) ForceUpdate=true; shift ;;
        -Help) Help=true; shift ;;
        -IsBehindProxy) IsBehindProxy=true; shift ;;
        -ProxyHost) ProxyHost="$2"; shift 2 ;;
        -ProxyPort) ProxyPort="$2"; shift 2 ;;
        -ProxyUser) ProxyUser="$2"; shift 2 ;;
        -ProxyPassword) ProxyPassword="$2"; shift 2 ;;
        -DisableAppFilter) DisableAppFilter=true; shift ;;
        -OfflineInstall) OfflineInstall=true; shift ;;
        -ApmHost) ApmHost="$2"; shift 2 ;;
        -ApmPort) ApmPort="$2"; shift 2 ;;
        -ApmProtocolHttps) 
            if [ "$2" = "false" ] || [ "$2" = "False" ] || [ "$2" = "FALSE" ]; then
                ApmProtocolHttps=false
            else
                ApmProtocolHttps=true
            fi
            shift 2
            ;;
        -ExporterHost) ExporterHost="$2"; shift 2 ;;
        -ExporterStatusPort) ExporterStatusPort="$2"; shift 2 ;;
        -ExporterDataPort) ExporterDataPort="$2"; shift 2 ;;
        -AutoProfilerInstall) AutoProfilerInstall=true; shift ;;
        -AutoProfilerHomePath) AutoProfilerHomePath="$2"; shift 2 ;;
		-SupportDeprecatedVersions) SupportDeprecatedVersions=true; shift ;;
        *) echo "Unknown parameter: $1"; exit 1 ;;
    esac
done

[ "$Help" = true ] && {
    cat << 'HELP'
ManageEngine APM .NET Core Agent Installer

Usage: sudo ./InstallAgent.sh [OPTIONS]

Standard Installation Options:
  -Destination <path>          Install location (default: /opt/manageengine)
  -LicenseKey <key>            ManageEngine license key
  -AppName <name>              Application name
  -ForceUpdate                 Force update without prompt
  -IsBehindProxy               Enable proxy
  -ProxyHost <host>            Proxy hostname
  -ProxyPort <port>            Proxy port
  -ProxyUser <user>            Proxy username
  -ProxyPassword <pass>        Proxy password
  -DisableAppFilter            Disable app filtering
  -OfflineInstall              Install from local files
  -SupportDeprecatedVersions   Enable support for .NET Core 2.0 - 3.1
                               (uses DOTNET_ADDITIONAL_DEPS and DOTNET_SHARED_STORE)
  -Help                     Show this help

APM Direct Connection Options (used when Exporter is not configured):
  -ApmHost <host>           APM server hostname
  -ApmPort <port>           APM server port (default: 9090)
  -ApmProtocolHttps <bool>  Use HTTPS protocol (default: true)

APM Exporter Service Options (when using local exporter):
  -ExporterHost <host>      APM exporter service host (default: localhost)
  -ExporterStatusPort <p>   APM exporter status port (default: 20021)
  -ExporterDataPort <p>     APM exporter data port (default: 20022)

Deprecated Versions Support:
  When -SupportDeprecatedVersions is enabled, the installer creates the
  directory structure required for .NET Core 2.0 - 3.1 compatibility using
  DOTNET_ADDITIONAL_DEPS and DOTNET_SHARED_STORE environment variables.
  
  This is necessary because DOTNET_STARTUP_HOOKS (used by default) is not
  supported in .NET Core versions prior to 3.0.
  
AutoProfiler Installation Options:
  -AutoProfilerInstall      Enable AutoProfiler installation mode
  -AutoProfilerHomePath <p> Path for configuration files (required with -AutoProfilerInstall)
  -Destination <path>       Path for library files (default: /opt/manageengine)

Communication Modes:
  - Direct: Agent sends data directly to APM server (default)
            Configure with -ApmHost, -ApmPort, -ApmProtocolHttps
  - Exporter: Agent sends datathrough local exporter service
			Configure with -ExporterHost, -ExporterStatusPort, -ExporterDataPort
Examples:
	# Standard installation with direct APM connection
	sudo ./InstallAgent.sh -Destination /opt/manageengine -LicenseKey your_key_here \
	-ApmHost apm.manageengine.com -ApmPort 9090 -ApmProtocolHttps true

	# Exporter mode installation
	sudo ./InstallAgent.sh -Destination /opt/manageengine -LicenseKey your_key \
	-ExporterHost localhost -ExporterStatusPort 20021 -ExporterDataPort 20022
	
    # AutoProfiler installation
	sudo ./InstallAgent.sh -Destination /path/to/dotnet/lib \
	-AutoProfilerInstall -AutoProfilerHomePath /path/to/dotnet/home

Note: -ApmHost, -ApmPort, and -ApmProtocolHttps are only used when Exporter options are NOT provided.
In AutoProfiler mode, none of these connection settings are required.

HELP
	exit 0
}

ValidateParameters
CheckAdminRights
InstallAgent