#!/bin/bash

# UninstallAgent.sh - APMInsight .NET Core Agent Uninstaller

echo "╔════════════════════════════════════════════════════════════════════════╗"
echo "║            APMINSIGHT .NET Core Agent Uninstallation                   ║"
echo "╚════════════════════════════════════════════════════════════════════════╝"
echo ""

# Function to execute command with or without sudo
ExecuteWithPrivilege() {
    if [ "$EUID" -eq 0 ]; then
        # Already root, execute directly
        "$@"
    else
        # Not root, use sudo
        sudo "$@"
    fi
}

# Check if running with appropriate privileges
if [ "$EUID" -ne 0 ] && ! command -v sudo &> /dev/null; then
    echo "Error: This script requires root privileges or sudo."
    echo "Please run as root or install sudo."
    exit 1
fi

# Get agent home from environment variable
AGENT_HOME="${DOTNETCOREAGENT_HOME}"

if [ -z "$AGENT_HOME" ]; then
    echo "Warning: DOTNETCOREAGENT_HOME environment variable not set."
    echo ""
    read -p "Enter the agent installation path (e.g., /opt/site24x7/ApmInsightDotNetCoreAgent): " AGENT_HOME
    
    if [ -z "$AGENT_HOME" ]; then
        echo "Error: No installation path provided. Exiting."
        exit 1
    fi
fi

# Verify the path exists
if [ ! -d "$AGENT_HOME" ]; then
    echo "Error: Agent directory not found at: $AGENT_HOME"
    echo ""
    echo "The agent may have already been uninstalled or the path is incorrect."
    read -p "Do you want to proceed with cleaning environment variables anyway? [y/N] " proceed
    
    if [[ ! "$proceed" =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Get scripts directory path (inside ApmInsightDotNetCoreAgent)
SCRIPTS_DIR="$AGENT_HOME/scripts"

echo "Agent Home: $AGENT_HOME"
[ -d "$SCRIPTS_DIR" ] && echo "Scripts Directory: $SCRIPTS_DIR"
echo ""

# Confirm uninstallation
read -p "Are you sure you want to uninstall the APMINSIGHT .NET agent? [y/N] " confirmation

if [[ ! "$confirmation" =~ ^[Yy]$ ]]; then
    echo "Uninstallation cancelled."
    exit 0
fi

echo ""
echo "Starting uninstallation..."
echo ""

# Step 1: Remove environment variables from /etc/environment
echo "[1/3] Removing global environment variables..."

ENV_VARS_TO_REMOVE=(
    "DOTNETCOREAGENT_HOME"
    "SITE24X7_SCRIPTS_PATH"
	"APMINSIGHT_SCRIPTS_PATH"
    "CORECLR_ENABLE_PROFILING"
    "CORECLR_PROFILER"
	"APMINSIGHT_APP_NAME"
	"APMINSIGHT_LICENSEKEY"
    "CORECLR_PROFILER_PATH_64"
    "CORECLR_PROFILER_PATH_32"
    "DOTNET_STARTUP_HOOKS"
    "S247_LICENSE_KEY"
    "SITE24X7_APP_NAME"
    "MANAGEENGINE_COMMUNICATION_MODE"
)

for var in "${ENV_VARS_TO_REMOVE[@]}"; do
    ExecuteWithPrivilege sed -i "/^${var}=/d" /etc/environment 2>/dev/null
done

echo "      ✓ Environment variables removed from /etc/environment"

# Step 2: Remove agent files
echo "[2/3] Removing agent files..."

if [ -d "$AGENT_HOME" ]; then
    ExecuteWithPrivilege rm -rf "$AGENT_HOME"
    echo "      ✓ Removed: $AGENT_HOME (including scripts directory)"
else
    echo "      ⚠ Agent directory not found (may already be removed)"
fi

# Step 3: Check if parent directory is empty
echo "[3/3] Cleanup check..."

PARENT_DIR="$(dirname "$AGENT_HOME")"
if [ -d "$PARENT_DIR" ]; then
    if [ -z "$(ls -A "$PARENT_DIR" 2>/dev/null)" ]; then
        read -p "      Parent directory $PARENT_DIR is empty. Remove it? [y/N] " remove_parent
        if [[ "$remove_parent" =~ ^[Yy]$ ]]; then
            ExecuteWithPrivilege rmdir "$PARENT_DIR" 2>/dev/null
            echo "      ✓ Removed: $PARENT_DIR"
        fi
    fi
fi

echo ""
echo "╔════════════════════════════════════════════════════════════════════════╗"
echo "║              Uninstallation completed successfully!                    ║"
echo "╚════════════════════════════════════════════════════════════════════════╝"
echo ""
echo "Cleanup Summary:"
echo "  ✓ Environment variables removed from /etc/environment"
echo "  ✓ Agent files removed (including scripts)"
echo ""
echo "Important Notes:"
echo "  • Restart your shell or re-login for environment changes to take effect"
echo "  • Running .NET processes will continue to be monitored until restarted"
echo "  • To stop monitoring immediately, restart your .NET applications"
echo ""
echo "If you had sourced set-shell-env.sh in your shell config (~/.bashrc, etc.),"
echo "please remove that line manually."
echo ""