#!/bin/bash

# Function to print messages
function Print() {
    echo -e "\n$1"
}

# Function to uninstall the agent
function UninstallAgent() {
    if [ -z "$DOTNETCOREAGENT_HOME" ]; then
        Print "DOTNETCOREAGENT_HOME environment variable is not set. Cannot determine the install location."
        exit 1
    fi

    agentPath="$DOTNETCOREAGENT_HOME"
    
    if [ -d "$agentPath" ]; then
        Print "Removing APM Insight .NET Core agent files and folders."

        # Remove the agent directories and files
        sudo rm -rf "$agentPath"

        # Clean environment variables
        CleanEnvironmentVariables

        Print "APM Insight .NET Core agent has been uninstalled successfully."
    else
        Print "APM Insight .NET Core agent is not installed in the specified location."
    fi
}

# Function to clean environment variables
function CleanEnvironmentVariables() {
    if grep -q "DOTNETCOREAGENT_HOME" /etc/environment; then
        Print "Removing environment variables from /etc/environment (global install)."
        sudo sed -i '/CORECLR_ENABLE_PROFILING/d' /etc/environment
        sudo sed -i '/CORECLR_PROFILER/d' /etc/environment
        sudo sed -i '/DOTNETCOREAGENT_HOME/d' /etc/environment
        sudo sed -i '/CORECLR_PROFILER_PATH_64/d' /etc/environment
        sudo sed -i '/CORECLR_PROFILER_PATH_32/d' /etc/environment
        sudo sed -i '/DOTNET_ADDITIONAL_DEPS/d' /etc/environment
        sudo sed -i '/DOTNET_SHARED_STORE/d' /etc/environment
        sudo sed -i '/S247_LICENSE_KEY/d' /etc/environment
        sudo sed -i '/SITE24X7_APP_NAME/d' /etc/environment
		sudo sed -i '/DOTNET_STARTUP_HOOKS/d' /etc/environment
		sudo sed -i '/MANAGEENGINE_COMMUNICATION_MODE/d' /etc/environment

        Print "Reloading environment variables."
        source /etc/environment
    else
        Print "Removing local environment variables."
        unset CORECLR_ENABLE_PROFILING
        unset CORECLR_PROFILER
        unset DOTNETCOREAGENT_HOME
        unset CORECLR_PROFILER_PATH_64
        unset CORECLR_PROFILER_PATH_32
        unset DOTNET_ADDITIONAL_DEPS
        unset DOTNET_SHARED_STORE
        unset S247_LICENSE_KEY
        unset SITE24X7_APP_NAME
		unset DOTNET_STARTUP_HOOKS
		unset MANAGEENGINE_COMMUNICATION_MODE
    fi
}

# Function to check admin rights
function CheckAdminRights() {
    if [ "$EUID" -ne 0 ]; then
        Print "You must have administrator rights to uninstall the agent globally. Please run this script with sudo."
        exit 1
    fi
}

# Main script execution
CheckAdminRights
UninstallAgent
