#!/bin/bash

# run-dotnetapm-s247.sh
# Wrapper script to run .NET commands with APMINSIGHT monitoring
# Usage: ./run-dotnetapm-s247.sh dotnet run
#        ./run-dotnetapm-s247.sh dotnet YourApp.dll

# Determine agent home - try global env first, then derive from script location
if [ -n "$DOTNETCOREAGENT_HOME" ]; then
    AGENT_HOME="$DOTNETCOREAGENT_HOME"
else
    # Get the directory where this script is located
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    # Scripts are inside ApmInsightDotNetCoreAgent/scripts
    AGENT_HOME="$(dirname "$SCRIPT_DIR")"
fi

# Validate agent installation
if [ ! -d "$AGENT_HOME/DotNetCoreAgent" ]; then
    echo "Error: APM agent not found at $AGENT_HOME"
    echo "Please verify the installation path."
    exit 1
fi

# Set APM profiler environment variables
export CORECLR_ENABLE_PROFILING=1
export CORECLR_PROFILER="{9D363A5F-ED5F-4AAC-B456-75AFFA6AA0C8}"
export DOTNETCOREAGENT_HOME="$AGENT_HOME"
export CORECLR_PROFILER_PATH_64="$AGENT_HOME/x64/libClrProfilerAgent.so"
export CORECLR_PROFILER_PATH_32="$AGENT_HOME/x86/libClrProfilerAgent.so"
export DOTNET_STARTUP_HOOKS="$AGENT_HOME/netstandard2.0/DotNetAgent.Loader.dll"

# Read configuration from apminsight.conf
CONFIG_FILE="$AGENT_HOME/DotNetCoreAgent/apminsight.conf"

# Default communication mode
export MANAGEENGINE_COMMUNICATION_MODE="direct"

if [ -f "$CONFIG_FILE" ]; then

    # Extract communication mode from config
    COMM_MODE=$(grep "^manageengine_communication_mode=" "$CONFIG_FILE" | cut -d'=' -f2- | tr -d '[:space:]')
    if [ -n "$COMM_MODE" ]; then
        export MANAGEENGINE_COMMUNICATION_MODE="$COMM_MODE"
    fi
    
    # Handle application filtering settings
    APP_FILTER=$(grep "^enable.appfilter=" "$CONFIG_FILE" | cut -d'=' -f2- | tr -d '[:space:]')
    if [ "$APP_FILTER" = "false" ]; then
        APP_NAME=$(grep "^app.name=" "$CONFIG_FILE" | cut -d'=' -f2-)
        if [ -n "$APP_NAME" ]; then
            export SITE24X7_APP_NAME="$APP_NAME"
			export APMINSIGHT_APP_NAME="$APP_NAME"
        fi
    fi
    
    # Handle proxy settings
    BEHIND_PROXY=$(grep "^behind.proxy=" "$CONFIG_FILE" | cut -d'=' -f2- | tr -d '[:space:]')
    if [ "$BEHIND_PROXY" = "true" ]; then
        PROXY_HOST=$(grep "^proxy.server.host=" "$CONFIG_FILE" | cut -d'=' -f2-)
        PROXY_PORT=$(grep "^proxy.server.port=" "$CONFIG_FILE" | cut -d'=' -f2-)
        
        if [ -n "$PROXY_HOST" ] && [ -n "$PROXY_PORT" ]; then
            export HTTP_PROXY="http://${PROXY_HOST}:${PROXY_PORT}"
            export HTTPS_PROXY="http://${PROXY_HOST}:${PROXY_PORT}"
            
            PROXY_USER=$(grep "^proxy.auth.username=" "$CONFIG_FILE" | cut -d'=' -f2-)
            PROXY_PASS=$(grep "^proxy.auth.password=" "$CONFIG_FILE" | cut -d'=' -f2-)
            
            if [ -n "$PROXY_USER" ] && [ -n "$PROXY_PASS" ]; then
                export HTTP_PROXY="http://${PROXY_USER}:${PROXY_PASS}@${PROXY_HOST}:${PROXY_PORT}"
                export HTTPS_PROXY="http://${PROXY_USER}:${PROXY_PASS}@${PROXY_HOST}:${PROXY_PORT}"
            fi
        fi
    fi
else
    echo "Warning: Configuration file not found at $CONFIG_FILE"
fi

# Verify required files exist
if [ ! -f "$CORECLR_PROFILER_PATH_64" ] && [ ! -f "$CORECLR_PROFILER_PATH_32" ]; then
    echo "Error: Profiler libraries not found"
    echo "Expected at: $CORECLR_PROFILER_PATH_64"
    exit 1
fi

if [ ! -f "$DOTNET_STARTUP_HOOKS" ]; then
    echo "Error: Agent loader not found at $DOTNET_STARTUP_HOOKS"
    exit 1
fi

# Check if command is provided
if [ $# -eq 0 ]; then
    echo "Usage: $0 <command> [arguments...]"
    echo ""
    echo "Examples:"
    echo "  $0 dotnet run"
    echo "  $0 dotnet MyApp.dll"
    echo "  $0 dotnet test"
    echo ""
    exit 1
fi

# Execute the provided command with APM monitoring enabled
exec "$@"