#!/bin/bash

# set-shell-env.sh
# Sets up APMINSIGHT environment variables in the current shell
# Usage: source ./set-shell-env.sh
#        . ./set-shell-env.sh

# Note: This script must be sourced, not executed
if [ "${BASH_SOURCE[0]}" -ef "$0" ]; then
    echo "Error: This script must be sourced, not executed directly."
    echo ""
    echo "Usage:"
    echo "  source $0"
    echo "  . $0"
    echo ""
    exit 1
fi

# Determine agent home - try global env first, then derive from script location
if [ -n "$DOTNETCOREAGENT_HOME" ]; then
    AGENT_HOME="$DOTNETCOREAGENT_HOME"
else
    # Get the directory where this script is located
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    # Scripts are inside ApmInsightDotNetCoreAgent/scripts
    AGENT_HOME="$(dirname "$SCRIPT_DIR")"
fi

# Validate agent installation
if [ ! -d "$AGENT_HOME/DotNetCoreAgent" ]; then
    echo "Error: APM agent not found at $AGENT_HOME"
    echo "Please verify the installation path."
    return 1
fi

# Set APM profiler environment variables in current shell
export CORECLR_ENABLE_PROFILING=1
export CORECLR_PROFILER="{9D363A5F-ED5F-4AAC-B456-75AFFA6AA0C8}"
export DOTNETCOREAGENT_HOME="$AGENT_HOME"
export CORECLR_PROFILER_PATH_64="$AGENT_HOME/x64/libClrProfilerAgent.so"
export CORECLR_PROFILER_PATH_32="$AGENT_HOME/x86/libClrProfilerAgent.so"
export DOTNET_STARTUP_HOOKS="$AGENT_HOME/netstandard2.0/DotNetAgent.Loader.dll"
export MANAGEENGINE_COMMUNICATION_MODE="direct"

# Read and process configuration file
CONFIG_FILE="$AGENT_HOME/DotNetCoreAgent/apminsight.conf"

if [ -f "$CONFIG_FILE" ]; then

    # Extract communication mode from config
    COMM_MODE=$(grep "^manageengine_communication_mode=" "$CONFIG_FILE" | cut -d'=' -f2- | tr -d '[:space:]')
    if [ -n "$COMM_MODE" ]; then
        export MANAGEENGINE_COMMUNICATION_MODE="$COMM_MODE"
    fi
    
    # Handle application filtering settings
    APP_FILTER=$(grep "^enable.appfilter=" "$CONFIG_FILE" | cut -d'=' -f2- | tr -d '[:space:]')
    if [ "$APP_FILTER" = "false" ]; then
        APP_NAME=$(grep "^app.name=" "$CONFIG_FILE" | cut -d'=' -f2-)
        if [ -n "$APP_NAME" ]; then
            export SITE24X7_APP_NAME="$APP_NAME"
			export APMINSIGHT_APP_NAME="$APP_NAME"
        fi
    fi
    
    # Handle proxy settings
    BEHIND_PROXY=$(grep "^behind.proxy=" "$CONFIG_FILE" | cut -d'=' -f2- | tr -d '[:space:]')
    if [ "$BEHIND_PROXY" = "true" ]; then
        PROXY_HOST=$(grep "^proxy.server.host=" "$CONFIG_FILE" | cut -d'=' -f2-)
        PROXY_PORT=$(grep "^proxy.server.port=" "$CONFIG_FILE" | cut -d'=' -f2-)
        
        if [ -n "$PROXY_HOST" ] && [ -n "$PROXY_PORT" ]; then
            export HTTP_PROXY="http://${PROXY_HOST}:${PROXY_PORT}"
            export HTTPS_PROXY="http://${PROXY_HOST}:${PROXY_PORT}"
            
            PROXY_USER=$(grep "^proxy.auth.username=" "$CONFIG_FILE" | cut -d'=' -f2-)
            PROXY_PASS=$(grep "^proxy.auth.password=" "$CONFIG_FILE" | cut -d'=' -f2-)
            
            if [ -n "$PROXY_USER" ] && [ -n "$PROXY_PASS" ]; then
                export HTTP_PROXY="http://${PROXY_USER}:${PROXY_PASS}@${PROXY_HOST}:${PROXY_PORT}"
                export HTTPS_PROXY="http://${PROXY_USER}:${PROXY_PASS}@${PROXY_HOST}:${PROXY_PORT}"
            fi
        fi
    fi
else
    echo "Warning: Configuration file not found at $CONFIG_FILE"
    return 1
fi

# Verify required files exist
if [ ! -f "$CORECLR_PROFILER_PATH_64" ] && [ ! -f "$CORECLR_PROFILER_PATH_32" ]; then
    echo "Error: Profiler libraries not found"
    echo "Expected at: $CORECLR_PROFILER_PATH_64"
    return 1
fi

if [ ! -f "$DOTNET_STARTUP_HOOKS" ]; then
    echo "Error: Agent loader not found at $DOTNET_STARTUP_HOOKS"
    return 1
fi

# Success message
echo ""
echo "╔══════════════════════════════════════════════════════════════════════╗"
echo "║  ✓  APMINSIGHT environment configured for this shell session        ║"
echo "╚══════════════════════════════════════════════════════════════════════╝"
echo ""
echo "Agent Home: $AGENT_HOME"
echo "Communication Mode: $MANAGEENGINE_COMMUNICATION_MODE"
echo ""
echo "All .NET applications started from this shell will now be monitored."
echo ""
echo "Examples:"
echo "  dotnet run"
echo "  dotnet MyApp.dll"
echo "  dotnet test"
echo ""
echo "To make this permanent, add to your shell configuration:"
if [ -n "$SITE24X7_SCRIPTS_PATH" ]; then
    echo "  echo 'source $SITE24X7_SCRIPTS_PATH/set-shell-env.sh' >> ~/.bashrc"
else
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    echo "  echo 'source $SCRIPT_DIR/set-shell-env.sh' >> ~/.bashrc"
fi
echo ""

# Return success
return 0